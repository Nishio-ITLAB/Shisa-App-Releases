# utils/network.py

import subprocess
import time


# =========================================================
# 共通コマンド実行
# =========================================================
def _run(cmd: str):
    print(f"RUN: {cmd}")
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    print(f"RETURN: {result.returncode}")
    if result.stdout:
        print(f"STDOUT: {result.stdout.strip()}")
    if result.stderr:
        print(f"STDERR: {result.stderr.strip()}")
    return result.returncode, result.stdout.strip()


# =========================================================
# eth0のdefault route削除（安全）
# =========================================================
def _disable_eth0_default():
    print("===== DISABLE ETH0 DEFAULT ROUTE =====")
    _run("sudo ip route del default dev eth0 || true")


# =========================================================
# eth0のdefault route復元（安全）
# =========================================================
def _restore_eth0_default():
    print("===== RESTORE ETH0 DEFAULT ROUTE =====")

    # gateway自動取得（eth0）
    rc, out = _run("ip route | grep '192.168' | grep eth0 | head -n1")

    gateway = None
    if out:
        # 例: 192.168.137.0/24 dev eth0 proto kernel scope link src 192.168.137.2
        parts = out.split()
        if parts:
            net = parts[0]  # 192.168.137.0/24
            gateway = net.split('/')[0]
            gateway = gateway[:-1] + "1"  # 雑に .1 を想定

    # fallback（固定）
    if not gateway:
        gateway = "192.168.137.1"

    _run(f"sudo ip route add default via {gateway} dev eth0 || true")


# =========================================================
# WiFi接続
# =========================================================
def connect_wifi(ssid: str, password: str, timeout: int = 40):

    print("===== WIFI CONNECT START =====")
    print(f"SSID: {ssid}")

    start = time.time()

    while time.time() - start < timeout:

        elapsed = int(time.time() - start)
        print(f"TRY CONNECT... ({elapsed}s)")

        # scan
        _run("sudo nmcli device wifi rescan")
        rc, out = _run("nmcli -t -f SSID,SIGNAL device wifi list")

        if ssid not in out:
            print("SSID NOT FOUND -> RETRY")
            time.sleep(3)
            continue

        print("===== CREATE WIFI CONNECTION =====")

        _run(f"sudo nmcli connection delete {ssid} || true")

        rc, _ = _run(
            f"sudo nmcli connection add type wifi ifname wlan0 con-name {ssid} ssid {ssid}"
        )
        if rc != 0:
            time.sleep(3)
            continue

        rc, _ = _run(
            f"sudo nmcli connection modify {ssid} wifi-sec.key-mgmt wpa-psk wifi-sec.psk {password}"
        )
        if rc != 0:
            time.sleep(3)
            continue

        rc, _ = _run(f"sudo nmcli connection up {ssid}")
        if rc != 0:
            print("CONNECT FAILED -> RETRY")
            time.sleep(3)
            continue

        print("WIFI CONNECT SUCCESS")

        # ============================
        # ★ ここが重要：eth0無効化
        # ============================
        _disable_eth0_default()

        # ネットワーク安定待ち
        for i in range(12):
            print(f"WAIT NETWORK READY... ({i+1}/12)")
            time.sleep(1)

            rc, routes = _run("ip route")
            if "wlan0" in routes:
                print("NETWORK READY")
                return True, "connected"

        print("NETWORK NOT READY -> RETRY")

    print("WIFI TIMEOUT")
    return False, "timeout"


# =========================================================
# インターネットチェック
# =========================================================
def check_internet():

    print("===== INTERNET CHECK START =====")

    for i in range(10):

        print(f"CHECK INTERNET... ({i}s)")

        rc, _ = _run("ping -c 1 -W 1 8.8.8.8")
        if rc == 0:
            rc2, _ = _run("curl -s --max-time 2 https://api.github.com")
            if rc2 == 0:
                print("INTERNET OK")
                return True, "ok"

        time.sleep(1)

    print("INTERNET FAILED")
    return False, "timeout"


# =========================================================
# WiFi切断＋eth0復元
# =========================================================
def disconnect_wifi():

    print("===== WIFI DISCONNECT =====")

    _run("sudo nmcli device disconnect wlan0")

    # ============================
    # ★ eth0復元
    # ============================
    _restore_eth0_default()

    print("===== NETWORK RESTORED =====")