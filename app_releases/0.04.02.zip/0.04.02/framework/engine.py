# framework/engine.py

import os
import time
from pathlib import Path

import sdl2

from framework.renderer import Renderer
from framework.audio_player import AudioPlayer
from framework.video_player import VideoPlayer
from framework.image_viewer import ImageViewer
from framework.screensaver import ScreenSaver
from framework.input_manager import InputManager
from framework.scenes.boot import BootScene

from framework.config.system_config import SystemConfig
from framework.config.game_config import GameConfig
from framework.overlay import Overlay
from framework.input_types import EventType

from hw_platform.io.led_manager import LedManager


class Engine:
    """
    Engine = オーケストレータ

    [解像度方針]
      - Game / Scene / View 側は常に 1920x1080 論理座標で描画する
      - 実ウィンドウ解像度は Engine 側で決定する
      - 接続先解像度が不明な場合は SDL から現在の表示解像度を取得する
      - Renderer 側で logical -> output の letterbox 変換を行う
    """

    LOGICAL_WIDTH = 1920
    LOGICAL_HEIGHT = 1080

    DEFAULT_OUTPUT_WIDTH = 1920
    DEFAULT_OUTPUT_HEIGHT = 1080

    def __init__(self):
        self.running = True

        # --------------------------------------------------
        # Config
        # --------------------------------------------------
        self.system_config = SystemConfig()
        self.game_config = GameConfig()

        # --------------------------------------------------
        # Renderer
        # --------------------------------------------------
        output_w, output_h = self._resolve_output_resolution()

        self.renderer = Renderer(
            width=output_w,
            height=output_h,
            logical_width=self.LOGICAL_WIDTH,
            logical_height=self.LOGICAL_HEIGHT,
        )

        print(
            "RENDERER CONFIG:",
            f"output={output_w}x{output_h}",
            f"logical={self.LOGICAL_WIDTH}x{self.LOGICAL_HEIGHT}",
            f"viewport={self.renderer.get_viewport()}",
        )

        # --------------------------------------------------
        # Subsystems
        # --------------------------------------------------
        self.audio = AudioPlayer()
        self.video = VideoPlayer(self.renderer, self.audio)
        self.image_viewer = ImageViewer(self.renderer)
        self.screensaver = ScreenSaver(self.image_viewer)
        self.input = InputManager()

        self.led = LedManager()

        # ★ Overlayも同一config参照
        self.overlay = Overlay(self)

        self.asset_check = self._check_assets_version()

        self.scene = BootScene(self)

    # --------------------------------------------------
    # Resolution
    # --------------------------------------------------
    def _resolve_output_resolution(self):
        """
        実ウィンドウ解像度を決定する。

        優先順位:
          1. 環境変数 SHISA_OUTPUT_WIDTH / SHISA_OUTPUT_HEIGHT
          2. SDL_GetCurrentDisplayMode(0)
          3. DEFAULT_OUTPUT_WIDTH / DEFAULT_OUTPUT_HEIGHT

        接続先ディスプレイ不明、HDMI/VGA変換、EDID不安定環境を想定し、
        取得失敗時は必ず安全に 1920x1080 へフォールバックする。
        """

        env_resolution = self._read_output_resolution_from_env()
        if env_resolution is not None:
            return env_resolution

        detected_resolution = self._detect_display_resolution()
        if detected_resolution is not None:
            return detected_resolution

        print(
            "DISPLAY RESOLUTION FALLBACK:",
            f"{self.DEFAULT_OUTPUT_WIDTH}x{self.DEFAULT_OUTPUT_HEIGHT}",
        )

        return self.DEFAULT_OUTPUT_WIDTH, self.DEFAULT_OUTPUT_HEIGHT

    def _read_output_resolution_from_env(self):
        env_w = os.environ.get("SHISA_OUTPUT_WIDTH", "").strip()
        env_h = os.environ.get("SHISA_OUTPUT_HEIGHT", "").strip()

        if not env_w and not env_h:
            return None

        if not env_w or not env_h:
            print(
                "OUTPUT RESOLUTION ENV INCOMPLETE:",
                f"SHISA_OUTPUT_WIDTH={env_w or '-'}",
                f"SHISA_OUTPUT_HEIGHT={env_h or '-'}",
                "ignored",
            )
            return None

        try:
            width = int(env_w)
            height = int(env_h)
        except Exception:
            print(
                "OUTPUT RESOLUTION ENV INVALID:",
                f"SHISA_OUTPUT_WIDTH={env_w}",
                f"SHISA_OUTPUT_HEIGHT={env_h}",
                "ignored",
            )
            return None

        if width <= 0 or height <= 0:
            print(
                "OUTPUT RESOLUTION ENV OUT OF RANGE:",
                f"{width}x{height}",
                "ignored",
            )
            return None

        print(f"OUTPUT RESOLUTION FROM ENV: {width}x{height}")
        return width, height

    def _detect_display_resolution(self):
        """
        SDLから現在のディスプレイ解像度を取得する。

        Renderer生成前なので、ここで SDL_INIT_VIDEO だけ先に初期化する。
        Renderer側でも SDL_Init(SDL_INIT_VIDEO) されるが、SDL_Init は同一サブシステムに対して
        複数回呼んでも実用上問題ない。
        """

        try:
            result = sdl2.SDL_InitSubSystem(sdl2.SDL_INIT_VIDEO)
            if result != 0:
                print(
                    "SDL_InitSubSystem VIDEO failed:",
                    sdl2.SDL_GetError(),
                )
                return None

            mode = sdl2.SDL_DisplayMode()

            result = sdl2.SDL_GetCurrentDisplayMode(0, mode)
            if result != 0:
                print(
                    "SDL_GetCurrentDisplayMode failed:",
                    sdl2.SDL_GetError(),
                )
                return None

            width = int(mode.w)
            height = int(mode.h)

            if width <= 0 or height <= 0:
                print(
                    "SDL_GetCurrentDisplayMode invalid size:",
                    f"{width}x{height}",
                )
                return None

            print(f"DETECTED DISPLAY RESOLUTION: {width}x{height}")
            return width, height

        except Exception as e:
            print("DISPLAY RESOLUTION DETECT ERROR:", e)
            return None

    # --------------------------------------------------
    # Asset version check
    # --------------------------------------------------
    def _parse_version_tuple(self, version_str):
        try:
            return tuple(int(p) for p in version_str.strip().split("."))
        except Exception:
            return None

    def _read_product_id(self):
        try:
            path = Path("/opt/shisa/product_id")

            if not path.exists():
                print("PRODUCT ID FILE NOT FOUND: fallback to shisa")
                return "shisa"

            product_id = path.read_text().strip()

            if not product_id:
                print("PRODUCT ID EMPTY: fallback to shisa")
                return "shisa"

            return product_id

        except Exception as e:
            print("READ PRODUCT ID ERROR:", e)
            return "shisa"

    def _read_required_assets_version(self):
        try:
            product_id = self._read_product_id()

            path = Path("/opt/shisa/current/version.txt")
            lines = path.read_text().splitlines()

            key = f"required_assets.{product_id}="

            for line in lines[2:]:
                line = line.strip()

                if line.startswith(key):
                    return line.split("=", 1)[1].strip()

            print(f"REQUIRED ASSETS NOT FOUND FOR PRODUCT: {product_id}")
            return ""

        except Exception as e:
            print("READ REQUIRED ASSETS ERROR:", e)
            return ""

    def _read_current_assets_info(self):
        info = {
            "version": "",
            "product_id": "",
        }

        try:
            path = Path("/opt/shisa/current/assets/version.txt")
            lines = path.read_text().splitlines()

            if lines:
                info["version"] = lines[0].strip()

            for line in lines[2:]:
                line = line.strip()

                if line.startswith("product_id="):
                    info["product_id"] = line.split("=", 1)[1].strip()

            return info

        except Exception as e:
            print("READ CURRENT ASSETS INFO ERROR:", e)
            return info

    def _check_assets_version(self):
        product_id = self._read_product_id()
        required = self._read_required_assets_version()
        current_info = self._read_current_assets_info()

        current = current_info.get("version", "")
        current_product_id = current_info.get("product_id", "")

        result = {
            "ok": True,
            "reason": "",
            "required": required if required else "-",
            "current": current if current else "-",
        }

        if not required:
            result["ok"] = False
            result["reason"] = f"REQUIRED ASSETS NOT FOUND : {product_id}"
            print(f"ASSET CHECK NG: required assets not found for product={product_id}")
            return result

        if not current:
            result["ok"] = False
            result["reason"] = "ASSET VERSION MISSING"
            print("ASSET CHECK NG: current assets version missing")
            return result

        if not current_product_id:
            result["ok"] = False
            result["reason"] = "ASSET PRODUCT ID MISSING"
            print("ASSET CHECK NG: current assets product_id missing")
            return result

        if current_product_id != product_id:
            result["ok"] = False
            result["reason"] = "ASSET PRODUCT ID MISMATCH"
            result["required"] = product_id
            result["current"] = current_product_id
            print(
                "ASSET CHECK NG:",
                f"required_product={product_id}",
                f"current_product={current_product_id}",
            )
            return result

        req_tuple = self._parse_version_tuple(required)
        cur_tuple = self._parse_version_tuple(current)

        if req_tuple is None:
            result["ok"] = False
            result["reason"] = "REQUIRED ASSETS VERSION INVALID"
            print("ASSET CHECK NG: required assets version invalid")
            return result

        if cur_tuple is None:
            result["ok"] = False
            result["reason"] = "CURRENT ASSETS VERSION INVALID"
            print("ASSET CHECK NG: current assets version invalid")
            return result

        if cur_tuple < req_tuple:
            result["ok"] = False
            result["reason"] = "ASSET VERSION TOO OLD"
            print(
                "ASSET CHECK NG:",
                f"product={product_id}",
                f"required={required}",
                f"current={current}",
            )
            return result

        result["ok"] = True
        result["reason"] = "ASSET VERSION OK"
        print(
            "ASSET CHECK OK:",
            f"product={product_id}",
            f"required={required}",
            f"current={current}",
        )
        return result

    # --------------------------------------------------
    # Engine control
    # --------------------------------------------------
    def stop(self):
        self.running = False

    def run(self):
        while self.running and self.scene is not None:

            # -------------------------
            # 1. 入力取得
            # -------------------------
            events = self.input.poll()

            # -------------------------
            # 2. Engineレベル処理
            # -------------------------
            for e in events:
                if e.type == EventType.COIN:
                    self.system_config.insert_coin()
                    self.audio.play("coin")

            # -------------------------
            # 3. Sceneへ渡す
            # -------------------------
            self.scene.set_events(events)

            # -------------------------
            # 4. Scene実行
            # -------------------------
            self.scene = self.scene.run()

            time.sleep(0.001)