# framework/ui/image_loader.py

from PIL import Image
import numpy as np


def load_rgba_image(path):
    img = Image.open(path).convert("RGBA")
    rgba = np.array(img, dtype=np.uint8)
    return rgba, img.width, img.height
