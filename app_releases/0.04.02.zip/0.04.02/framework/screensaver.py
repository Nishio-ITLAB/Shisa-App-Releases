# framework/screensaver.py

import os
import subprocess
from typing import Optional, Callable


ASSET_IMAGE_DIR = "/opt/shisa/current/assets/image/screensaver"

USB_MOUNT_POINT = "/mnt/usb"

USB_SEARCH_DIRS = (
    USB_MOUNT_POINT,
)

SUPPORTED_EXTS = (".jpg", ".jpeg", ".png")

# 画像切り替え時間（秒）
SCREENSAVER_INTERVAL_SECONDS = 60.0


class ScreenSaver:
    """
    スクリーンセーバー制御。

    [仕様]
      - USBメモリ側に jpg/png が見つかった場合は USB側を優先
      - USBが無い、読めない、抜かれた場合は assets 側へfallback
      - USBデバイスは lsblk で動的検出
      - 画像表示自体は ImageViewer に委譲
      - 入力などで poll_callback が True を返したら終了
      - mount/umount 失敗で固まらない
    """

    def __init__(
        self,
        image_viewer,
        asset_image_dir: str = ASSET_IMAGE_DIR,
        usb_search_dirs=USB_SEARCH_DIRS,
        interval: float = SCREENSAVER_INTERVAL_SECONDS,
    ):
        self.image_viewer = image_viewer
        self.asset_image_dir = asset_image_dir
        self.usb_search_dirs = tuple(usb_search_dirs)
        self.interval = float(interval)

    # --------------------------------------------------
    # PUBLIC
    # --------------------------------------------------
    def run(
        self,
        poll_callback: Optional[Callable[[], bool]] = None,
    ) -> bool:
        """
        スクリーンセーバーを開始する。

        Returns:
            True  : 正常終了
            False : 入力検出などにより中断
        """

        try:
            self._mount_usb()

            paths = self._get_screensaver_images()

            if not paths:
                print("ScreenSaver: no images found")
                return True

            print(
                "ScreenSaver:",
                f"{len(paths)} image(s)",
                f"source={self._detect_source(paths)}",
            )

            return self.image_viewer.slideshow(
                paths,
                interval=self.interval,
                loop=True,
                poll_callback=poll_callback,
            )

        except Exception as e:
            print("ScreenSaver: stopped by error:", repr(e))
            return True

    def list_images(self) -> list[str]:
        return self._get_screensaver_images()

    # --------------------------------------------------
    # IMAGE SOURCE
    # --------------------------------------------------
    def _get_screensaver_images(self) -> list[str]:
        """
        USB画像があればUSB優先。
        なければ assets/image/screensaver を使う。
        """

        usb_images = self._find_usb_images()
        if usb_images:
            return usb_images

        return self._find_images_recursive(self.asset_image_dir)

    def _find_usb_images(self) -> list[str]:
        images = []

        for root in self.usb_search_dirs:
            if not os.path.isdir(root):
                continue

            if not os.path.ismount(root):
                continue

            try:
                images.extend(self._find_images_recursive(root))
            except Exception as e:
                print("ScreenSaver USB: scan failed:", repr(e))

        return sorted(set(images))

    def _find_images_recursive(self, directory: str) -> list[str]:
        if not os.path.isdir(directory):
            return []

        images = []

        try:
            walker = os.walk(directory)
        except Exception:
            return []

        for current_dir, dirnames, filenames in walker:
            dirnames[:] = [
                d for d in dirnames
                if not d.startswith(".")
                and d not in ("System Volume Information", "$RECYCLE.BIN")
            ]

            for filename in filenames:
                if filename.startswith("."):
                    continue

                if not filename.lower().endswith(SUPPORTED_EXTS):
                    continue

                path = os.path.join(current_dir, filename)

                try:
                    if os.path.isfile(path):
                        images.append(path)
                except Exception:
                    continue

        return sorted(images)

    # --------------------------------------------------
    # USB MOUNT
    # --------------------------------------------------
    def _mount_usb(self):
        """
        USBを /mnt/usb に再マウントする。

        sudoers 前提:
          pi ALL=(ALL) NOPASSWD: /usr/bin/mount, /usr/bin/umount

        環境によって /bin/mount の場合もあるため which mount で確認。
        """

        mount_point = USB_MOUNT_POINT

        try:
            os.makedirs(mount_point, exist_ok=True)
        except Exception as e:
            print("ScreenSaver USB: mkdir failed:", repr(e))
            return

        # stale mount 対策。
        # USB抜き差しで /dev/sda1 -> /dev/sdb1 などに変わるため、
        # 毎回一度 umount してから現在存在する partition を mount する。
        self._umount_usb()

        for dev in self._list_usb_partitions():
            result = self._run_command(
                ["sudo", "-n", "mount", dev, mount_point],
                timeout=5,
            )

            if result is None:
                continue

            if result.returncode == 0:
                return

            stderr = (result.stderr or "").lower()
            if "already mounted" in stderr:
                return

        # mount失敗時は assets fallback
        return

    def _umount_usb(self):
        result = self._run_command(
            ["sudo", "-n", "umount", USB_MOUNT_POINT],
            timeout=5,
        )

        return result

    def _list_usb_partitions(self) -> list[str]:
        """
        lsblkからUSBストレージ候補のpartitionを取得する。

        方針:
          - /dev/sd* の part のみ対象
          - /dev/mmcblk* はRaspberry PiのSDカードなので除外
          - fstypeは vfat/exfat/ext4/ntfs などを許可
          - mountpointがあっても一旦候補に入れる
        """

        result = self._run_command(
            ["lsblk", "-pnlo", "NAME,TYPE,FSTYPE"],
            timeout=3,
        )

        if result is None or result.returncode != 0:
            return []

        devices = []

        for line in result.stdout.splitlines():
            parts = line.strip().split()

            if len(parts) < 2:
                continue

            name = parts[0]
            typ = parts[1]
            fstype = parts[2].lower() if len(parts) >= 3 else ""

            if typ != "part":
                continue

            if not name.startswith("/dev/sd"):
                continue

            if fstype and fstype not in ("vfat", "exfat", "ext4", "ntfs", "ntfs3"):
                continue

            devices.append(name)

        return sorted(devices)

    def _run_command(self, cmd: list[str], timeout: float = 5.0):
        try:
            return subprocess.run(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=timeout,
            )
        except subprocess.TimeoutExpired:
            print("ScreenSaver USB: command timeout:", " ".join(cmd))
            return None
        except Exception as e:
            print("ScreenSaver USB: command failed:", " ".join(cmd), repr(e))
            return None

    # --------------------------------------------------
    # UTILITY
    # --------------------------------------------------
    def _detect_source(self, paths: list[str]) -> str:
        if not paths:
            return "none"

        first = paths[0]

        for root in self.usb_search_dirs:
            if first.startswith(root.rstrip("/") + "/"):
                return "usb"

        if first.startswith(self.asset_image_dir.rstrip("/") + "/"):
            return "assets"

        return "unknown"