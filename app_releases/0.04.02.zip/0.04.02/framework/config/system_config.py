# framework/config/system_config.py

import json
import os
from pathlib import Path


class SystemConfig:
    """
    システム永続状態管理クラス
    system.json / wifi.json を管理する
    """

    DEFAULT_SYSTEM_DATA = {
        "schema_version": 1,
        "free_play": False,
        "coin_per_credit": 1,
        "coin_total": 0,
        "current_credit": 0,
        "credit_buffer": 0,
    }

    DEFAULT_WIFI_DATA = {
        "schema_version": 1,
        "ssid": "",
        "password": "",
    }

    def __init__(self):
        base_dir = Path(__file__).resolve().parents[4]
        self._persist_dir = base_dir / "persist" / "system"

        self._system_file_path = self._persist_dir / "system.json"
        self._wifi_file_path = self._persist_dir / "wifi.json"

        self._data = {}
        self._wifi_data = {}

        self._persist_dir.mkdir(parents=True, exist_ok=True)

        self._ensure_system_storage()
        self._ensure_wifi_storage()

        self._load_system()
        self._load_wifi()

    # --------------------------------------------------
    # 初期化
    # --------------------------------------------------

    def _ensure_system_storage(self):
        if not self._system_file_path.exists():
            self._data = self.DEFAULT_SYSTEM_DATA.copy()
            self._atomic_save_system()

    def _ensure_wifi_storage(self):
        if not self._wifi_file_path.exists():
            self._wifi_data = self.DEFAULT_WIFI_DATA.copy()
            self._atomic_save_wifi()

    def _load_system(self):
        try:
            with open(self._system_file_path, "r", encoding="utf-8") as f:
                loaded = json.load(f)
        except Exception:
            loaded = {}

        self._data = self.DEFAULT_SYSTEM_DATA.copy()
        self._data.update(loaded)

        if self._data.get("schema_version") != self.DEFAULT_SYSTEM_DATA["schema_version"]:
            self._data["schema_version"] = self.DEFAULT_SYSTEM_DATA["schema_version"]
            self._atomic_save_system()

    def _load_wifi(self):
        try:
            with open(self._wifi_file_path, "r", encoding="utf-8") as f:
                loaded = json.load(f)
        except Exception:
            loaded = {}

        self._wifi_data = self.DEFAULT_WIFI_DATA.copy()
        self._wifi_data.update(loaded)

        if self._wifi_data.get("schema_version") != self.DEFAULT_WIFI_DATA["schema_version"]:
            self._wifi_data["schema_version"] = self.DEFAULT_WIFI_DATA["schema_version"]
            self._atomic_save_wifi()

    def reload(self):
        self._load_system()
        self._load_wifi()

    # --------------------------------------------------
    # 保存（atomic）
    # --------------------------------------------------

    def _atomic_save_system(self):
        tmp_path = self._system_file_path.with_suffix(".json.tmp")

        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump(self._data, f, indent=2)
            f.flush()
            os.fsync(f.fileno())

        os.replace(tmp_path, self._system_file_path)

    def _atomic_save_wifi(self):
        tmp_path = self._wifi_file_path.with_suffix(".json.tmp")

        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump(self._wifi_data, f, indent=2)
            f.flush()
            os.fsync(f.fileno())

        os.replace(tmp_path, self._wifi_file_path)

    # --------------------------------------------------
    # コイン消費
    # --------------------------------------------------

    def consume_credits(self, amount: int):
        if self._data["free_play"]:
            return True

        amount = int(amount)
        if amount <= 0:
            return True

        if self._data["current_credit"] >= amount:
            self._data["current_credit"] -= amount
            self._atomic_save_system()
            return True

        return False

    # --------------------------------------------------
    # system.json 関連
    # --------------------------------------------------

    def is_free_play(self):
        return self._data["free_play"]

    def set_free_play(self, value: bool):
        self._data["free_play"] = bool(value)

        if self._data["free_play"]:
            self._data["credit_buffer"] = 0

        self._atomic_save_system()

    def get_coin_per_credit(self):
        return self._data["coin_per_credit"]

    def set_coin_per_credit(self, value: int):
        if value < 1:
            value = 1

        self._data["coin_per_credit"] = int(value)
        self._data["credit_buffer"] = 0
        self._atomic_save_system()

    def get_coin_total(self):
        return self._data["coin_total"]

    def get_current_credit(self):
        return self._data["current_credit"]

    def insert_coin(self):
        self._data["coin_total"] += 1
        self._data["credit_buffer"] += 1

        if self._data["credit_buffer"] >= self._data["coin_per_credit"]:
            self._data["current_credit"] += 1
            self._data["credit_buffer"] = 0

        self._atomic_save_system()

    def consume_credit(self):
        if self._data["free_play"]:
            return True

        if self._data["current_credit"] > 0:
            self._data["current_credit"] -= 1
            self._atomic_save_system()
            return True

        return False

    def reset_current_credit(self):
        self._data["current_credit"] = 0
        self._data["credit_buffer"] = 0
        self._atomic_save_system()

    def reset_coin_total(self):
        self._data["coin_total"] = 0
        self._atomic_save_system()

    # --------------------------------------------------
    # wifi.json 関連
    # --------------------------------------------------

    def get_wifi_ssid(self):
        return self._wifi_data["ssid"]

    def get_wifi_password(self):
        return self._wifi_data["password"]

    def set_wifi_ssid(self, value: str):
        self._wifi_data["ssid"] = str(value or "")
        self._atomic_save_wifi()

    def set_wifi_password(self, value: str):
        self._wifi_data["password"] = str(value or "")
        self._atomic_save_wifi()

    def get_wifi_config(self):
        return {
            "ssid": self._wifi_data["ssid"],
            "password": self._wifi_data["password"],
        }