# framework/input_manager.py

from typing import List

from hw_platform.io.dart_io import DartIO
from framework.input_types import InputEvent


class InputManager:
    """
    入力統合マネージャ

    責務:
    - Engine から毎フレーム呼ばれる
    - DartIO から InputEvent 群を受け取ってそのまま返す

    注意:
    - ポーリング周期制御は DartIO 側で実施する
    - ここでは余計な間引きをしない
    """

    def __init__(self):
        self.dart_io = DartIO()

    # --------------------------------------------------
    # PUBLIC
    # --------------------------------------------------

    def poll(self) -> List[InputEvent]:
        try:
            return self.dart_io.poll()

        except Exception as e:
            # 入力系で例外が出てもエンジン全体は落とさない
            print("DartIO error:", e)
            return []