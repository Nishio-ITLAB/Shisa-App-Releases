# framework/input_types.py

from dataclasses import dataclass
from enum import Enum, auto
from typing import Optional


# =========================================================
# Event Type
# =========================================================

class EventType(Enum):
    # ---------------------------------
    # Dart board input
    # ---------------------------------
    DART_HIT = auto()
    DART_RELEASED = auto()
    DART_LONG_PRESS = auto()
    DART_LONG_PRESS_RELEASED = auto()

    # ---------------------------------
    # Button input
    # ---------------------------------
    BUTTON_PRESSED = auto()
    BUTTON_RELEASED = auto()
    BUTTON_LONG_PRESS = auto()
    BUTTON_LONG_PRESS_RELEASED = auto()

    # ---------------------------------
    # Other input
    # ---------------------------------
    MISS = auto()
    COIN = auto()


# =========================================================
# Button
# =========================================================

class ButtonType(Enum):
    ENTER = auto()
    CANCEL = auto()

    NAV_UP = auto()
    NAV_DOWN = auto()
    NAV_LEFT = auto()
    NAV_RIGHT = auto()

    SERVICE = auto()


# =========================================================
# Dart
# =========================================================

class DartRing(Enum):
    INNER_SINGLE = auto()
    TRIPLE = auto()
    OUTER_SINGLE = auto()
    DOUBLE = auto()
    OUTER_BULL = auto()
    INNER_BULL = auto()


@dataclass
class DartHit:
    """
    ダーツ盤判定結果

    number:
        1〜20、Bull系は None

    ring:
        シングル/ダブル/トリプル/ブル種別
    """
    number: Optional[int]
    ring: DartRing


@dataclass
class DartMatrixState:
    """
    生のダーツ盤入力状態

    D_MODE に応じた盤面判定ロジックへ渡すための
    生スナップショット情報を保持する。

    active_sis:
        アクティブ(LOW)だった SI番号のタプル
        例: (3, 17)

    d_mode_high:
        True  -> D_MODE = HIGH
        False -> D_MODE = LOW
    """
    active_sis: tuple[int, ...]
    d_mode_high: bool


# =========================================================
# Unified Input Event
# =========================================================

@dataclass
class InputEvent:
    """
    統一入力イベント

    payload の想定:
    - BUTTON_*                  -> ButtonType
    - DART_HIT                  -> DartHit
    - DART_RELEASED             -> DartMatrixState
    - DART_LONG_PRESS           -> DartMatrixState または DartHit
    - DART_LONG_PRESS_RELEASED  -> DartMatrixState または DartHit
    - MISS                      -> None
    - COIN                      -> None
    """
    type: EventType
    payload: Optional[object]
    timestamp: float