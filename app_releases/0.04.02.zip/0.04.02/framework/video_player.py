# framework/video_player.py

import os
import time
import av


VIDEO_DIR = "/opt/shisa/current/assets/video"


class VideoPlayer:

    def __init__(self, renderer, audio_player):
        self.renderer = renderer
        self.audio = audio_player

    # --------------------------------------------------
    # PUBLIC
    # --------------------------------------------------
    def play_with_intro(self, name, black_seconds=2.0, poll_callback=None):

        path = os.path.join(VIDEO_DIR, f"{name}.mp4")
        if not os.path.exists(path):
            print("Video not found:", path)
            return

        # ① 黒画演出（旧互換：draw_solid が swap までやる）
        t0 = time.time()
        while time.time() - t0 < black_seconds:
            if poll_callback is not None:
                if poll_callback():
                    return

            self.renderer.draw_solid(0.0, 0.0, 0.0)
            time.sleep(0.01)

        # ② 動画オープン
        container = av.open(path)
        stream = container.streams.video[0]
        stream.thread_type = "AUTO"

        frame_iter = container.decode(stream)

        try:
            first = next(frame_iter)
        except StopIteration:
            container.close()
            return

        # ---- PTS同期準備 ----
        time_base = stream.time_base
        start_pts = first.pts if first.pts is not None else 0
        wall_start = time.perf_counter()

        # ③ 最初のフレーム描画（旧互換：blit_rgba_frame が swap までやる）
        img = first.to_ndarray(format="rgba")
        self.renderer.blit_rgba_frame(first.width, first.height, img)

        # ④ 音開始（映像表示と同タイミング）
        audio_name = f"video_{name}"
        self.audio.play(audio_name)

        # ⑤ 残りフレーム
        for frame in frame_iter:

            if poll_callback is not None:
                if poll_callback():
                    container.close()
                    return

            # PTS同期
            if frame.pts is not None:
                target_time = wall_start + float((frame.pts - start_pts) * time_base)
                now = time.perf_counter()
                sleep_time = target_time - now
                if sleep_time > 0:
                    time.sleep(sleep_time)

            img = frame.to_ndarray(format="rgba")
            self.renderer.blit_rgba_frame(frame.width, frame.height, img)

        container.close()
