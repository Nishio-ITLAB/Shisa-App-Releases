# framework/image_viewer.py

import os
import time
from typing import Iterable, Optional, Callable

import numpy as np
from PIL import Image


IMAGE_DIR = "/opt/shisa/current/assets/image"


class ImageViewer:
    """
    静止画表示クラス。

    [方針]
      - jpg / jpeg / png を読む
      - renderer の logical_width x logical_height に aspect-fit で合成
      - 余白は黒
      - renderer.blit_rgba_frame() に RGBA numpy 配列を渡す
      - blit_rgba_frame() は swap 内包前提
    """

    SUPPORTED_EXTS = (".jpg", ".jpeg", ".png")

    def __init__(self, renderer, image_dir: str = IMAGE_DIR):
        self.renderer = renderer
        self.image_dir = image_dir

    # --------------------------------------------------
    # PUBLIC
    # --------------------------------------------------
    def show(
        self,
        path: str,
        seconds: Optional[float] = None,
        poll_callback: Optional[Callable[[], bool]] = None,
    ) -> bool:
        """
        画像を1枚表示する。

        Returns:
            True  : 正常表示完了
            False : poll_callback により中断、または読み込み失敗
        """

        if not os.path.exists(path):
            print("Image not found:", path)
            return False

        try:
            frame = self._load_as_logical_rgba(path)
        except Exception as e:
            print("Image load failed:", path, e)
            return False

        h, w = frame.shape[:2]
        self.renderer.blit_rgba_frame(w, h, frame)

        if seconds is None:
            return True

        t0 = time.time()
        while time.time() - t0 < seconds:
            if poll_callback is not None:
                if poll_callback():
                    return False
            time.sleep(0.01)

        return True

    def show_by_name(
        self,
        name: str,
        seconds: Optional[float] = None,
        poll_callback: Optional[Callable[[], bool]] = None,
    ) -> bool:
        """
        assets/image 配下の画像を名前指定で表示する。

        例:
            show_by_name("logo")
            show_by_name("default.png")
        """

        path = self._resolve_name(name)
        if path is None:
            print("Image not found by name:", name)
            return False

        return self.show(path, seconds=seconds, poll_callback=poll_callback)

    def slideshow(
        self,
        paths: Iterable[str],
        interval: float = 10.0,
        loop: bool = True,
        poll_callback: Optional[Callable[[], bool]] = None,
    ) -> bool:
        """
        複数画像を順番に表示する。

        Returns:
            True  : 正常終了
            False : poll_callback により中断、または画像なし
        """

        paths = list(paths)
        if not paths:
            print("No images for slideshow")
            return False

        while True:
            for path in paths:
                ok = self.show(
                    path,
                    seconds=interval,
                    poll_callback=poll_callback,
                )

                if not ok:
                    return False

            if not loop:
                break

        return True

    def slideshow_from_dir(
        self,
        directory: Optional[str] = None,
        interval: float = 10.0,
        loop: bool = True,
        poll_callback: Optional[Callable[[], bool]] = None,
    ) -> bool:
        """
        ディレクトリ内の jpg/png を順番表示する。
        """

        if directory is None:
            directory = self.image_dir

        paths = self.list_images(directory)

        return self.slideshow(
            paths,
            interval=interval,
            loop=loop,
            poll_callback=poll_callback,
        )

    def list_images(self, directory: Optional[str] = None) -> list[str]:
        """
        指定ディレクトリ内の対応画像一覧を返す。
        """

        if directory is None:
            directory = self.image_dir

        if not os.path.isdir(directory):
            print("Image directory not found:", directory)
            return []

        files = []

        for name in sorted(os.listdir(directory)):
            path = os.path.join(directory, name)

            if not os.path.isfile(path):
                continue

            if name.lower().endswith(self.SUPPORTED_EXTS):
                files.append(path)

        return files

    # --------------------------------------------------
    # INTERNAL
    # --------------------------------------------------
    def _resolve_name(self, name: str) -> Optional[str]:
        """
        拡張子あり/なしの名前指定を解決する。
        """

        if os.path.isabs(name):
            return name if os.path.exists(name) else None

        base, ext = os.path.splitext(name)

        if ext:
            path = os.path.join(self.image_dir, name)
            return path if os.path.exists(path) else None

        for candidate_ext in self.SUPPORTED_EXTS:
            path = os.path.join(self.image_dir, base + candidate_ext)
            if os.path.exists(path):
                return path

        return None

    def _load_as_logical_rgba(self, path: str) -> np.ndarray:
        """
        画像を renderer の logical canvas サイズへ aspect-fit 合成する。
        """

        logical_w, logical_h = self.renderer.get_logical_size()

        with Image.open(path) as img:
            img = img.convert("RGBA")

            src_w, src_h = img.size
            if src_w <= 0 or src_h <= 0:
                raise ValueError("Invalid image size")

            scale = min(logical_w / src_w, logical_h / src_h)

            dst_w = max(1, int(round(src_w * scale)))
            dst_h = max(1, int(round(src_h * scale)))

            img = img.resize((dst_w, dst_h), Image.LANCZOS)

            canvas = Image.new("RGBA", (logical_w, logical_h), (0, 0, 0, 255))

            x = (logical_w - dst_w) // 2
            y = (logical_h - dst_h) // 2

            canvas.paste(img, (x, y), img)

            return np.asarray(canvas, dtype=np.uint8)