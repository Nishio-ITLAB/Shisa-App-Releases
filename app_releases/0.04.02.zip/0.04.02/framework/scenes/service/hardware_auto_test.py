# framework/scenes/service/hardware_auto_test.py

import time
import RPi.GPIO as GPIO
from smbus2 import SMBus

from hw_platform.io.mcp23017 import MCP23017
from hw_platform.io.tca9555 import TCA9555


class HardwareAutoTest:

    def __init__(self):

        self.running = False
        self.stage = "IDLE"

        self.log = []
        self.fail = 0
        self.finish_time = None

        bus = SMBus(1)

        self.mcp20 = MCP23017(bus, 0x20)
        self.mcp21 = MCP23017(bus, 0x21)

        self.tca22 = TCA9555(bus, 0x22)
        self.tca23 = TCA9555(bus, 0x23)
        self.tca24 = TCA9555(bus, 0x24)

        self._mcp21_gpio_b = 0

        # ----------------------------
        # COIN POWER GPIO
        # ----------------------------

        self.COIN_POWER_GPIO = 9

        GPIO.setmode(GPIO.BCM)
        GPIO.setup(self.COIN_POWER_GPIO, GPIO.OUT)

        # COINVcheck : ADDR23 P03
        self.coinv_input = ("tca23", 0, 3)

        # COIN : ADDR21 B7
        self.coin_input = ("mcp21", "B", 7)

        # COINcheck : ADDR24 P10 = port1 bit0
        self.coin_check = ("tca24", 1, 0)

        # --------------------------------------------------
        # SI
        # --------------------------------------------------

        self.si_tests = [

            ("SI1", ("tca23", 0, 4), ("mcp21", "B", 0)),
            ("SI2", ("tca23", 0, 5), ("mcp21", "B", 1)),
            ("SI3", ("tca23", 0, 7), ("mcp21", "A", 0)),
            ("SI4", ("tca23", 0, 6), ("mcp21", "A", 1)),
            ("SI5", ("tca23", 1, 7), ("mcp21", "A", 3)),
            ("SI6", ("tca23", 1, 6), ("mcp21", "A", 2)),
            ("SI7", ("tca23", 1, 4), ("mcp21", "A", 4)),
            ("SI8", ("tca23", 1, 5), ("mcp21", "A", 5)),
            ("SI9", ("tca23", 1, 3), ("mcp21", "A", 7)),
            ("SI10", ("tca23", 1, 2), ("mcp21", "A", 6)),

            ("SI11", ("tca23", 1, 0), ("mcp20", "B", 7)),
            ("SI12", ("tca23", 1, 1), ("mcp20", "B", 6)),
            ("SI13", ("tca22", 0, 0), ("mcp20", "B", 4)),
            ("SI14", ("tca22", 0, 1), ("mcp20", "B", 5)),
            ("SI15", ("tca22", 0, 3), ("mcp20", "B", 3)),
            ("SI16", ("tca22", 0, 2), ("mcp20", "B", 2)),
            ("SI17", ("tca22", 0, 4), ("mcp20", "B", 0)),
            ("SI18", ("tca22", 0, 5), ("mcp20", "B", 1)),
            ("SI19", ("tca22", 1, 6), ("mcp20", "A", 0)),
            ("SI20", ("tca22", 1, 7), ("mcp20", "A", 1)),
            ("SI21", ("tca22", 1, 5), ("mcp20", "A", 3)),
            ("SI22", ("tca22", 1, 4), ("mcp20", "A", 2)),
            ("SI23", ("tca22", 1, 3), ("mcp20", "A", 7)),
            ("SI24", ("tca22", 1, 2), ("mcp20", "A", 6)),
            ("SI25", ("tca22", 1, 1), ("mcp20", "A", 4)),
            ("SI26", ("tca22", 1, 0), ("mcp20", "A", 5)),
        ]

        # --------------------------------------------------
        # SHOCK
        # --------------------------------------------------

        self.shock_tests = [
            ("SHOCK1", 5),
            ("SHOCK2", 4),
            ("SHOCK3", 3),
            ("SHOCK4", 2),
        ]

        # --------------------------------------------------
        # BTN
        # --------------------------------------------------

        self.btn_tests = [

            ("BTN1", ("tca24", 1, 2), ("tca24", 1, 1)),
            ("BTN2", ("tca24", 1, 5), ("tca24", 1, 4)),
            ("BTN3", ("tca24", 0, 7), ("tca24", 1, 7)),
            ("BTN4", ("tca24", 0, 4), ("tca24", 0, 5)),
            ("BTN5", ("tca24", 0, 1), ("tca24", 0, 2)),
            ("BTN6", ("tca23", 0, 1), ("tca23", 0, 0)),
        ]

    # --------------------------------------------------

    def start(self):

        self.running = True
        self.stage = "LED"
        self.fail = 0
        self.finish_time = None
        self.log.clear()

        self.log.append("AUTO TEST START")

    # --------------------------------------------------

    def update(self):

        if not self.running:

            if self.finish_time:
                if time.time() - self.finish_time > 3:
                    self.log.clear()
                    self.finish_time = None

            return

        # --------------------------------------------------
        # LED
        # --------------------------------------------------

        if self.stage == "LED":

            self._set_all_led(True)
            self.log.append("LED ON")

            time.sleep(0.05)

            self._set_all_led(False)
            self.log.append("LED OFF")

            self._set_all_led(True)

            self.stage = "SI"
            self.log.append("STEP SI")
            return

        # --------------------------------------------------
        # SI
        # --------------------------------------------------

        if self.stage == "SI":

            for _, check, _ in self.si_tests:
                self._set_tca_check(*check, False)

            time.sleep(0.01)

            m20a, m20b = self.mcp20.read_gpio()
            m21a, m21b = self.mcp21.read_gpio()

            for name, _, inputp in self.si_tests:

                if not self._read_from_snapshot(inputp, m20a, m20b, m21a, m21b):
                    self.log.append(f"[NG] {name} STUCK")
                    self.fail += 1

            for _, check, _ in self.si_tests:
                self._set_tca_check(*check, True)

            time.sleep(0.01)

            m20a, m20b = self.mcp20.read_gpio()
            m21a, m21b = self.mcp21.read_gpio()

            for name, _, inputp in self.si_tests:

                if self._read_from_snapshot(inputp, m20a, m20b, m21a, m21b):
                    self.log.append(f"[NG] {name} NO RESPONSE")
                    self.fail += 1

            for _, check, _ in self.si_tests:
                self._set_tca_check(*check, False)

            time.sleep(0.01)

            m20a, m20b = self.mcp20.read_gpio()
            m21a, m21b = self.mcp21.read_gpio()

            for name, _, inputp in self.si_tests:

                if not self._read_from_snapshot(inputp, m20a, m20b, m21a, m21b):
                    self.log.append(f"[NG] {name} NO RELEASE")
                    self.fail += 1
                else:
                    self.log.append(f"{name} OK")

            self.stage = "SHOCK"
            self.log.append("STEP SHOCK")
            return

        # --------------------------------------------------
        # SHOCK
        # --------------------------------------------------

        if self.stage == "SHOCK":

            for name, bit in self.shock_tests:

                self._set_shock(bit, True)

                time.sleep(0.01)

                if not self._read_mcp_low("mcp21", "B", 6):
                    self.log.append(f"[NG] {name} NO RESPONSE")
                    self.fail += 1

                self._set_shock(bit, False)

                time.sleep(0.01)

                if not self._read_mcp_high("mcp21", "B", 6):
                    self.log.append(f"[NG] {name} NO RELEASE")
                    self.fail += 1
                else:
                    self.log.append(f"{name} OK")

            self.stage = "BTN"
            self.log.append("STEP BTN")
            return

        # --------------------------------------------------
        # BTN
        # --------------------------------------------------

        if self.stage == "BTN":

            for name, check, inputp in self.btn_tests:

                if not self._read_tca_high(*inputp):
                    self.log.append(f"[NG] {name} STUCK")
                    self.fail += 1
                    continue

                self._set_tca_check(*check, True)

                time.sleep(0.01)

                if not self._read_tca_low(*inputp):
                    self.log.append(f"[NG] {name} NO RESPONSE")
                    self.fail += 1

                self._set_tca_check(*check, False)

                time.sleep(0.01)

                if not self._read_tca_high(*inputp):
                    self.log.append(f"[NG] {name} NO RELEASE")
                    self.fail += 1
                else:
                    self.log.append(f"{name} OK")

            self.stage = "COINV"
            self.log.append("STEP COINV")
            return

        # --------------------------------------------------
        # COINV
        # --------------------------------------------------

        if self.stage == "COINV":

            GPIO.output(self.COIN_POWER_GPIO, GPIO.LOW)

            time.sleep(0.02)

            if not self._read_tca_high(*self.coinv_input):
                self.log.append("[NG] COINV NO OFF")
                self.fail += 1

            GPIO.output(self.COIN_POWER_GPIO, GPIO.HIGH)

            time.sleep(0.02)

            if not self._read_tca_low(*self.coinv_input):
                self.log.append("[NG] COINV NO ON")
                self.fail += 1
            else:
                self.log.append("COINV OK")

            self.stage = "COIN"
            self.log.append("STEP COIN")
            return

        # --------------------------------------------------
        # COIN
        # --------------------------------------------------

        if self.stage == "COIN":

            if not self._read_mcp_high(*self.coin_input):
                self.log.append("[NG] COIN STUCK")
                self.fail += 1

            self._set_tca_check(*self.coin_check, True)

            time.sleep(0.01)

            if not self._read_mcp_low(*self.coin_input):
                self.log.append("[NG] COIN NO RESPONSE")
                self.fail += 1

            self._set_tca_check(*self.coin_check, False)

            time.sleep(0.01)

            if not self._read_mcp_high(*self.coin_input):
                self.log.append("[NG] COIN NO RELEASE")
                self.fail += 1
            else:
                self.log.append("COIN OK")

            self.running = False
            self.finish_time = time.time()

            if self.fail == 0:
                self.log.append("TEST PASS")
            else:
                self.log.append(f"TEST FAIL {self.fail}")

    # --------------------------------------------------

    def _set_all_led(self, state):

        self.tca23.set_bit(0, 2, state)

        self.tca24.set_bit(0, 0, state)
        self.tca24.set_bit(0, 3, state)
        self.tca24.set_bit(0, 6, state)

        self.tca24.set_bit(1, 3, state)
        self.tca24.set_bit(1, 6, state)

    # --------------------------------------------------

    def _read_from_snapshot(self, inputp, m20a, m20b, m21a, m21b):

        dev, port, bit = inputp

        if dev == "mcp20":
            if port == "A":
                return bool(m20a & (1 << bit))
            return bool(m20b & (1 << bit))

        if port == "A":
            return bool(m21a & (1 << bit))

        return bool(m21b & (1 << bit))

    # --------------------------------------------------

    def _read_mcp_high(self, dev, port, bit):

        d = self.mcp20 if dev == "mcp20" else self.mcp21

        a, b = d.read_gpio()

        if port == "A":
            return bool(a & (1 << bit))

        return bool(b & (1 << bit))

    def _read_mcp_low(self, dev, port, bit):

        return not self._read_mcp_high(dev, port, bit)

    # --------------------------------------------------

    def _read_tca_high(self, dev, port, bit):

        d = getattr(self, dev)

        p0, p1 = d.read_inputs()

        if port == 0:
            return bool(p0 & (1 << bit))

        return bool(p1 & (1 << bit))

    def _read_tca_low(self, dev, port, bit):

        return not self._read_tca_high(dev, port, bit)

    # --------------------------------------------------

    def _set_tca_check(self, dev, port, bit, state):

        getattr(self, dev).set_bit(port, bit, state)

    def _set_shock(self, bit, state):

        if state:
            self._mcp21_gpio_b |= (1 << bit)
        else:
            self._mcp21_gpio_b &= ~(1 << bit)

        self.mcp21.bus.write_byte_data(
            self.mcp21.addr,
            self.mcp21.GPIOB,
            self._mcp21_gpio_b
        )