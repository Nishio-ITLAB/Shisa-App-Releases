# framework/scenes/service/root.py

import numpy as np
from PIL import Image, ImageDraw, ImageFont
import os

from framework.scene import Scene
from framework.input_types import EventType, ButtonType


FONT_PATH = "/opt/shisa/current/system_assets/fonts/NotoSansMono-Regular.ttf"


class ServiceRootScene(Scene):

    def __init__(self, engine):
        super().__init__(engine)

        self.r = self.engine.renderer
        self.W = self.r.width
        self.H = self.r.height

        # フォント
        self.title_font_size = int(self.H * 0.08)
        self.menu_font_size = int(self.H * 0.06)

        self.title_font = ImageFont.truetype(FONT_PATH, self.title_font_size)
        self.menu_font = ImageFont.truetype(FONT_PATH, self.menu_font_size)

        # バージョン表示用フォント（追加）
        self.version_font_size = int(self.H * 0.035)
        self.version_font = ImageFont.truetype(FONT_PATH, self.version_font_size)

        ascent_t, descent_t = self.title_font.getmetrics()
        self.title_height = ascent_t + descent_t

        ascent_m, descent_m = self.menu_font.getmetrics()
        self.menu_height = ascent_m + descent_m

        ascent_v, descent_v = self.version_font.getmetrics()
        self.version_height = ascent_v + descent_v

        self.text_cache = {}

        # メニュー順変更済み
        self.menu_items = [
            "SYSTEM",
            "GAME SETTINGS",
        ]

        self.index = 0

        # 枠設定
        self.box_width = int(self.W * 0.5)
        self.box_height = int(self.H * 0.35)
        self.box_radius = 40

        self.box_x = (self.W - self.box_width) // 2
        self.box_y = int(self.H * 0.32)

        self._menu_box_texture = self._create_rounded_box()

        self._panel_cache = {}
        self._outline_cache = {}

        # バージョン取得
        self.version, self.build = self._get_version_info()
        self.assets_version, self.assets_build = self._get_assets_version()

    # --------------------------------------------------
    def _get_version_info(self):
        try:
            with open("/opt/shisa/current/version.txt", "r") as f:
                lines = f.read().splitlines()
                version = lines[0] if len(lines) > 0 else "unknown"
                build = lines[1] if len(lines) > 1 else ""
                return version, build
        except:
            return "unknown", ""

    # --------------------------------------------------
    def _create_rounded_box(self):

        img = Image.new("RGBA", (self.box_width, self.box_height), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        draw.rounded_rectangle(
            [0, 0, self.box_width, self.box_height],
            radius=self.box_radius,
            fill=(20, 20, 20, 220)
        )

        return np.array(img, dtype=np.uint8)

    # --------------------------------------------------
    def _get_text_texture(self, text, font, color):

        key = (text, font.size, color)
        if key in self.text_cache:
            return self.text_cache[key]

        w = int(font.getlength(text))
        ascent, descent = font.getmetrics()
        h = ascent + descent

        img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        draw.text((0, 0), text, font=font, fill=color)

        arr = np.array(img, dtype=np.uint8)
        self.text_cache[key] = (arr, w, h)
        return arr, w, h

    # --------------------------------------------------
    def _get_panel_texture(self, w, h, radius, fill):

        key = (w, h, radius, fill)

        if key not in self._panel_cache:
            img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
            draw = ImageDraw.Draw(img)

            draw.rounded_rectangle(
                [0, 0, w - 1, h - 1],
                radius=radius,
                fill=fill
            )

            self._panel_cache[key] = np.array(img, dtype=np.uint8)

        return self._panel_cache[key]


    def _get_rect_texture(self, w, h, fill):

        key = (w, h, fill)

        if key not in self._outline_cache:
            img = Image.new("RGBA", (w, h), fill)
            self._outline_cache[key] = np.array(img, dtype=np.uint8)

        return self._outline_cache[key]


    def _draw_rect_outline(self, x, y, w, h, color, width=3):

        r = self.r

        top = self._get_rect_texture(w, width, color)
        bottom = top
        left = self._get_rect_texture(width, h, color)
        right = left

        r.ui_draw_texture(x, y, w, width, top)
        r.ui_draw_texture(x, y + h - width, w, width, bottom)
        r.ui_draw_texture(x, y, width, h, left)
        r.ui_draw_texture(x + w - width, y, width, h, right)

    # --------------------------------------------------
    def _get_assets_version(self):
        try:
            with open("/opt/shisa/current/assets/version.txt", "r") as f:
                lines = f.read().splitlines()

            version = lines[0] if len(lines) > 0 else "unknown"
            build = lines[1] if len(lines) > 1 else ""

            return version, build

        except:
            return "unknown", ""

    # --------------------------------------------------
    def _handle_input(self):

        events = self.get_events()

        for e in events:

            if e.type != EventType.BUTTON_PRESSED:
                continue

            if e.payload == ButtonType.NAV_UP:
                self.index = (self.index - 1) % len(self.menu_items)

            elif e.payload == ButtonType.NAV_DOWN:
                self.index = (self.index + 1) % len(self.menu_items)

            elif e.payload == ButtonType.ENTER:

                # 0 = SYSTEM
                if self.index == 0:
                    from framework.scenes.service.system import SystemMenuScene
                    return SystemMenuScene(self.engine)

                # 1 = GAME SETTINGS
                elif self.index == 1:
                    from framework.scenes.service.game_settings import GameSettingsScene
                    return GameSettingsScene(self.engine)

            elif e.payload == ButtonType.CANCEL:
                check = getattr(self.engine, "asset_check", None)

                if check is not None and not check.get("ok", False):
                    from framework.scenes.emergency import EmergencyScene
                    return EmergencyScene(
                        self.engine,
                        reason=check.get("reason", "ASSET VERSION ERROR"),
                        required=check.get("required", "-"),
                        current=check.get("current", "-"),
                    )

                from framework.scenes.menu import MenuScene
                return MenuScene(self.engine)

        return None

    # --------------------------------------------------
    def _draw(self):

        r = self.r

        r.ui_clear(0.0, 0.0, 0.0)

        # タイトル
        title_text = "SERVICE MENU"

        tex_t, w_t, h_t = self._get_text_texture(
            title_text,
            self.title_font,
            (255, 255, 255, 255)
        )

        r.ui_draw_texture(
            (self.W - w_t) // 2,
            int(self.H * 0.15),
            w_t,
            h_t,
            tex_t
        )

        # 枠
        r.ui_draw_texture(
            self.box_x,
            self.box_y,
            self.box_width,
            self.box_height,
            self._menu_box_texture
        )

        # メニュー中央揃え
        spacing = 40

        total_menu_height = (
            len(self.menu_items) * self.menu_height +
            (len(self.menu_items) - 1) * spacing
        )

        start_y = self.box_y + (self.box_height - total_menu_height) // 2

        for i, item in enumerate(self.menu_items):

            y = start_y + i * (self.menu_height + spacing)

            row_w = int(self.box_width * 0.78)
            row_h = self.menu_height + 18
            row_x = self.box_x + (self.box_width - row_w) // 2
            row_y = y - 9

            if i == self.index:
                color = (255, 255, 255, 255)
                fill_color = (70, 0, 0, 185)
                border_color = (255, 80, 80, 255)

                row_tex = self._get_panel_texture(
                    row_w,
                    row_h,
                    10,
                    fill_color
                )

                r.ui_draw_texture(row_x, row_y, row_w, row_h, row_tex)

                self._draw_rect_outline(
                    row_x,
                    row_y,
                    row_w,
                    row_h,
                    border_color,
                    width=3
                )

            else:
                color = (200, 200, 200, 255)

            tex, w, h = self._get_text_texture(
                item,
                self.menu_font,
                color
            )

            x = (self.W - w) // 2
            r.ui_draw_texture(x, y, w, h, tex)

        # --------------------------------------------------
        # バージョン表示
        # --------------------------------------------------
        label_w = 6

        if self.build:
            app_text = f"{'APP'.ljust(label_w)}: {self.version} ({self.build})"
        else:
            app_text = f"{'APP'.ljust(label_w)}: {self.version}"

        if self.assets_build:
            assets_text = f"{'ASSETS'.ljust(label_w)}: {self.assets_version} ({self.assets_build})"
        else:
            assets_text = f"{'ASSETS'.ljust(label_w)}: {self.assets_version}"

        tex_v1, w_v1, h_v1 = self._get_text_texture(
            app_text,
            self.version_font,
            (140, 140, 140, 255)
        )

        tex_v2, w_v2, h_v2 = self._get_text_texture(
            assets_text,
            self.version_font,
            (140, 140, 140, 255)
        )

        x_v1 = (self.W - w_v1) // 2
        x_v2 = (self.W - w_v2) // 2

        y_v = self.box_y + self.box_height + int(self.H * 0.03)

        r.ui_draw_texture(x_v1, y_v, w_v1, h_v1, tex_v1)
        r.ui_draw_texture(x_v2, y_v + h_v1 + 6, w_v2, h_v2, tex_v2)

        self.engine.overlay.draw()
        r.ui_swap()

    # --------------------------------------------------
    def run(self):

        next_scene = self._handle_input()
        self._draw()

        if next_scene is not None:
            return next_scene

        return self