# framework/scenes/service/system.py

import os
import numpy as np
from PIL import Image, ImageDraw, ImageFont

from framework.scene import Scene
from framework.input_types import EventType, ButtonType


FONT_PATH = "/opt/shisa/current/system_assets/fonts/NotoSansMono-Regular.ttf"


class SystemMenuScene(Scene):

    def __init__(self, engine):
        super().__init__(engine)

        self.r = self.engine.renderer
        self.W, self.H = self.r.get_logical_size()

        # フォント
        self.title_font_size = int(self.H * 0.08)
        self.menu_font_size = int(self.H * 0.06)

        self.title_font = ImageFont.truetype(FONT_PATH, self.title_font_size)
        self.menu_font = ImageFont.truetype(FONT_PATH, self.menu_font_size)

        ascent_t, descent_t = self.title_font.getmetrics()
        self.title_height = ascent_t + descent_t

        ascent_m, descent_m = self.menu_font.getmetrics()
        self.menu_height = ascent_m + descent_m

        self.text_cache = {}

        self.menu_items = [
            "HARDWARE TEST",
            "COIN SETTINGS",
            "ONLINE UPDATE",
            "ALL RESET",
            #"VIDEO TEST",
        ]

        self.index = 0

        # 枠設定
        self.box_width = int(self.W * 0.6)
        self.box_height = int(self.H * 0.52)
        self.box_radius = 40

        self.box_x = (self.W - self.box_width) // 2
        self.box_y = int(self.H * 0.26)

        self._menu_box_texture = self._create_rounded_box()

        self._panel_cache = {}
        self._outline_cache = {}

        self.confirm_mode = False
        self.confirm_target = None

    # --------------------------------------------------
    def _create_rounded_box(self):

        img = Image.new("RGBA", (self.box_width, self.box_height), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        draw.rounded_rectangle(
            [0, 0, self.box_width, self.box_height],
            radius=self.box_radius,
            fill=(20, 20, 20, 220)
        )

        return np.array(img, dtype=np.uint8)

    # --------------------------------------------------
    def _get_text_texture(self, text, font, color):

        key = (text, font.size, color)
        if key in self.text_cache:
            return self.text_cache[key]

        w = int(font.getlength(text))
        ascent, descent = font.getmetrics()
        h = ascent + descent

        img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        draw.text((0, 0), text, font=font, fill=color)

        arr = np.array(img, dtype=np.uint8)
        self.text_cache[key] = (arr, w, h)
        return arr, w, h

    # --------------------------------------------------
    def _get_panel_texture(self, w, h, radius, fill):

        key = (w, h, radius, fill)

        if key not in self._panel_cache:
            img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
            draw = ImageDraw.Draw(img)

            draw.rounded_rectangle(
                [0, 0, w - 1, h - 1],
                radius=radius,
                fill=fill
            )

            self._panel_cache[key] = np.array(img, dtype=np.uint8)

        return self._panel_cache[key]


    def _get_rect_texture(self, w, h, fill):

        key = (w, h, fill)

        if key not in self._outline_cache:
            img = Image.new("RGBA", (w, h), fill)
            self._outline_cache[key] = np.array(img, dtype=np.uint8)

        return self._outline_cache[key]


    def _draw_rect_outline(self, x, y, w, h, color, width=3):

        r = self.r

        top = self._get_rect_texture(w, width, color)
        bottom = top
        left = self._get_rect_texture(width, h, color)
        right = left

        r.ui_draw_texture(x, y, w, width, top)
        r.ui_draw_texture(x, y + h - width, w, width, bottom)
        r.ui_draw_texture(x, y, width, h, left)
        r.ui_draw_texture(x + w - width, y, width, h, right)

    # --------------------------------------------------
    def _handle_input(self):

        events = self.get_events()

        for e in events:

            if e.type != EventType.BUTTON_PRESSED:
                continue

            if self.confirm_mode:

                if e.payload == ButtonType.ENTER:
                    if self.confirm_target == "all_reset":
                        self._execute_all_reset()

                    self.confirm_mode = False
                    self.confirm_target = None

                elif e.payload == ButtonType.CANCEL:
                    self.confirm_mode = False
                    self.confirm_target = None

                return None

            if e.payload == ButtonType.NAV_UP:
                self.index = (self.index - 1) % len(self.menu_items)

            elif e.payload == ButtonType.NAV_DOWN:
                self.index = (self.index + 1) % len(self.menu_items)

            elif e.payload == ButtonType.ENTER:

                # 0 = HARDWARE TEST
                if self.index == 0:
                    from framework.scenes.service.hardware_tests import HardwareTestsScene
                    return HardwareTestsScene(self.engine)

                # 1 = COIN SETTINGS
                elif self.index == 1:
                    from framework.scenes.service.coin_settings import CoinSettingsScene
                    return CoinSettingsScene(self.engine)

                # 2 = ONLINE UPDATE
                elif self.index == 2:
                    from framework.scenes.service.online_update import OnlineUpdateScene
                    return OnlineUpdateScene(self.engine)

                # 3 = ALL RESET
                elif self.index == 3:
                    self.confirm_mode = True
                    self.confirm_target = "all_reset"

                # 4 = VIDEO TEST
                #elif self.index == 4:
                #    from framework.scenes.service.video_test import VideoTestScene
                #    return VideoTestScene(self.engine)

            elif e.payload == ButtonType.CANCEL:
                from framework.scenes.service.root import ServiceRootScene
                return ServiceRootScene(self.engine)

        return None

    # --------------------------------------------------
    def _draw(self):

        r = self.r
        r.ui_clear(0.0, 0.0, 0.0)

        # タイトル
        title_text = "SYSTEM MENU"

        tex_t, w_t, h_t = self._get_text_texture(
            title_text,
            self.title_font,
            (255, 255, 255, 255)
        )

        r.ui_draw_texture(
            (self.W - w_t) // 2,
            int(self.H * 0.15),
            w_t,
            h_t,
            tex_t
        )

        # 枠
        r.ui_draw_texture(
            self.box_x,
            self.box_y,
            self.box_width,
            self.box_height,
            self._menu_box_texture
        )

        # メニュー中央配置
        spacing = 40

        total_menu_height = (
            len(self.menu_items) * self.menu_height +
            (len(self.menu_items) - 1) * spacing
        )

        start_y = self.box_y + (self.box_height - total_menu_height) // 2

        for i, item in enumerate(self.menu_items):

            y = start_y + i * (self.menu_height + spacing)

            row_w = int(self.box_width * 0.78)
            row_h = self.menu_height + 18
            row_x = self.box_x + (self.box_width - row_w) // 2
            row_y = y - 9

            if i == self.index:
                color = (255, 255, 255, 255)
                fill_color = (70, 0, 0, 185)
                border_color = (255, 80, 80, 255)

                row_tex = self._get_panel_texture(
                    row_w,
                    row_h,
                    10,
                    fill_color
                )

                r.ui_draw_texture(row_x, row_y, row_w, row_h, row_tex)

                self._draw_rect_outline(
                    row_x,
                    row_y,
                    row_w,
                    row_h,
                    border_color,
                    width=3
                )

            else:
                color = (200, 200, 200, 255)

            tex, w, h = self._get_text_texture(
                item,
                self.menu_font,
                color
            )

            x = (self.W - w) // 2
            r.ui_draw_texture(x, y, w, h, tex)

        # Confirm Dialog
        if self.confirm_mode:

            overlay_w = int(self.W * 0.55)
            overlay_h = int(self.H * 0.32)

            ox = (self.W - overlay_w) // 2
            oy = (self.H - overlay_h) // 2

            img = Image.new("RGBA", (overlay_w, overlay_h), (0, 0, 0, 0))
            draw = ImageDraw.Draw(img)

            draw.rounded_rectangle(
                [0, 0, overlay_w, overlay_h],
                radius=30,
                fill=(0, 0, 0, 230)
            )

            r.ui_draw_texture(ox, oy, overlay_w, overlay_h, np.array(img))

            message = "ALL RESET ?"

            tex_msg, w_msg, h_msg = self._get_text_texture(
                message,
                self.menu_font,
                (255, 255, 255, 255)
            )

            r.ui_draw_texture(
                (self.W - w_msg) // 2,
                oy + 50,
                w_msg,
                h_msg,
                tex_msg
            )

            tex_yes, w_yes, h_yes = self._get_text_texture(
                "ENTER : YES",
                self.menu_font,
                (255, 80, 80, 255)
            )

            tex_no, w_no, h_no = self._get_text_texture(
                "CANCEL : NO",
                self.menu_font,
                (80, 255, 80, 255)
            )

            margin_bottom = 40

            r.ui_draw_texture(
                (self.W - w_yes) // 2,
                oy + overlay_h - (h_yes + h_no + margin_bottom),
                w_yes,
                h_yes,
                tex_yes
            )

            r.ui_draw_texture(
                (self.W - w_no) // 2,
                oy + overlay_h - (h_no + margin_bottom),
                w_no,
                h_no,
                tex_no
            )

        self.engine.overlay.draw()
        r.ui_swap()

    # --------------------------------------------------
    def _execute_all_reset(self):

        paths = [
            "/opt/shisa/persist/games/countup.json",
            "/opt/shisa/persist/games/cricket.json",
            "/opt/shisa/persist/games/zero1.json",
            "/opt/shisa/persist/system/system.json",
            "/opt/shisa/persist/system/wifi.json",
        ]

        for path in paths:
            try:
                if os.path.exists(path):
                    os.remove(path)
            except Exception:
                pass

        # system.json / wifi.json を再生成・再読込
        try:
            self.engine.system_config._ensure_system_storage()
            self.engine.system_config._ensure_wifi_storage()
            self.engine.system_config.reload()
        except Exception:
            pass

        # games/*.json を再生成・再読込
        try:
            self.engine.game_config._ensure_storage()
            self.engine.game_config.reload()
        except Exception:
         pass

    # --------------------------------------------------
    def _draw_confirm_dialog(self):

        r = self.r

        overlay_w = int(self.W * 0.60)
        overlay_h = int(self.H * 0.34)

        ox = (self.W - overlay_w) // 2
        oy = (self.H - overlay_h) // 2

        img = Image.new("RGBA", (overlay_w, overlay_h), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        draw.rounded_rectangle(
            [0, 0, overlay_w, overlay_h],
            radius=30,
            fill=(0, 0, 0, 230)
        )

        r.ui_draw_texture(ox, oy, overlay_w, overlay_h, np.array(img, dtype=np.uint8))

        message = "ALL SETTINGS RESET ?"

        tex_msg, w_msg, h_msg = self._get_text_texture(
            message,
            self.menu_font,
            (255, 255, 255, 255)
        )

        r.ui_draw_texture(
            (self.W - w_msg) // 2,
            oy + 55,
            w_msg,
            h_msg,
            tex_msg
        )

        warn = "DELETE ALL PERSIST JSON FILES"

        tex_warn, w_warn, h_warn = self._get_text_texture(
            warn,
            self.version_font if hasattr(self, "version_font") else self.menu_font,
            (255, 180, 80, 255)
        )

        r.ui_draw_texture(
            (self.W - w_warn) // 2,
            oy + 125,
            w_warn,
            h_warn,
            tex_warn
        )

        tex_yes, w_yes, h_yes = self._get_text_texture(
            "ENTER : YES",
            self.menu_font,
            (255, 80, 80, 255)
        )

        tex_no, w_no, h_no = self._get_text_texture(
            "CANCEL : NO",
            self.menu_font,
            (80, 255, 80, 255)
        )

        margin_bottom = 42

        r.ui_draw_texture(
            (self.W - w_yes) // 2,
            oy + overlay_h - (h_yes + h_no + margin_bottom),
            w_yes,
            h_yes,
            tex_yes
        )

        r.ui_draw_texture(
            (self.W - w_no) // 2,
            oy + overlay_h - (h_no + margin_bottom),
            w_no,
            h_no,
            tex_no
        )

    # --------------------------------------------------
    def run(self):

        next_scene = self._handle_input()
        self._draw()

        if next_scene is not None:
            return next_scene

        return self
