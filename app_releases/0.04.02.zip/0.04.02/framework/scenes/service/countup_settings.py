# framework/scenes/service/countup_settings.py

import numpy as np
from PIL import Image, ImageDraw, ImageFont

from framework.scene import Scene
from framework.input_types import EventType, ButtonType


FONT_PATH = "/opt/shisa/current/system_assets/fonts/NotoSansMono-Regular.ttf"


class CountupSettingsScene(Scene):

    def __init__(self, engine):
        super().__init__(engine)

        self.config = self.engine.game_config

        self.r = self.engine.renderer
        self.W, self.H = self.r.get_logical_size()

        # ----------------------------
        # Font
        # ----------------------------
        self.title_font_size = int(self.H * 0.07)
        self.menu_font_size = int(self.H * 0.052)

        self.title_font = ImageFont.truetype(FONT_PATH, self.title_font_size)
        self.menu_font = ImageFont.truetype(FONT_PATH, self.menu_font_size)

        ascent_m, descent_m = self.menu_font.getmetrics()
        self.menu_height = ascent_m + descent_m

        self.text_cache = {}

        # ----------------------------
        # Menu
        # 設定項目を上、ゲームモードを下に集める
        # ----------------------------
        self.menu_items = [
            {
                "type": "setting",
                "label": "UNDO LIMIT",
                "key": "undo_limit",
                "values": [-1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
            },
            {
                "type": "setting",
                "label": "ROUNDS",
                "key": "rounds",
                "min": 1,
                "max": 20,
                "step": 1,
            },
            {
                "type": "bull",
                "label": "BULL - COUNT-UP",
                "mode_id": "count_up",
            },
            {
                "type": "bull",
                "label": "BULL - CR COUNT-UP",
                "mode_id": "cr_count_up",
            },
            {
                "type": "mode",
                "label": "COUNT-UP MODE",
                "mode_id": "count_up",
            },
            {
                "type": "mode",
                "label": "CR.COUNT-UP MODE",
                "mode_id": "cr_count_up",
            },
        ]

        self.index = 0
        self.spacing = 26
        self.scroll_offset = 0
        self.visible_rows = 6

        # ----------------------------
        # Box
        # ----------------------------
        self.box_width = int(self.W * 0.72)
        self.box_height = int(self.H * 0.62)
        self.box_radius = 40

        self.box_x = (self.W - self.box_width) // 2
        self.box_y = int(self.H * 0.24)

        self._menu_box_texture = self._create_rounded_box()

        self._panel_cache = {}
        self._outline_cache = {}

    # --------------------------------------------------
    def _create_rounded_box(self):

        img = Image.new("RGBA", (self.box_width, self.box_height), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        draw.rounded_rectangle(
            [0, 0, self.box_width, self.box_height],
            radius=self.box_radius,
            fill=(20, 20, 20, 220)
        )

        return np.array(img, dtype=np.uint8)

    # --------------------------------------------------
    def _get_text_texture(self, text, font, color):

        key = (text, font.size, color)

        if key in self.text_cache:
            return self.text_cache[key]

        w = int(font.getlength(text))
        ascent, descent = font.getmetrics()
        h = ascent + descent

        img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        draw.text((0, 0), text, font=font, fill=color)

        arr = np.array(img, dtype=np.uint8)
        self.text_cache[key] = (arr, w, h)

        return arr, w, h

    # --------------------------------------------------
    def _get_panel_texture(self, w, h, radius, fill):

        key = (w, h, radius, fill)

        if key not in self._panel_cache:
            img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
            draw = ImageDraw.Draw(img)

            draw.rounded_rectangle(
                [0, 0, w - 1, h - 1],
                radius=radius,
                fill=fill
            )

            self._panel_cache[key] = np.array(img, dtype=np.uint8)

        return self._panel_cache[key]


    def _get_rect_texture(self, w, h, fill):

        key = (w, h, fill)

        if key not in self._outline_cache:
            img = Image.new("RGBA", (w, h), fill)
            self._outline_cache[key] = np.array(img, dtype=np.uint8)

        return self._outline_cache[key]


    def _draw_rect_outline(self, x, y, w, h, color, width=3):

        r = self.r

        top = self._get_rect_texture(w, width, color)
        bottom = top
        left = self._get_rect_texture(width, h, color)
        right = left

        r.ui_draw_texture(x, y, w, width, top)
        r.ui_draw_texture(x, y + h - width, w, width, bottom)
        r.ui_draw_texture(x, y, width, h, left)
        r.ui_draw_texture(x + w - width, y, width, h, right)

    # --------------------------------------------------
    def _update_scroll(self):

        if self.index < self.scroll_offset:
            self.scroll_offset = self.index

        elif self.index >= self.scroll_offset + self.visible_rows:
            self.scroll_offset = self.index - self.visible_rows + 1

    # --------------------------------------------------
    def _handle_input(self):

        events = self.get_events()

        for e in events:

            if e.type != EventType.BUTTON_PRESSED:
                continue

            if e.payload == ButtonType.NAV_UP:
                self.index = (self.index - 1) % len(self.menu_items)
                self._update_scroll()

            elif e.payload == ButtonType.NAV_DOWN:
                self.index = (self.index + 1) % len(self.menu_items)
                self._update_scroll()

            elif e.payload == ButtonType.NAV_LEFT:
                self._change_current_item(-1)

            elif e.payload == ButtonType.NAV_RIGHT:
                self._change_current_item(1)

            elif e.payload == ButtonType.ENTER:
                self._change_current_item(1)

            elif e.payload == ButtonType.CANCEL:
                from framework.scenes.service.game_settings import GameSettingsScene
                return GameSettingsScene(self.engine)

        return None

    # --------------------------------------------------
    def _change_current_item(self, direction):

        item = self.menu_items[self.index]

        if item["type"] == "mode":
            current = self.config.is_mode_enabled(
                "countup",
                item["mode_id"]
            )
            self.config.set_mode_enabled(
                "countup",
                item["mode_id"],
                not current
            )
            return

        if item["type"] == "bull":
            current = self.config.is_fat_bull(
                "countup",
                item["mode_id"]
            )

            self.config.set_fat_bull(
                "countup",
                item["mode_id"],
                not current
            )
            return

        if item["type"] != "setting":
            return

        settings = self.config.get_settings("countup")
        key = item["key"]
        current = int(settings.get(key, 0))

        # 値リスト方式：UNDO LIMITなど
        if "values" in item:
            values = item["values"]

            if current not in values:
                current_index = 0
            else:
                current_index = values.index(current)

            next_index = (current_index + direction) % len(values)
            next_value = values[next_index]

            self.config.set_setting("countup", key, next_value)
            return

        # min/max方式：ROUNDSなど
        value = current + direction * item.get("step", 1)
        value = max(item["min"], min(item["max"], value))

        self.config.set_setting("countup", key, value)

    # --------------------------------------------------
    def _get_item_value_text(self, item):

        if item["type"] == "mode":
            return "ENABLE" if self.config.is_mode_enabled(
                "countup",
                item["mode_id"]
            ) else "DISABLE"

        if item["type"] == "bull":
            return "FAT" if self.config.is_fat_bull(
                "countup",
                item["mode_id"]
            ) else "SEPARATE"

        if item["type"] == "setting":
            settings = self.config.get_settings("countup")
            value = int(settings.get(item["key"], 0))

            if item["key"] == "undo_limit" and value == -1:
                return "UNLIMITED"

            return str(value)

        return ""

    # --------------------------------------------------
    def _draw_empty(self, r, left_x, start_y):

        tex_l, w_l, h_l = self._get_text_texture(
            "NO SETTINGS",
            self.menu_font,
            (255, 80, 80, 255)
        )

        r.ui_draw_texture(left_x, start_y, w_l, h_l, tex_l)

    # --------------------------------------------------
    def _draw(self):

        r = self.r
        r.ui_clear(0.0, 0.0, 0.0)

        # ----------------------------
        # Title
        # ----------------------------
        title_text = "COUNT-UP SETTINGS"

        tex_t, w_t, h_t = self._get_text_texture(
            title_text,
            self.title_font,
            (255, 255, 255, 255)
        )

        r.ui_draw_texture(
            (self.W - w_t) // 2,
            int(self.H * 0.14),
            w_t,
            h_t,
            tex_t
        )

        # ----------------------------
        # Box
        # ----------------------------
        r.ui_draw_texture(
            self.box_x,
            self.box_y,
            self.box_width,
            self.box_height,
            self._menu_box_texture
        )

        left_x = self.box_x + 90
        right_x = self.box_x + self.box_width - 90

        if not self.menu_items:
            self._draw_empty(r, left_x, self.box_y + 80)
            self.engine.overlay.draw()
            r.ui_swap()
            return

        visible_items = self.menu_items[
            self.scroll_offset:self.scroll_offset + self.visible_rows
        ]

        total_menu_height = (
            len(visible_items) * self.menu_height +
            (len(visible_items) - 1) * self.spacing
        )

        start_y = self.box_y + (self.box_height - total_menu_height) // 2

        for row, item in enumerate(visible_items):

            actual_index = self.scroll_offset + row
            y = start_y + row * (self.menu_height + self.spacing)

            row_w = self.box_width - 100
            row_h = self.menu_height + 18
            row_x = self.box_x + 50
            row_y = y - 9

            if actual_index == self.index:
                color = (255, 255, 255, 255)
                fill_color = (70, 0, 0, 185)
                border_color = (255, 80, 80, 255)

                row_tex = self._get_panel_texture(
                    row_w,
                    row_h,
                    10,
                    fill_color
                )

                r.ui_draw_texture(row_x, row_y, row_w, row_h, row_tex)

                self._draw_rect_outline(
                    row_x,
                    row_y,
                    row_w,
                    row_h,
                    border_color,
                    width=3
                )

            else:
                color = (200, 200, 200, 255)

            tex_l, w_l, h_l = self._get_text_texture(
                item["label"],
                self.menu_font,
                color
            )

            r.ui_draw_texture(left_x, y, w_l, h_l, tex_l)

            value = self._get_item_value_text(item)

            tex_v, w_v, h_v = self._get_text_texture(
                value,
                self.menu_font,
                (255, 255, 255, 255)
            )

            r.ui_draw_texture(
                right_x - w_v,
                y,
                w_v,
                h_v,
                tex_v
            )

        # ----------------------------
        # Scroll hint
        # ----------------------------
        if self.scroll_offset > 0:
            tex_u, w_u, h_u = self._get_text_texture(
                "▲",
                self.menu_font,
                (180, 180, 180, 255)
            )

            r.ui_draw_texture(
                right_x - w_u,
                self.box_y - 22,
                w_u,
                h_u,
                tex_u
            )

        if self.scroll_offset + self.visible_rows < len(self.menu_items):
            tex_d, w_d, h_d = self._get_text_texture(
                "▼",
                self.menu_font,
                (180, 180, 180, 255)
            )

            r.ui_draw_texture(
                right_x - w_d,
                self.box_y + self.box_height - h_d + 12,
                w_d,
                h_d,
                tex_d
            )

        self.engine.overlay.draw()
        r.ui_swap()

    # --------------------------------------------------
    def run(self):

        next_scene = self._handle_input()
        self._draw()

        if next_scene is not None:
            return next_scene

        return self