# framework/scenes/emergency.py

import time
import numpy as np
from PIL import Image, ImageDraw, ImageFont

from framework.scene import Scene
from framework.input_types import EventType, ButtonType


FONT_PATH = "/opt/shisa/current/system_assets/fonts/NotoSansMono-Regular.ttf"


class EmergencyScene(Scene):
    """
    Asset version mismatch / missing 時の復旧専用画面。

    許可する操作:
      - SERVICE button: Service Menu へ遷移

    禁止する操作:
      - 通常ゲーム開始
      - 通常メニュー操作
    """

    def __init__(self, engine, reason="ASSET VERSION ERROR", required="-", current="-"):
        super().__init__(engine)

        self.reason = reason
        self.required = required
        self.current = current

        self.r = self.engine.renderer
        self.W, self.H = self.r.get_logical_size()

        self.title_font = ImageFont.truetype(FONT_PATH, int(self.H * 0.075))
        self.body_font = ImageFont.truetype(FONT_PATH, int(self.H * 0.038))
        self.small_font = ImageFont.truetype(FONT_PATH, int(self.H * 0.030))

        self.text_cache = {}

    def _get_text_texture(self, text, font, color):
        key = (text, font.size, color)

        if key in self.text_cache:
            return self.text_cache[key]

        w = max(1, int(font.getlength(text)))
        ascent, descent = font.getmetrics()
        h = ascent + descent

        img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        draw.text((0, 0), text, font=font, fill=color)

        arr = np.array(img, dtype=np.uint8)
        self.text_cache[key] = (arr, w, h)

        return arr, w, h

    def _draw_text_center(self, text, y, font, color):
        tex, w, h = self._get_text_texture(text, font, color)
        self.r.ui_draw_texture((self.W - w) // 2, y, w, h, tex)
        return h

    def _draw(self):
        r = self.r
        r.ui_clear(0.0, 0.0, 0.0)

        y = int(self.H * 0.16)

        h = self._draw_text_center(
            "SYSTEM ERROR",
            y,
            self.title_font,
            (255, 80, 80, 255)
        )

        y += h + int(self.H * 0.08)

        lines = [
            self.reason,
            "",
            f"APP REQUIRED ASSETS : {self.required}",
            f"CURRENT ASSETS      : {self.current}",
            "",
            "NORMAL GAME START IS DISABLED.",
            "PLEASE OPEN SERVICE MENU.",
            "",
            "PRESS SERVICE BUTTON",
        ]

        for line in lines:
            font = self.body_font if line else self.small_font
            color = (255, 255, 255, 255)

            if "DISABLED" in line or "PLEASE" in line:
                color = (255, 220, 120, 255)

            if "PRESS SERVICE" in line:
                now = time.time()
                blink = int(now * 2) % 2 == 0

                if not blink:
                    y += self.body_font.getmetrics()[0] + self.body_font.getmetrics()[1]
                    y += int(self.H * 0.018)
                    continue

                color = (120, 220, 255, 255)

            h = self._draw_text_center(line, y, font, color)
            y += h + int(self.H * 0.018)

        self.engine.overlay.draw()
        r.ui_swap()

    def _handle_input(self):
        events = self.get_events()

        for e in events:
            if e.type != EventType.BUTTON_PRESSED:
                continue

            if e.payload == ButtonType.SERVICE:
                from framework.scenes.service.root import ServiceRootScene
                return ServiceRootScene(self.engine)

        return None

    def run(self):
        next_scene = self._handle_input()
        self._draw()

        if next_scene is not None:
            return next_scene

        return self
