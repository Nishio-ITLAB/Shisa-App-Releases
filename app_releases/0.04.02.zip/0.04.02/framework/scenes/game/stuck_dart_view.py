# framework/scenes/game/stuck_dart_view.py

import time
import numpy as np
from PIL import Image, ImageDraw


class StuckDartView:

    def __init__(self, renderer, font_manager):

        self.r = renderer
        self.fm = font_manager

        self._panel_cache = {}

    def draw(self, state, W, H):

        if not state.stuck_dart_message:
            return

        if time.time() >= state.stuck_dart_until:
            return

        overlay_w = int(W * 0.72)
        overlay_h = int(H * 0.26)

        ox = (W - overlay_w) // 2
        oy = int(H * 0.34)

        tex = self._get_panel_texture(
            overlay_w,
            overlay_h,
            28,
            (80, 0, 0, 235),
            (255, 80, 80, 255),
            5,
        )

        self.r.ui_draw_texture(ox, oy, overlay_w, overlay_h, tex)

        title = "WARNING"
        tex_title, w_title, h_title = self.fm.get_text_texture(
            title,
            "mono",
            64,
            (255, 80, 80, 255)
        )

        self.r.ui_draw_texture(
            (W - w_title) // 2,
            oy + 32,
            w_title,
            h_title,
            tex_title
        )

        message = state.stuck_dart_message
        lines = message.split("\n")

        base_y = oy + 110
        line_gap = 60

        for i, line in enumerate(lines):

            tex_msg, w_msg, h_msg = self.fm.get_text_texture(
                line,
                "jp",
                48,
                (255, 255, 255, 255)
            )

            self.r.ui_draw_texture(
                (W - w_msg) // 2,
                base_y + i * line_gap,
                w_msg,
                h_msg,
                tex_msg
            )

    def _get_panel_texture(self, w, h, radius, fill, outline, width):

        key = (w, h, radius, fill, outline, width)

        if key not in self._panel_cache:
            img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
            draw = ImageDraw.Draw(img)

            draw.rounded_rectangle(
                [0, 0, w - 1, h - 1],
                radius=radius,
                fill=fill,
                outline=outline,
                width=width
            )

            self._panel_cache[key] = np.array(img, dtype=np.uint8)

        return self._panel_cache[key]