# framework/scenes/game/cutin_view.py

import time
import numpy as np
from PIL import Image, ImageDraw


CUTIN_DURATION_SEC = 1.0


class CutinView:

    def __init__(self, renderer, font_manager):

        self.r = renderer
        self.fm = font_manager

        self._panel_cache = {}

    def draw(self, state, W, H):

        if not getattr(state, "cutin_active", False):
            return

        now = time.time()
        elapsed = now - state.cutin_start_time

        if elapsed >= CUTIN_DURATION_SEC:
            state.cutin_active = False
            return

        progress = elapsed / CUTIN_DURATION_SEC

        player = state.current_player
        player_color = self._get_player_color(player)

        # 0.0-0.2: IN / 0.2-0.7: HOLD / 0.7-1.0: OUT
        if progress < 0.20:
            in_t = progress / 0.20
            slide = self._ease_out(in_t)
            alpha = int(230 * slide)
        elif progress < 0.70:
            slide = 1.0
            alpha = 230
        else:
            out_t = (progress - 0.70) / 0.30
            slide = 1.0
            alpha = int(230 * (1.0 - self._ease_in(out_t)))

        panel_w = int(W * 0.72)
        panel_h = int(H * 0.24)

        target_x = (W - panel_w) // 2
        y = int(H * 0.34)

        # 左からスライドIN
        x = int(-panel_w + (target_x + panel_w) * slide)

        fill = (
            int(player_color[0] * 0.65),
            int(player_color[1] * 0.65),
            int(player_color[2] * 0.65),
            alpha,
        )

        outline = (
            255,
            255,
            255,
            min(180, alpha),
        )

        tex = self._get_panel_texture(
            panel_w,
            panel_h,
            22,
            fill,
            outline,
            4,
        )

        self.r.ui_draw_texture(x, y, panel_w, panel_h, tex)

        # スピードライン
        line_h = 5
        line_tex = self._get_rect_texture(
            panel_w,
            line_h,
            (255, 255, 255, int(alpha * 0.45))
        )

        self.r.ui_draw_texture(
            x,
            y + panel_h - 22,
            panel_w,
            line_h,
            line_tex
        )

        # 表示テキスト
        show_player = getattr(state, "players", 1) > 1

        if show_player:
            main_text = f"PLAYER {player + 1}"
            sub_text = f"ROUND {state.round_no}"
        else:
            main_text = f"ROUND {state.round_no}"
            sub_text = ""

        main_tex, main_w, main_h = self.fm.get_text_texture(
            main_text,
            "mono",
            92,
            (255, 255, 255, alpha)
        )

        main_x = x + (panel_w - main_w) // 2
        main_y = y + 42

        self.r.ui_draw_texture(
            main_x,
            main_y,
            main_w,
            main_h,
            main_tex
        )

        if sub_text:
            sub_tex, sub_w, sub_h = self.fm.get_text_texture(
                sub_text,
                "mono",
                54,
                (255, 255, 255, int(alpha * 0.88))
            )

            self.r.ui_draw_texture(
                x + (panel_w - sub_w) // 2,
                main_y + main_h + 8,
                sub_w,
                sub_h,
                sub_tex
            )

    def _get_player_color(self, player):

        colors = [
            (255, 80, 80),
            (80, 180, 255),
            (80, 255, 140),
            (255, 220, 80),
        ]

        return colors[player % len(colors)]

    def _ease_out(self, t):
        return 1.0 - (1.0 - t) * (1.0 - t)

    def _ease_in(self, t):
        return t * t

    def _get_panel_texture(self, w, h, radius, fill, outline, width):

        key = (w, h, radius, fill, outline, width)

        if key not in self._panel_cache:
            img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
            draw = ImageDraw.Draw(img)

            draw.rounded_rectangle(
                [0, 0, w - 1, h - 1],
                radius=radius,
                fill=fill,
                outline=outline,
                width=width
            )

            self._panel_cache[key] = np.array(img, dtype=np.uint8)

        return self._panel_cache[key]

    def _get_rect_texture(self, w, h, fill):

        key = ("rect", w, h, fill)

        if key not in self._panel_cache:
            img = Image.new("RGBA", (w, h), fill)
            self._panel_cache[key] = np.array(img, dtype=np.uint8)

        return self._panel_cache[key]