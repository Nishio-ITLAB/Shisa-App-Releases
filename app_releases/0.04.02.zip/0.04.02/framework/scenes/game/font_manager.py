# framework/scenes/game/font_manager.py

import numpy as np
from PIL import Image, ImageDraw, ImageFont


FONT_JP = "/opt/shisa/current/assets/fonts/NotoSansJP-Regular.ttf"
FONT_MONO = "/opt/shisa/current/assets/fonts/ChivoMono-VariableFont_wght.ttf"
FONT_MONO_ITALIC = "/opt/shisa/current/assets/fonts/ChivoMono-Italic-VariableFont_wght.ttf"


class FontManager:

    def __init__(self):

        self.cache = {}

        self.fonts = {
            ("jp", 42): ImageFont.truetype(FONT_JP, 42),
            ("jp", 64): ImageFont.truetype(FONT_JP, 64),
            ("mono", 42): ImageFont.truetype(FONT_MONO, 42),
            ("mono_italic", 42): ImageFont.truetype(FONT_MONO_ITALIC, 42),
        }

    def get_font(self, kind, size):

        key = (kind, size)

        if key not in self.fonts:
            if kind == "jp":
                path = FONT_JP
            elif kind == "mono":
                path = FONT_MONO
            else:
                path = FONT_MONO_ITALIC

            self.fonts[key] = ImageFont.truetype(path, size)

        return self.fonts[key]

    def get_text_texture(self, text, kind="jp", size=42, color=(255, 255, 255, 255)):

        key = (text, kind, size, color)

        if key in self.cache:
            return self.cache[key]

        font = self.get_font(kind, size)

        x0, y0, x1, y1 = font.getbbox(text)
        w = max(1, x1 - x0)
        h = max(1, y1 - y0)

        img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        draw.text((-x0, -y0), text, font=font, fill=color)

        tex = np.array(img, dtype=np.uint8)

        self.cache[key] = (tex, w, h)

        return tex, w, h