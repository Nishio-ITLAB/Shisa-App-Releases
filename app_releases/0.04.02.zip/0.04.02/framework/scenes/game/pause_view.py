# framework/scenes/game/pause_view.py

import numpy as np
from PIL import Image, ImageDraw


class PauseView:

    def __init__(self, renderer, font_manager):

        self.r = renderer
        self.fm = font_manager

        self._panel_cache = {}
        self._outline_cache = {}

    def draw(
        self,
        pause_index,
        pause_items,
        pause_confirm_mode,
        pause_confirm_target,
        controller,
        W,
        H
    ):

        self._draw_menu(pause_index, pause_items, controller, W, H)

        if pause_confirm_mode:
            self._draw_confirm(pause_confirm_target, W, H)

    def _draw_menu(self, pause_index, pause_items, controller, W, H):

        r = self.r

        overlay_w = int(W * 0.55)
        overlay_h = int(H * 0.62)

        ox = (W - overlay_w) // 2
        oy = int(H * 0.14)

        tex = self._get_panel_texture(
            overlay_w,
            overlay_h,
            30,
            (35, 35, 35, 255)
        )

        r.ui_draw_texture(ox, oy, overlay_w, overlay_h, tex)

        title = "ゲームオプション"

        # 疑似ボールド
        for dx, dy in [(0, 0), (1, 0), (0, 1), (1, 1)]:
            tex, w, h = self.fm.get_text_texture(
                title,
                "jp",
                64,
                (255, 255, 255, 255)
            )
            r.ui_draw_texture(
                (W - w) // 2 + dx,
                oy + 35 + dy,
                w,
                h,
                tex
            )

        start_y = oy + 200
        line_gap = 60

        for i, item in enumerate(pause_items):

            y_offset = i * line_gap

            item_type = item.get("type")
            label = item.get("label", "")

            color = (220, 220, 220, 255)
            text = label

            if item_type == "toggle_miss":
                value = "ON" if controller.state.count_miss_as_throw else "OFF"
                text = f"{label} : {value}"

            elif item_type == "undo":
                remaining = controller.get_undo_remaining_text()
                text = f"{label}（残り回数：{remaining}）"

                if not controller.can_undo():
                    color = (90, 90, 90, 255)

            elif item_type == "out_option":
                if hasattr(controller.state, "out_option"):
                    value = controller.state.out_option.upper()
                    text = f"{label} : {value}"
                else:
                    text = ""
                    item_type = "empty"

            elif item_type == "quit":
                color = (255, 220, 0, 255)

            elif item_type == "empty":
                text = ""
                color = (90, 90, 90, 100)

            row_x = ox + 50
            row_y = start_y + y_offset - 8
            row_w = overlay_w - 100
            row_h = 54

            if i == pause_index:

                selectable = not (
                    item_type == "empty"
                    or (item_type == "undo" and not controller.can_undo())
                )

                if selectable:
                    color = (255, 255, 255, 255)
                    fill_color = (70, 0, 0, 185)
                    border_color = (255, 80, 80, 255)
                else:
                    color = (120, 120, 120, 255)
                    fill_color = (25, 25, 25, 220)
                    border_color = (120, 120, 120, 255)

                row_tex = self._get_panel_texture(
                    row_w,
                    row_h,
                    10,
                    fill_color
                )

                r.ui_draw_texture(row_x, row_y, row_w, row_h, row_tex)

                self._draw_rect_outline(
                    row_x,
                    row_y,
                    row_w,
                    row_h,
                    border_color,
                    width=3
                )

            if text:
                tex, w, h = self.fm.get_text_texture(text, "jp", 42, color)

                r.ui_draw_texture(
                    ox + 80,
                    start_y + y_offset,
                    w,
                    h,
                    tex
                )

    def _draw_confirm(self, target, W, H):

        r = self.r

        overlay_w = int(W * 0.45)
        overlay_h = int(H * 0.28)

        ox = (W - overlay_w) // 2
        oy = (H - overlay_h) // 2

        tex = self._get_panel_texture(
            overlay_w,
            overlay_h,
            30,
            (20, 20, 20, 245)
        )

        r.ui_draw_texture(ox, oy, overlay_w, overlay_h, tex)

        if target == "undo":
            message = "前の投球に戻しますか？"
        else:
            message = "ゲームを終了しますか？"

        tex, w, h = self.fm.get_text_texture(message, "jp", 42)
        r.ui_draw_texture((W - w) // 2, oy + 45, w, h, tex)

        tex_yes, w_yes, h_yes = self.fm.get_text_texture(
            "ENTER : はい",
            "jp",
            42,
            (255, 80, 80, 255)
        )
        tex_no, w_no, h_no = self.fm.get_text_texture(
            "CANCEL : いいえ",
            "jp",
            42,
            (80, 255, 80, 255)
        )

        r.ui_draw_texture((W - w_yes) // 2, oy + 135, w_yes, h_yes, tex_yes)
        r.ui_draw_texture((W - w_no) // 2, oy + 190, w_no, h_no, tex_no)

    def _draw_rect_outline(self, x, y, w, h, color, width=3):

        r = self.r

        top = self._get_rect_texture(w, width, color)
        bottom = top
        left = self._get_rect_texture(width, h, color)
        right = left

        r.ui_draw_texture(x, y, w, width, top)
        r.ui_draw_texture(x, y + h - width, w, width, bottom)
        r.ui_draw_texture(x, y, width, h, left)
        r.ui_draw_texture(x + w - width, y, width, h, right)

    def _get_rect_texture(self, w, h, fill):

        key = (w, h, fill)

        if key not in self._outline_cache:
            img = Image.new("RGBA", (w, h), fill)
            self._outline_cache[key] = np.array(img, dtype=np.uint8)

        return self._outline_cache[key]

    def _get_panel_texture(self, w, h, radius, fill):

        key = (w, h, radius, fill)

        if key not in self._panel_cache:
            img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
            draw = ImageDraw.Draw(img)

            draw.rounded_rectangle(
                [0, 0, w - 1, h - 1],
                radius=radius,
                fill=fill
            )

            self._panel_cache[key] = np.array(img, dtype=np.uint8)

        return self._panel_cache[key]