# framework/scene.py

class Scene:
    """
    全シーンの基底クラス。
    Engine から毎フレーム run() が呼ばれる。
    """

    def __init__(self, engine):
        self.engine = engine
        self._events = []   # ★ 追加

    # ★ Engineからイベントを受け取る
    def set_events(self, events):
        self._events = events

    # ★ 子クラス用
    def get_events(self):
        return self._events

    def run(self):
        """
        毎フレーム実行。
        次に遷移する Scene を返す。
        基本は self を返す。
        """
        return self
