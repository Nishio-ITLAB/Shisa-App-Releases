# games/cricket/presenter.py

import time


def build_debug_view(state):
    """
    CRICKET stateをデバッグ表示用に左右カラムへ分割する。
    描画はしない。
    """

    undo_limit_text = "UNLIMITED" if state.undo_limit == -1 else str(state.undo_limit)

    if state.stuck_dart_message and time.time() < state.stuck_dart_until:
        stuck_warning = state.stuck_dart_message
    else:
        stuck_warning = None

    if state.waiting_for_throw_collect and time.time() >= state.throw_collect_ready_at:
        collect_message = "矢を抜いてENTERを押してください"
    else:
        collect_message = None

    left_lines = [
        "CRICKET DEBUG STATE",
        "",
        f"mode_id        : {state.mode_id}",
        f"players        : {state.players}",
        f"rounds         : {state.rounds}",
        f"undo_limit     : {undo_limit_text}",
        f"count_miss_as_throw : {state.count_miss_as_throw}",
        f"scores         : {state.scores}",
        f"targets        : {state.targets}",
        f"current_player : {state.current_player + 1}",
        f"round_no       : {state.round_no}",
        f"dart_no        : {state.dart_no}",
        f"finished       : {state.finished}",
        f"winner         : {_format_winner(state)}",
        f"result_reason  : {state.result_reason}",
        f"undo_used      : {state.undo_used}",
        f"can_undo       : {state.last_snapshot is not None}",
        "",
        f"finish_pending : {state.finish_pending}",
        f"pending_awards : {state.pending_awards}",
        f"current_award  : {state.current_award}",
        "",
        f"stuck_warning  : {stuck_warning}",
        f"collect_message: {collect_message}",
    ]

    right_lines = [
        "CRICKET MARKS",
        "",
    ]

    header = "TARGET  " + "  ".join(
        f"P{player_index + 1}"
        for player_index in range(state.players)
    )
    right_lines.append(header)
    right_lines.append("-" * len(header))

    for target in state.targets:
        values = []

        for player_index in range(state.players):
            mark = state.marks[player_index][target]
            values.append(_format_mark_debug(mark))

        right_lines.append(
            f"{_format_target(target):>6}  " + "  ".join(f"{v:>2}" for v in values)
        )

    right_lines.extend([
        "",
        "ROUND SCORES",
        "",
    ])

    for round_index, row in enumerate(state.round_scores):
        round_no = round_index + 1
        scores_text = " / ".join(
            f"P{player_index + 1}:{score}"
            for player_index, score in enumerate(row)
        )
        right_lines.append(f"R{round_no:02d}  {scores_text}")

    right_lines.extend([
        "",
        "RECENT THROWS",
        "",
    ])

    recent_throws = state.throw_history[-8:]

    if not recent_throws:
        right_lines.append("(none)")
    else:
        for t in recent_throws:
            score_text = _format_score_deltas(t.get("score_deltas", []))

            right_lines.append(
                f"R{t['round_no']:02d} "
                f"P{t['player'] + 1} "
                f"D{t['dart_no']} "
                f"{_format_throw(t)} "
                f"M:{t.get('applied_marks', 0)}"
                f"+{t.get('overflow_marks', 0)} "
                f"S:{score_text}"
            )

    return {
        "left": left_lines,
        "right": right_lines,
    }


def build_debug_lines(state):
    """
    互換用。
    古いroot.pyが get_debug_lines() を使っていても一応動くようにする。
    """
    view = build_debug_view(state)
    return view["left"] + ["", "--- RIGHT ---", ""] + view["right"]


def _format_winner(state):
    if state.winner is None:
        return None

    return f"P{state.winner + 1}"


def _format_target(target):
    if target == "BULL":
        return "BULL"

    return str(target)


def _format_mark_debug(mark):
    if mark <= 0:
        return "-"

    if mark == 1:
        return "/"

    if mark == 2:
        return "X"

    return "O"


def _format_score_deltas(score_deltas):
    if not score_deltas:
        return "0"

    non_zero = []

    for player_index, delta in enumerate(score_deltas):
        if delta != 0:
            non_zero.append(f"P{player_index + 1}+{delta}")

    if not non_zero:
        return "0"

    return ",".join(non_zero)


def _format_throw(t):
    if t.get("is_skip"):
        return "SKIP"

    if t.get("is_miss"):
        return "MISS"

    ring = t.get("ring")
    number = t.get("number")
    target = t.get("target")

    if ring == "INNER_BULL":
        return "D-BULL"

    if ring == "OUTER_BULL":
        return "S-BULL"

    if not t.get("valid"):
        if number is None:
            return "INVALID"
        return f"INVALID {number}"

    if ring == "INNER_SINGLE":
        return f"S{number}"

    if ring == "OUTER_SINGLE":
        return f"S{number}"

    if ring == "DOUBLE":
        return f"D{number}"

    if ring == "TRIPLE":
        return f"T{number}"

    if target is not None:
        return str(target)

    return "-"