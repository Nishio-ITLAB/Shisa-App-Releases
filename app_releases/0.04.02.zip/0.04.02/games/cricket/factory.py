# games/cricket/factory.py

from .state import CricketState
from .controller import CricketController


VALID_MODES = {
    "standard",
    "cut_throat",
}

MIN_PLAYERS = 1
MAX_PLAYERS = 4


def create_game(engine, mode_id, players):
    """
    CRICKETゲーム生成入口。
    MenuSceneから呼ばれる。

    - mode_id: "standard" / "cut_throat"
    - players: 1〜4
    """

    if mode_id not in VALID_MODES:
        raise ValueError(f"Unknown cricket mode_id: {mode_id}")

    players = int(players)

    if players < MIN_PLAYERS or players > MAX_PLAYERS:
        raise ValueError(f"Invalid players: {players}")

    settings = engine.game_config.get_settings("cricket")

    rounds = int(settings.get("rounds", 20))
    undo_limit = int(settings.get("undo_limit", 5))

    state = CricketState(
        mode_id=mode_id,
        players=players,
        rounds=rounds,
        undo_limit=undo_limit,
    )

    controller = CricketController(
        engine=engine,
        state=state,
    )

    return controller