# games/cricket/controller.py

import time

from framework.input_types import EventType, ButtonType, DartHit

from .presenter import build_debug_view, build_debug_lines
from . import rules


AWARD_PRE_DELAY_SEC = 0.5
AWARD_INPUT_LOCK_SEC = 7.5
PLAYER_CHANGE_LOCK_SEC = 0.5
AWARD_PLAYER_CHANGE_LOCK_SEC = 0.5
THROW_COLLECT_NOTICE_DELAY_SEC = 0.5
FINISH_DELAY_SEC = 2.0
CLOSE_DELAY_SEC = 0.8


class CricketController:

    def __init__(self, engine, state):
        self.engine = engine
        self.state = state

        now = time.time()

        self.state.throw_collect_confirmed = False
        self.state.start_sequence_active = True
        self.state.start_ready_at = now + THROW_COLLECT_NOTICE_DELAY_SEC

    # --------------------------------------------------
    # Debug / Presenter
    # --------------------------------------------------
    def get_debug_view(self):
        return build_debug_view(self.state)

    def get_debug_lines(self):
        return build_debug_lines(self.state)

    # --------------------------------------------------
    # Input
    # --------------------------------------------------
    def update(self):

        if self.state.close_pending:
            if time.time() >= self.state.close_ready_at:
                self._complete_close_sequence()
            return

        if self.state.pending_award_active:
            if time.time() >= self.state.pending_award_ready_at:
                self.state.pending_award_active = False

                award_played = self._play_award(self.state.pending_awards)
                self.state.pending_awards = []

                if self.state.finish_pending:
                    return

                self._start_throw_collect_wait(award_played)

            return

        if self.state.waiting_for_throw_collect:
            if (
                self.state.throw_collect_confirmed
                and time.time() >= self.state.throw_collect_ready_at
            ):
                self._confirm_throw_collect()
            return

        if self.state.finish_pending:
            if time.time() >= self.state.finish_at:
                self.state.finish_pending = False
                self.state.finished = True
            return

        if not self.state.start_sequence_active:
            return

        if time.time() < self.state.start_ready_at:
            return

        self.state.start_sequence_active = False
        self.state.start_ready_at = 0.0

        self.engine.audio.play("player_change")
        self._start_player_change_cutin()
        self._lock_player_change()

    def handle_event(self, event):

        if self.state.start_sequence_active:
            return

        if self.state.waiting_for_throw_collect:

            if event.type == EventType.BUTTON_PRESSED and event.payload == ButtonType.ENTER:
                self.state.throw_collect_confirmed = True

            if time.time() < self.state.throw_collect_ready_at:
                return

            if self.state.throw_collect_confirmed:
                self._confirm_throw_collect()
                return

            return

        if time.time() < self.state.input_locked_until:
            return

        if event.type == EventType.DART_LONG_PRESS:
            self._handle_dart_long_press(event.payload)
            return

        if event.type == EventType.DART_LONG_PRESS_RELEASED:
            return

        if event.type == EventType.DART_HIT:

            if self.state.waiting_for_throw_collect:
                return

            if self.state.dart_no > 3:
                return

            self._apply_dart_hit(event.payload)
            return

        if event.type == EventType.MISS:

            if self.state.waiting_for_throw_collect:
                return

            if self.state.dart_no > 3:
                return

            self._apply_miss()
            return

        if event.type != EventType.BUTTON_PRESSED:
            return

        if event.payload == ButtonType.ENTER:

            if self.state.dart_no > 3:
                return

            self._apply_skip()

    # --------------------------------------------------
    # Stuck dart warning
    # --------------------------------------------------
    def _handle_dart_long_press(self, payload):

        if isinstance(payload, DartHit):
            message = self._format_dart_hit_message(payload)
        else:
            message = "ダーツが刺さったままです\n盤面から取り外してください"

        self.state.stuck_dart_message = message
        self.state.stuck_dart_until = time.time() + 1.1

    def _clear_stuck_dart_warning(self):
        self.state.stuck_dart_message = None
        self.state.stuck_dart_until = 0.0

    def _format_dart_hit_message(self, hit):

        ring_name = hit.ring.name.replace("_", " ")

        if hit.number is None:
            line1 = f"{ring_name} にダーツが刺さったままです"
        else:
            line1 = f"{ring_name} {hit.number} にダーツが刺さったままです"

        line2 = "盤面から取り外してください"

        return f"{line1}\n{line2}"

    # --------------------------------------------------
    # Throw handling
    # --------------------------------------------------
    def _apply_dart_hit(self, hit):

        if not isinstance(hit, DartHit):
            return

        result = rules.apply_hit(self.state, hit)

        self._play_hit_sound(hit, result)

        self._apply_result(
            result=result,
            hit=hit,
            is_miss=False,
            is_skip=False,
        )

    def _apply_miss(self):

        if not self.state.count_miss_as_throw:
            self.engine.audio.play("miss")
            return

        result = rules.build_miss_result(self.state)

        self._apply_result(
            result=result,
            hit=None,
            is_miss=True,
            is_skip=False,
        )

    def _apply_skip(self):

        result = rules.build_miss_result(self.state)

        self._apply_result(
            result=result,
            hit=None,
            is_miss=False,
            is_skip=True,
        )

    def _apply_result(self, result, hit=None, is_miss=False, is_skip=False):

        if self.state.finished:
            return

        if self.state.round_no > self.state.rounds:
            self._finalize_by_round_limit()
            return

        score_deltas = result.get(
            "score_deltas",
            [0 for _ in range(self.state.players)]
        )

        if is_miss or is_skip:
            self.engine.audio.play("miss")

        self._save_snapshot()

        player_index = self.state.current_player
        round_index = self.state.round_no - 1

        target = result.get("target")

        close_enabled = self.state.players >= 2

        was_all_closed = False
        if close_enabled and target is not None:
            was_all_closed = self._is_target_all_closed(target)

        if target is not None:
            self.state.marks[player_index][target] = result.get(
                "marks_after",
                self.state.marks[player_index][target]
            )

        close_started = False
        if close_enabled and target is not None:
            is_all_closed = self._is_target_all_closed(target)

            if is_all_closed:
                self.state.closed_targets.add(target)

            if is_all_closed and not was_all_closed:
                self._start_close_sequence(target)
                close_started = True

        for i, delta in enumerate(score_deltas):
            self.state.scores[i] += delta
            self.state.round_scores[round_index][i] += delta

        record = rules.build_throw_record(
            state=self.state,
            result=result,
            hit=hit,
            is_miss=is_miss,
            is_skip=is_skip,
        )

        self.state.throw_history.append(record)

        self.state.dart_no += 1

        if self._check_closed_win(player_index):
            self._start_finish_pending(
                winner=player_index,
                reason="closed"
            )
            return

        if self.state.dart_no > 3:
            self.state.throw_collect_confirmed = False

            turn_throws = self._get_current_turn_throws()
            awards = rules.evaluate_turn_awards(turn_throws)

            if close_started:
                self.state.pending_awards_after_close = awards
                return

            if awards:
                self.state.pending_awards = awards
                self.state.pending_award_ready_at = time.time() + AWARD_PRE_DELAY_SEC
                self.state.pending_award_active = True
            else:
                self._start_throw_collect_wait(False)

    def _play_hit_sound(self, hit, result):

        if not result.get("valid", False):
            self.engine.audio.play("miss")
            return

        applied_marks = int(result.get("applied_marks", 0))
        score_deltas = result.get("score_deltas", [])

        has_score = any(delta != 0 for delta in score_deltas)

        # クローズ済みで、全員も閉じていて、ゲーム上何も起きないヒット
        if applied_marks <= 0 and not has_score:
            self.engine.audio.play("miss")
            return

        hit_marks = int(result.get("hit_marks", 0))

        if hit_marks >= 3:
            self.engine.audio.play("cricket_triple")
            return

        if hit_marks == 2:
            self.engine.audio.play("cricket_double")
            return

        if hit_marks == 1:
            self.engine.audio.play("cricket_single")
            return

        self.engine.audio.play("miss")

    # --------------------------------------------------
    # Finish handling
    # --------------------------------------------------
    def _is_target_all_closed(self, target):

        for player in range(self.state.players):
            if self.state.marks[player][target] < 3:
                return False

        return True

    def _start_close_sequence(self, target):

        self.state.close_pending = True
        self.state.close_ready_at = time.time() + CLOSE_DELAY_SEC
        self.state.pending_close_target = target
        self.state.closed_targets.add(target)

    def _complete_close_sequence(self):

        self.engine.audio.play("cricket_close")

        self.state.close_pending = False
        self.state.close_ready_at = 0.0
        self.state.pending_close_target = None

        # 勝利確定待ち中なら、投球回収には進めない
        if self.state.finish_pending:
            return

        # まだ1〜3投目の途中なら、そのまま次投へ進ませる
        if self.state.dart_no <= 3:
            return

        # 3投完了後だけ、クローズ後にアワード or 投球回収へ進む
        awards = self.state.pending_awards_after_close
        self.state.pending_awards_after_close = []

        if awards:
            self.state.pending_awards = awards
            self.state.pending_award_ready_at = time.time() + AWARD_PRE_DELAY_SEC
            self.state.pending_award_active = True
        else:
            self._start_throw_collect_wait(False)

    def _check_closed_win(self, player_index):

        if not rules.is_all_closed(self.state, player_index):
            return False

        return rules.is_score_leader(self.state, player_index)

    def _start_finish_pending(self, winner, reason):

        self.state.winner = winner
        self.state.result_reason = reason

        self.state.waiting_for_throw_collect = False
        self.state.pending_next_player = False
        self.state.throw_collect_confirmed = False

        self.state.finish_pending = True
        self.state.finish_at = time.time() + FINISH_DELAY_SEC

    def _finalize_by_round_limit(self):

        ranking = rules.build_ranking(self.state)

        if not ranking:
            self.state.winner = None
            self.state.result_reason = "round_limit"
            self.state.finished = True
            return

        top_score = ranking[0]["score"]
        top_players = [
            row["player"]
            for row in ranking
            if row["score"] == top_score
        ]

        if len(top_players) == 1:
            self.state.winner = top_players[0]
            self.state.result_reason = "round_limit"
        else:
            self.state.winner = None
            self.state.result_reason = "draw"

        self.state.finished = True

    # --------------------------------------------------
    # Turn / player change
    # --------------------------------------------------
    def _start_throw_collect_wait(self, award_played: bool):

        self.state.throw_collect_blink_immediate = award_played

        if (
            self.state.round_no >= self.state.rounds
            and self.state.current_player >= self.state.players - 1
        ):
            self._start_round_limit_finish_pending()
            return

        self.state.waiting_for_throw_collect = True
        self.state.pending_next_player = True
        self.state.throw_collect_message = None

        now = time.time()

        if award_played:
            if self.state.throw_collect_confirmed:
                self.state.throw_collect_ready_at = time.time()
            else:
                self.state.throw_collect_ready_at = (
                    self.state.input_locked_until + AWARD_PLAYER_CHANGE_LOCK_SEC
                )
        else:
            self.state.input_locked_until = now + PLAYER_CHANGE_LOCK_SEC
            self.state.throw_collect_ready_at = now + PLAYER_CHANGE_LOCK_SEC

    def _start_round_limit_finish_pending(self):

        ranking = rules.build_ranking(self.state)

        if ranking:
            top_score = ranking[0]["score"]
            top_players = [
                row["player"]
                for row in ranking
                if row["score"] == top_score
            ]

            if len(top_players) == 1:
                self.state.winner = top_players[0]
                self.state.result_reason = "round_limit"
            else:
                self.state.winner = None
                self.state.result_reason = "draw"
        else:
            self.state.winner = None
            self.state.result_reason = "round_limit"

        self.state.finish_pending = True
        self.state.finish_at = time.time() + FINISH_DELAY_SEC

    def _confirm_throw_collect(self):

        self.state.waiting_for_throw_collect = False
        self.state.pending_next_player = False
        self.state.throw_collect_message = None
        self.state.throw_collect_ready_at = 0.0
        self.state.throw_collect_blink_immediate = False

        self.state.dart_no = 1
        self._next_player()

        if not self.state.finished:
            self.engine.audio.play("player_change")
            self._start_player_change_cutin()
            self._lock_player_change()

    def _next_player(self):

        if self.state.finished:
            return

        self.state.current_player += 1

        if self.state.current_player >= self.state.players:
            self.state.current_player = 0
            self.state.round_no += 1

        self.state.dart_no = 1

        if self.state.round_no > self.state.rounds:
            self._finalize_by_round_limit()

    def _get_current_turn_throws(self):
        """
        現在プレイヤー・現在ラウンドの投球履歴を取得する。
        基本的に3投分。
        """

        return [
            t for t in self.state.throw_history
            if t["round_no"] == self.state.round_no
            and t["player"] == self.state.current_player
        ][-3:]

    # --------------------------------------------------
    # Award
    # --------------------------------------------------
    def _play_award(self, awards):

        if not awards:
            self.state.current_award = None
            return False

        priority = [
            "white_horse",
            "9_mark",
            "hat_trick",
            "3_in_a_bed",
            "7_mark",
            "5_mark",
        ]

        for award in priority:
            if award in awards:
                self.state.current_award = award

                self.state.input_locked_until = time.time() + AWARD_INPUT_LOCK_SEC

                self.engine.video.play_with_intro(
                    award,
                    black_seconds=2.0,
                    poll_callback=self._poll_award_input
                )

                return True

        self.state.current_award = None
        return False

    def _poll_award_input(self):
        led = getattr(self.engine, "led", None)

        events = self.engine.input.poll()

        for e in events:
            if e.type == EventType.BUTTON_PRESSED and e.payload == ButtonType.ENTER:
                self.state.throw_collect_confirmed = True

                if led is not None:
                    led.restore_button_leds()
                    led.update()

                return True

        if led is not None:
            led.set_enter_blink_only()
            led.update()

        return False

    # --------------------------------------------------
    # Cut-in / lock
    # --------------------------------------------------
    def _start_player_change_cutin(self):

        self.state.cutin_active = True
        self.state.cutin_start_time = time.time()

    def _lock_player_change(self):

        self.state.current_award = None
        self.state.input_locked_until = time.time() + PLAYER_CHANGE_LOCK_SEC

    # --------------------------------------------------
    # Undo
    # --------------------------------------------------
    def _save_snapshot(self):

        self.state.last_snapshot = {
            "scores": self.state.scores.copy(),
            "marks": [
                row.copy() for row in self.state.marks
            ],
            "round_scores": [
                row.copy() for row in self.state.round_scores
            ],
            "throw_history": [
                row.copy() for row in self.state.throw_history
            ],
            "current_player": self.state.current_player,
            "round_no": self.state.round_no,
            "dart_no": self.state.dart_no,
            "finished": self.state.finished,
            "winner": self.state.winner,
            "result_reason": self.state.result_reason,
            "finish_pending": self.state.finish_pending,
            "finish_at": self.state.finish_at,

            "close_pending": self.state.close_pending,
            "close_ready_at": self.state.close_ready_at,
            "pending_close_target": self.state.pending_close_target,
            "pending_awards_after_close": self.state.pending_awards_after_close.copy(),
            "closed_targets": set(self.state.closed_targets),
        }

    def toggle_count_miss_as_throw(self):
        self.state.count_miss_as_throw = not self.state.count_miss_as_throw

    def can_undo(self):
        if self.state.last_snapshot is None:
            return False

        if self.state.undo_limit == -1:
            return True

        return self.state.undo_used < self.state.undo_limit

    def get_undo_remaining_text(self):
        if self.state.undo_limit == -1:
            return "制限なし"

        remaining = self.state.undo_limit - self.state.undo_used
        if remaining < 0:
            remaining = 0

        return f"{remaining}回"

    def undo(self):
        if not self.can_undo():
            self.engine.audio.play("miss")
            return False

        self._undo()
        return True

    def _undo(self):

        if self.state.last_snapshot is None:
            self.engine.audio.play("miss")
            return

        if self.state.undo_limit != -1:
            if self.state.undo_used >= self.state.undo_limit:
                self.engine.audio.play("miss")
                return

        snap = self.state.last_snapshot

        self.state.scores = snap["scores"].copy()
        self.state.marks = [
            row.copy() for row in snap["marks"]
        ]
        self.state.round_scores = [
            row.copy() for row in snap["round_scores"]
        ]
        self.state.throw_history = [
            row.copy() for row in snap["throw_history"]
        ]

        self.state.current_player = snap["current_player"]
        self.state.round_no = snap["round_no"]
        self.state.dart_no = snap["dart_no"]
        self.state.finished = snap["finished"]
        self.state.winner = snap["winner"]
        self.state.result_reason = snap["result_reason"]
        self.state.finish_pending = snap.get("finish_pending", False)
        self.state.finish_at = snap.get("finish_at", 0.0)

        self.state.close_pending = snap.get("close_pending", False)
        self.state.close_ready_at = snap.get("close_ready_at", 0.0)
        self.state.pending_close_target = snap.get("pending_close_target", None)
        self.state.pending_awards_after_close = snap.get(
            "pending_awards_after_close",
            []
        ).copy()
        self.state.closed_targets = set(snap.get("closed_targets", set()))

        self.state.waiting_for_throw_collect = False
        self.state.pending_next_player = False
        self.state.throw_collect_confirmed = False
        self.state.pending_awards = []
        self.state.pending_award_active = False
        self.state.current_award = None

        self.state.last_snapshot = None
        self.state.undo_used += 1

        self.engine.audio.play("cancel")