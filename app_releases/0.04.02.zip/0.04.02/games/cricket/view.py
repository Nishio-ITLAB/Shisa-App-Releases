# games/cricket/view.py

import numpy as np
from PIL import Image, ImageDraw


FONT_MONO = "/opt/shisa/current/assets/fonts/ChivoMono-VariableFont_wght.ttf"


class CricketView:

    def __init__(self, renderer, font_manager, controller):

        self.r = renderer
        self.fm = font_manager
        self.controller = controller

        self.W, self.H = renderer.get_logical_size()

        self.player_colors = [
            (255, 80, 80, 255),
            (80, 180, 255, 255),
            (80, 255, 140, 255),
            (255, 220, 80, 255),
        ]

        self._panel_cache = {}
        self._mark_board_cache_key = None
        self._mark_board_cache_value = None
        self._player_score_cache = {}

        self._mark_texture_cache = {}
        self._round_history_cache_key = None
        self._round_history_cache_value = None

    # --------------------------------------------------
    def draw(self, show_enter_indicator=True):

        state = self.controller.state

        self._draw_mode_name(state)
        self._draw_round_history(state)
        self._draw_mark_board(state)
        self._draw_current_round_throws(state)
        self._draw_player_score_bar(state)

        if show_enter_indicator:
            self._draw_enter_indicator(state)

    # --------------------------------------------------
    def _draw_mode_name(self, state):

        mode_text = self._format_mode_name(state.mode_id)

        x = 60
        y = 40

        tex, w, h = self.fm.get_text_texture(
            mode_text,
            "mono_italic",
            56,
            (230, 230, 230, 255)
        )

        self.r.ui_draw_texture(x, y, w, h, tex)

        line_img = Image.new("RGBA", (w, 3), (200, 200, 200, 200))

        self.r.ui_draw_texture(
            x,
            y + h + 4,
            w,
            3,
            np.array(line_img, dtype=np.uint8)
        )

    # --------------------------------------------------
    def _draw_status_panel(self, state):

        player = state.current_player
        color = self.player_colors[player % len(self.player_colors)]

        x = 60
        y = 130
        panel_w = 520
        panel_h = 170

        self._draw_panel(
            x,
            y,
            panel_w,
            panel_h,
            fill=(18, 18, 18, 255),
            outline=color,
            radius=8,
            width=3
        )

        lines = [
            f"PLAYER {player + 1}",
            f"ROUND {state.round_no:02d} / {state.rounds:02d}",
            f"DART {state.dart_no} / 3",
        ]

        font_size = 42
        line_y = y + 24

        for index, text in enumerate(lines):
            text_color = color if index == 0 else (230, 230, 230, 255)

            tex, w, h = self.fm.get_text_texture(
                text,
                "mono",
                font_size,
                text_color
            )

            self.r.ui_draw_texture(
                x + 28,
                line_y,
                w,
                h,
                tex
            )

            line_y += 48

    # --------------------------------------------------
    def _draw_mark_board(self, state):

        panel_w = 1000
        panel_h = 600
        x = (self.W - panel_w) // 2
        y = 120

        key = (
            state.current_player,
            state.round_no,
            state.dart_no,
            tuple(state.scores),
            tuple(str(t) for t in state.targets if t in state.closed_targets),
            tuple(
                tuple(state.marks[player][target] for target in state.targets)
                for player in range(state.players)
            ),
        )

        if (
            self._mark_board_cache_key == key
            and self._mark_board_cache_value is not None
        ):
            tex, w, h = self._mark_board_cache_value
            self.r.ui_draw_texture(x, y, w, h, tex)
            return

        img = Image.new("RGBA", (panel_w, panel_h), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        target_font = self.fm.get_font("mono", 64)
        score_font = self.fm.get_font("mono", 42)
        label_font = self.fm.get_font("mono", 36)

        # ----------------------------
        # column layout
        # 3P / 1P / TARGET / 2P / 4P
        # ----------------------------
        col_w = 150
        target_w = 170
        gap = 16

        columns = []

        target_x = (panel_w - target_w) // 2

        # 3P / 1P / TARGET / 2P / 4P
        if state.players >= 3:
            columns.append({
                "kind": "player",
                "player": 2,
                "x": target_x - gap - col_w - gap - col_w,
                "w": col_w,
            })

        if state.players >= 1:
            columns.append({
                "kind": "player",
                "player": 0,
                "x": target_x - gap - col_w,
                "w": col_w,
            })

        columns.append({
            "kind": "target",
            "player": None,
            "x": target_x,
            "w": target_w,
        })

        if state.players >= 2:
            columns.append({
                "kind": "player",
                "player": 1,
                "x": target_x + target_w + gap,
                "w": col_w,
            })

        if state.players >= 4:
            columns.append({
                "kind": "player",
                "player": 3,
                "x": target_x + target_w + gap + col_w + gap,
                "w": col_w,
            })

        header_y = 12
        row_start_y = 72
        row_h = 76
        mark_size = 52

        # header
        for col in columns:
            cx = col["x"]
            cw = col["w"]

            if col["kind"] == "target":
                text = "TARGET"
                color = (230, 230, 230, 255)
            else:
                player = col["player"]
                text = f"P{player + 1}"
                color = self.player_colors[player % len(self.player_colors)]

                if player != state.current_player:
                    color = (140, 140, 140, 255)

            tex, tw, th = self._text_to_pil(
                text,
                label_font,
                color
            )
            img.alpha_composite(tex, (cx + (cw - tw) // 2, header_y + 6))

        # rows
        for row_index, target in enumerate(state.targets):

            row_y = row_start_y + row_index * row_h
            is_closed_row = state.players >= 2 and target in state.closed_targets

            # --- 背景グレーダウン + 横線 ---
            if is_closed_row:
                draw.rounded_rectangle(
                    [
                        columns[0]["x"] - 18,
                        row_y + 8,
                        columns[-1]["x"] + columns[-1]["w"] + 18,
                        row_y + row_h - 8,
                    ],
                    radius=8,
                    fill=(45, 45, 45, 180)
                )

                draw.line(
                    [
                        (columns[0]["x"] - 10, row_y + row_h // 2),
                        (columns[-1]["x"] + columns[-1]["w"] + 10, row_y + row_h // 2),
                    ],
                    fill=(130, 130, 130, 220),
                    width=6
                )

            # --- 各列描画 ---
            for col in columns:
                cx = col["x"]
                cw = col["w"]

                # ---------- TARGET列 ----------
                if col["kind"] == "target":

                    if is_closed_row:
                        text_color = (120, 120, 120, 255)
                    else:
                        text_color = (245, 245, 245, 255)

                    text = self._format_target(target)
                    tex, tw, th = self._text_to_pil(
                        text,
                        target_font,
                        text_color
                    )

                    img.alpha_composite(
                        tex,
                        (cx + (cw - tw) // 2, row_y + (row_h - th) // 2)
                    )
                    continue

                # ---------- PLAYER列 ----------
                player = col["player"]
                mark = state.marks[player][target]

                if is_closed_row:
                    # 完全グレー
                    color = (100, 100, 100, 255)
                else:
                    color = self.player_colors[player % len(self.player_colors)]
                    if player != state.current_player:
                        color = (150, 150, 150, 255)

                mark_tex = self._get_mark_texture(
                    mark=mark,
                    size=mark_size,
                    color=color
                )

                img.alpha_composite(
                    Image.fromarray(mark_tex),
                    (
                        cx + (cw - mark_size) // 2,
                        row_y + (row_h - mark_size) // 2
                    )
                )
        # current player frame
        for col in columns:
            if col["kind"] != "player":
                continue

            player = col["player"]
            if player != state.current_player:
                continue

            color = self.player_colors[player % len(self.player_colors)]

            draw.rounded_rectangle(
                [
                    col["x"] - 8,
                    header_y - 8,
                    col["x"] + col["w"] + 8,
                    row_start_y + len(state.targets) * row_h - 4,
                ],
                radius=10,
                outline=color,
                width=4
            )

        tex = np.array(img, dtype=np.uint8)

        self._mark_board_cache_key = key
        self._mark_board_cache_value = (tex, panel_w, panel_h)

        self.r.ui_draw_texture(x, y, panel_w, panel_h, tex)

    # --------------------------------------------------
    def _text_to_pil(self, text, font, color):

        x0, y0, x1, y1 = font.getbbox(text)
        w = max(1, x1 - x0)
        h = max(1, y1 - y0)

        img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        draw.text((-x0, -y0), text, font=font, fill=color)

        return img, w, h    

    # --------------------------------------------------
    def _get_mark_texture(self, mark, size, color):

        key = (
            "cricket_mark",
            mark,
            size,
            color,
        )

        if key in self._mark_texture_cache:
            return self._mark_texture_cache[key]

        img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        line_w = max(4, size // 8)
        pad = size // 6

        if mark <= 0:
            pass

        elif mark == 1:
            # /
            draw.line(
                [
                    (size - pad, pad),
                    (pad, size - pad),
                ],
                fill=color,
                width=line_w
            )

        elif mark == 2:
            # X
            draw.line(
                [
                    (pad, pad),
                    (size - pad, size - pad),
                ],
                fill=color,
                width=line_w
            )
            draw.line(
                [
                    (size - pad, pad),
                    (pad, size - pad),
                ],
                fill=color,
                width=line_w
            )

        else:
            # close = circle + X
            circle_pad = size // 8
            draw.ellipse(
                [
                    circle_pad,
                    circle_pad,
                    size - circle_pad,
                    size - circle_pad,
                ],
                outline=color,
                width=line_w
            )
            draw.line(
                [
                    (pad, pad),
                    (size - pad, size - pad),
                ],
                fill=color,
                width=line_w
            )
            draw.line(
                [
                    (size - pad, pad),
                    (pad, size - pad),
                ],
                fill=color,
                width=line_w
            )

        tex = np.array(img, dtype=np.uint8)
        self._mark_texture_cache[key] = tex

        return tex


    # --------------------------------------------------
    def _draw_current_round_throws(self, state):

        throws = self._get_current_round_throws(state)

        box_w = 250
        box_h = 84
        gap = 30

        total_w = box_w * 3 + gap * 2
        base_x = (self.W - total_w) // 2
        y = int(self.H * 0.70)

        for i in range(3):

            x = base_x + i * (box_w + gap)

            active = i == state.dart_no - 1 and not state.waiting_for_throw_collect
            filled = i < len(throws)

            if filled:
                text = self._format_throw_hit(throws[i])
                border = (230, 230, 230, 255)
                fill = (35, 35, 35, 255)
                text_color = (255, 255, 255, 255)
            else:
                text = str(i + 1)
                border = (90, 90, 90, 255)
                fill = (18, 18, 18, 255)
                text_color = (80, 80, 80, 255)

            if active:
                border = self.player_colors[state.current_player % len(self.player_colors)]

            self._draw_panel(x, y, box_w, box_h, fill, border, radius=8, width=3)

            tex, w, h = self.fm.get_text_texture(
                text,
                "mono_italic",
                36,
                text_color
            )

            self.r.ui_draw_texture(
                x + (box_w - w) // 2,
                y + (box_h - h) // 2,
                w,
                h,
                tex
            )

    # --------------------------------------------------
    def _draw_player_score_bar(self, state):

        players = state.players

        bar_y = int(self.H * 0.82)
        bar_w = self.W - 160
        bar_h = 170

        gap = 24

        layout_slots = {
            1: 2,
            2: 3,
            3: 4,
            4: 4,
        }.get(players, 4)

        box_w = (bar_w - gap * (layout_slots - 1)) // layout_slots
        box_h = bar_h

        total_w = box_w * players + gap * (players - 1)
        bar_x = (self.W - total_w) // 2

        for i in range(players):

            x = bar_x + i * (box_w + gap)
            y = bar_y

            is_current = i == state.current_player
            base_color = self.player_colors[i % len(self.player_colors)]

            if is_current:
                fill = (35, 35, 35, 255)
                outline = base_color
                text_color = (255, 255, 255, 255)
                label_color = base_color
                width = 5
            else:
                fill = (14, 14, 14, 255)
                outline = (55, 55, 55, 255)
                text_color = (95, 95, 95, 255)
                label_color = (80, 80, 80, 255)
                width = 2

            self._draw_panel(
                x,
                y,
                box_w,
                box_h,
                fill=fill,
                outline=outline,
                radius=8,
                width=width
            )

            label = f"PLAYER {i + 1}"
            score = str(state.scores[i])
            closed = self._count_closed_targets(state, i)

            tex, w, h = self.fm.get_text_texture(
                label,
                "mono",
                32,
                label_color
            )

            self.r.ui_draw_texture(
                x + 28,
                y + 22,
                w,
                h,
                tex
            )

            key = (i, score, text_color)

            if key not in self._player_score_cache:
                self._player_score_cache[key] = self.fm.get_text_texture(
                    score,
                    "mono",
                    82,
                    text_color
                )

            tex2, w2, h2 = self._player_score_cache[key]

            self.r.ui_draw_texture(
                x + box_w - w2 - 32,
                y + 58,
                w2,
                h2,
                tex2
            )

            closed_text = f"CLOSED {closed}/{len(state.targets)}"

            tex3, w3, h3 = self.fm.get_text_texture(
                closed_text,
                "mono",
                26,
                label_color
            )

            self.r.ui_draw_texture(
                x + 28,
                y + 138,
                w3,
                h3,
                tex3
            )

    # --------------------------------------------------
    def _draw_round_history(self, state):

        x = 60
        y = 170
        panel_w = 360
        panel_h = 680

        player = state.current_player

        visible_count = 10

        if state.round_no <= visible_count:
            start_round = 1
            end_round = min(state.rounds, visible_count)
        else:
            end_round = state.round_no
            start_round = end_round - visible_count + 1

        history_key = (
            player,
            state.round_no,
            start_round,
            end_round,
            tuple(
                state.round_scores[i][player] if i < len(state.round_scores) else 0
                for i in range(start_round - 1, end_round)
            ),
        )

        if (
            self._round_history_cache_key == history_key
            and self._round_history_cache_value is not None
        ):
            tex, w, h = self._round_history_cache_value
            self.r.ui_draw_texture(x, y, w, h, tex)
            return

        img = Image.new("RGBA", (panel_w, panel_h), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        draw.rounded_rectangle(
            [0, 0, panel_w - 1, panel_h - 1],
            radius=8,
            fill=(18, 18, 18, 255),
            outline=(70, 70, 70, 255),
            width=2
        )

        title_font = self.fm.get_font("mono", 48)
        line_font = self.fm.get_font("mono", 48)

        draw.text(
            (24, 22),
            "ROUND SCORE",
            font=title_font,
            fill=(230, 230, 230, 255)
        )

        line_y = 100
        line_gap = 55

        for round_no in range(start_round, end_round + 1):

            round_index = round_no - 1

            if round_index < len(state.round_scores):
                score = state.round_scores[round_index][player]
            else:
                score = 0

            if round_no == state.round_no:
                color = self.player_colors[player % len(self.player_colors)]
            elif round_no < state.round_no:
                color = (160, 160, 160, 255)
            else:
                color = (80, 80, 80, 255)

            text = f"R{round_no:02d}   {score:>3}"

            draw.text(
                (48, line_y),
                text,
                font=line_font,
                fill=color
            )

            line_y += line_gap

        tex = np.array(img, dtype=np.uint8)

        self._round_history_cache_key = history_key
        self._round_history_cache_value = (tex, panel_w, panel_h)

        self.r.ui_draw_texture(x, y, panel_w, panel_h, tex)

    # --------------------------------------------------
    def _draw_panel(self, x, y, w, h, fill, outline, radius=8, width=2):

        key = (
            w,
            h,
            fill,
            outline,
            radius,
            width,
        )

        if key not in self._panel_cache:
            img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
            draw = ImageDraw.Draw(img)

            draw.rounded_rectangle(
                [0, 0, w - 1, h - 1],
                radius=radius,
                fill=fill,
                outline=outline,
                width=width
            )

            self._panel_cache[key] = np.array(img, dtype=np.uint8)

        tex = self._panel_cache[key]

        self.r.ui_draw_texture(x, y, w, h, tex)

    # --------------------------------------------------
    def _draw_enter_indicator(self, state):

        import time
        import math

        if not state.waiting_for_throw_collect:
            return

        if state.throw_collect_confirmed:
            return

        if not (
            state.throw_collect_blink_immediate
            or time.time() >= state.throw_collect_ready_at
        ):
            return

        t = time.time()

        pulse = 0.5 + 0.5 * math.sin(t * 5.0)
        alpha = int(120 + 135 * pulse)
        alpha = (alpha // 16) * 16

        player_color = self.player_colors[
            state.current_player % len(self.player_colors)
        ]

        accent = (
            player_color[0],
            player_color[1],
            player_color[2],
            alpha,
        )

        fill = (18, 18, 18, int(170 + 55 * pulse))
        outline = accent

        label = "PRESS ENTER"

        icon_w = 72
        icon_h = 72
        icon_tex = self._get_enter_button_icon_texture(
            size=icon_w,
            alpha=alpha
        )

        label_tex, label_w, label_h = self.fm.get_text_texture(
            label,
            "mono",
            44,
            (255, 255, 255, alpha)
        )

        gap = 18
        pad_x = 34
        pad_y = 18

        content_w = icon_w + gap + label_w
        content_h = max(icon_h, label_h)

        box_w = content_w + pad_x * 2
        box_h = content_h + pad_y * 2

        margin_x = 80
        margin_y = 40

        x = self.W - box_w - margin_x
        y = margin_y

        glow_pad = 10

        self._draw_panel(
            x - glow_pad,
            y - glow_pad,
            box_w + glow_pad * 2,
            box_h + glow_pad * 2,
            fill=(0, 0, 0, 0),
            outline=(
                player_color[0],
                player_color[1],
                player_color[2],
                int(55 + 80 * pulse),
            ),
            radius=18,
            width=4
        )

        self._draw_panel(
            x,
            y,
            box_w,
            box_h,
            fill=fill,
            outline=outline,
            radius=14,
            width=3
        )

        icon_x = x + pad_x
        icon_y = y + (box_h - icon_h) // 2

        label_x = icon_x + icon_w + gap
        label_y = y + (box_h - label_h) // 2

        self.r.ui_draw_texture(icon_x, icon_y, icon_w, icon_h, icon_tex)
        self.r.ui_draw_texture(label_x, label_y, label_w, label_h, label_tex)

    # --------------------------------------------------
    def _get_enter_button_icon_texture(self, size, alpha):

        key = (
            "enter_button_icon",
            size,
            alpha,
        )

        if key in self._panel_cache:
            return self._panel_cache[key]

        img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        cx = size // 2
        cy = size // 2

        outer_r = size // 2 - 2
        inner_r = int(size * 0.34)

        draw.ellipse(
            [
                cx - outer_r,
                cy - outer_r,
                cx + outer_r,
                cy + outer_r,
            ],
            fill=(255, 40, 40, int(alpha * 0.22))
        )

        draw.ellipse(
            [
                cx - inner_r,
                cy - inner_r,
                cx + inner_r,
                cy + inner_r,
            ],
            fill=(255, 45, 45, alpha),
            outline=(255, 180, 180, alpha),
            width=3
        )

        highlight_r = int(size * 0.10)
        draw.ellipse(
            [
                cx - int(size * 0.13) - highlight_r,
                cy - int(size * 0.16) - highlight_r,
                cx - int(size * 0.13) + highlight_r,
                cy - int(size * 0.16) + highlight_r,
            ],
            fill=(255, 255, 255, int(alpha * 0.55))
        )

        tex = np.array(img, dtype=np.uint8)
        self._panel_cache[key] = tex

        return tex

    # --------------------------------------------------
    def _format_throw_hit(self, t):

        ring = t.get("ring")
        number = t.get("number")

        if t.get("is_skip") or ring == "SKIP":
            return "SKIP"

        if t.get("is_miss") or ring == "MISS":
            return "MISS"

        if ring == "INNER_BULL":
            return "D-BULL"

        if ring == "OUTER_BULL":
            return "S-BULL"

        if ring in ("INNER_SINGLE", "OUTER_SINGLE"):
            return f"SINGLE {number}"

        if ring == "DOUBLE":
            return f"DOUBLE {number}"

        if ring == "TRIPLE":
            return f"TRIPLE {number}"

        return "-"

    # --------------------------------------------------
    def _get_current_round_throws(self, state):

        result = []

        for t in reversed(state.throw_history):
            if (
                t["round_no"] == state.round_no
                and t["player"] == state.current_player
            ):
                result.append(t)

                if len(result) >= 3:
                    break

        result.reverse()
        return result

    # --------------------------------------------------
    def _format_mode_name(self, mode_id):

        if mode_id == "standard":
            return "STANDARD CRICKET"

        if mode_id == "cut_throat":
            return "CUT THROAT CRICKET"

        return str(mode_id).upper()

    def _format_target(self, target):

        if target == "BULL":
            return "BULL"

        return str(target)

    def _format_mark(self, mark):

        if mark <= 0:
            return "-"

        if mark == 1:
            return "/"

        if mark == 2:
            return "X"

        return "O"

    def _count_closed_targets(self, state, player_index):

        count = 0

        for target in state.targets:
            if state.marks[player_index][target] >= 3:
                count += 1

        return count