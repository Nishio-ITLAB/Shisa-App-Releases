# games/zero1/controller.py

import time

from framework.input_types import EventType, ButtonType, DartHit

from .presenter import build_debug_view, build_debug_lines
from . import rules


AWARD_PRE_DELAY_SEC = 0.5
AWARD_INPUT_LOCK_SEC = 7.5
PLAYER_CHANGE_LOCK_SEC = 0.5
AWARD_PLAYER_CHANGE_LOCK_SEC = 0.5
THROW_COLLECT_NOTICE_DELAY_SEC = 0.5
FINISH_DELAY_SEC = 2.0
BUST_DELAY_SEC = 1.5


class Zero1Controller:

    def __init__(self, engine, state):
        self.engine = engine
        self.state = state

        now = time.time()

        self.state.throw_collect_confirmed = False
        self.state.start_sequence_active = True
        self.state.start_ready_at = now + THROW_COLLECT_NOTICE_DELAY_SEC

    # --------------------------------------------------
    # Debug / Presenter
    # --------------------------------------------------
    def get_debug_view(self):
        return build_debug_view(self.state)

    def get_debug_lines(self):
        return build_debug_lines(self.state)

    # --------------------------------------------------
    # Input
    # --------------------------------------------------
    def update(self):

        if self.state.pending_award_active:
            if time.time() >= self.state.pending_award_ready_at:
                self.state.pending_award_active = False

                award_played = self._play_award(self.state.pending_awards)
                self.state.pending_awards = []

                self._restore_pending_bust()

                self._start_throw_collect_wait(award_played)

            return

        if self.state.waiting_for_throw_collect:
            if (
                self.state.throw_collect_confirmed
                and time.time() >= self.state.throw_collect_ready_at
            ):
                self._confirm_throw_collect()
            return

        if self.state.finish_pending:
            if time.time() >= self.state.finish_at:
                self.state.finish_pending = False
                self.state.finished = True
            return

        if not self.state.start_sequence_active:
            return

        if time.time() < self.state.start_ready_at:
            return

        self.state.start_sequence_active = False
        self.state.start_ready_at = 0.0

        self._set_turn_start_snapshot()

        self.engine.audio.play("player_change")
        self._start_player_change_cutin()
        self._lock_player_change()

    def handle_event(self, event):

        if self.state.start_sequence_active:
            return

        if self.state.bust_pending:
            return

        if self.state.waiting_for_throw_collect:

            if event.type == EventType.BUTTON_PRESSED and event.payload == ButtonType.ENTER:
                self.state.throw_collect_confirmed = True

            if time.time() < self.state.throw_collect_ready_at:
                return

            if self.state.throw_collect_confirmed:
                self._confirm_throw_collect()
                return

            return

        if time.time() < self.state.input_locked_until:
            return

        if event.type == EventType.DART_LONG_PRESS:
            self._handle_dart_long_press(event.payload)
            return

        if event.type == EventType.DART_LONG_PRESS_RELEASED:
            return

        if event.type == EventType.DART_HIT:

            if self.state.waiting_for_throw_collect:
                return

            if self.state.dart_no > 3:
                return

            self._apply_dart_hit(event.payload)
            return

        if event.type == EventType.MISS:

            if self.state.waiting_for_throw_collect:
                return

            if self.state.dart_no > 3:
                return

            self._apply_miss()
            return

        if event.type != EventType.BUTTON_PRESSED:
            return

        if event.payload == ButtonType.ENTER:

            if self.state.dart_no > 3:
                return

            self._apply_skip()

    # --------------------------------------------------
    # Stuck dart warning
    # --------------------------------------------------
    def _handle_dart_long_press(self, payload):

        if isinstance(payload, DartHit):
            message = self._format_dart_hit_message(payload)
        else:
            message = "ダーツが刺さったままです\n盤面から取り外してください"

        self.state.stuck_dart_message = message
        self.state.stuck_dart_until = time.time() + 1.1

    def _clear_stuck_dart_warning(self):
        self.state.stuck_dart_message = None
        self.state.stuck_dart_until = 0.0

    def _format_dart_hit_message(self, hit):

        ring_name = hit.ring.name.replace("_", " ")

        if hit.number is None:
            line1 = f"{ring_name} にダーツが刺さったままです"
        else:
            line1 = f"{ring_name} {hit.number} にダーツが刺さったままです"

        line2 = "盤面から取り外してください"

        return f"{line1}\n{line2}"

    # --------------------------------------------------
    # Throw handling
    # --------------------------------------------------
    def _apply_dart_hit(self, hit):

        if not isinstance(hit, DartHit):
            return

        result = rules.apply_hit(self.state, hit)

        self._play_hit_sound(hit, result)

        self._apply_result(
            result=result,
            hit=hit,
            is_miss=False,
            is_skip=False,
        )

    def _apply_miss(self):

        if not self.state.count_miss_as_throw:
            self.engine.audio.play("miss")
            return

        result = rules.build_miss_result(self.state)

        self.engine.audio.play("miss")

        self._apply_result(
            result=result,
            hit=None,
            is_miss=True,
            is_skip=False,
        )

    def _apply_skip(self):

        result = rules.build_miss_result(self.state)

        self.engine.audio.play("miss")

        self._apply_result(
            result=result,
            hit=None,
            is_miss=False,
            is_skip=True,
        )

    def _apply_result(self, result, hit=None, is_miss=False, is_skip=False):

        if self.state.finished:
            return

        if self.state.round_no > self.state.rounds:
            self.state.finished = True
            return

        self._save_snapshot()

        player_index = self.state.current_player
        round_index = self.state.round_no - 1

        remaining_before = self.state.scores[player_index]

        record = rules.build_throw_record(
            state=self.state,
            result=result,
            hit=hit,
            is_miss=is_miss,
            is_skip=is_skip,
        )

        if is_skip:
            record["is_skip"] = True
            record["ring"] = "SKIP"

        self.state.throw_history.append(record)

        if result.get("bust", False):
            record["judge"] = "bust"
            record["judge_color"] = "red"

            self._apply_bust_result(player_index, round_index)
            return

        effective_score = int(result.get("effective_score", 0))

        self.state.scores[player_index] = int(result.get(
            "remaining_after",
            remaining_before,
        ))

        self.state.total_scores[player_index] = (
            self.state.start_score - self.state.scores[player_index]
        )

        self.state.round_scores[round_index][player_index] += effective_score

        if result.get("finish", False):
            record["judge"] = "finish"
            record["judge_color"] = "yellow"

            self.state.winner = player_index
            self.state.result_reason = "finish"
            self.state.finish_pending = True
            self.state.finish_at = time.time() + FINISH_DELAY_SEC
            return

        self.state.dart_no += 1

        if self.state.dart_no > 3:
            self.state.throw_collect_confirmed = False

            turn_throws = self._get_current_turn_throws()
            awards = rules.evaluate_turn_awards(turn_throws)

            if awards:
                self.state.pending_awards = awards
                self.state.pending_award_ready_at = time.time() + AWARD_PRE_DELAY_SEC
                self.state.pending_award_active = True
            else:
                self._start_throw_collect_wait(False)

    def _apply_bust_result(self, player_index, round_index):

        self.state.pending_bust_restore = {
            "player": player_index,
            "round_index": round_index,
            "score": self.state.turn_start_scores[player_index],
            "round_score": self.state.turn_start_round_scores[player_index],
        }

        self.state.dart_no = 4

        self.state.pending_awards = ["bust"]
        self.state.pending_award_ready_at = time.time() + AWARD_PRE_DELAY_SEC
        self.state.pending_award_active = True

        self.state.bust_pending = False
        self.state.bust_at = 0.0
        self.state.throw_collect_confirmed = False

    def _restore_pending_bust(self):

        data = self.state.pending_bust_restore

        if not data:
            return

        player = data["player"]
        round_index = data["round_index"]

        self.state.scores[player] = data["score"]
        self.state.round_scores[round_index][player] = data["round_score"]

        self.state.total_scores[player] = (
            self.state.start_score - self.state.scores[player]
        )

        self.state.pending_bust_restore = None

    def _play_hit_sound(self, hit, result):

        score = int(result.get("score", 0))

        if score <= 0:
            self.engine.audio.play("miss")
            return

        ring = hit.ring.name

        # -------------------------
        # bull
        # -------------------------
        if ring == "INNER_BULL":
            self.engine.audio.play("bull_inner")
            return

        if ring == "OUTER_BULL":
            self.engine.audio.play("bull_outer")
            return

        # -------------------------
        # normal hit
        # -------------------------
        if ring == "SINGLE":
            self.engine.audio.play("normal_single")

        elif ring == "DOUBLE":
            self.engine.audio.play("normal_double")

        elif ring == "TRIPLE":
            self.engine.audio.play("normal_triple")

        else:
            # 保険
            self.engine.audio.play("normal_single")

    # --------------------------------------------------
    # Turn / wait handling
    # --------------------------------------------------
    def _start_throw_collect_wait(self, award_played: bool):

        self.state.throw_collect_blink_immediate = award_played

        if (
            self.state.round_no >= self.state.rounds
            and self.state.current_player >= self.state.players - 1
        ):
            self.state.result_reason = "round_limit"
            self.state.finish_pending = True
            self.state.finish_at = time.time() + FINISH_DELAY_SEC
            return

        self.state.waiting_for_throw_collect = True
        self.state.pending_next_player = True
        self.state.throw_collect_message = None

        now = time.time()

        if award_played:
            if self.state.throw_collect_confirmed:
                self.state.throw_collect_ready_at = time.time()
            else:
                self.state.throw_collect_ready_at = (
                    self.state.input_locked_until + AWARD_PLAYER_CHANGE_LOCK_SEC
                )
        else:
            self.state.input_locked_until = now + PLAYER_CHANGE_LOCK_SEC
            self.state.throw_collect_ready_at = now + PLAYER_CHANGE_LOCK_SEC

    def _confirm_throw_collect(self):
        self.state.waiting_for_throw_collect = False
        self.state.pending_next_player = False
        self.state.throw_collect_message = None
        self.state.throw_collect_ready_at = 0.0
        self.state.throw_collect_blink_immediate = False

        self.state.dart_no = 1
        self._next_player()

        if not self.state.finished:
            self._set_turn_start_snapshot()
            self.engine.audio.play("player_change")
            self._start_player_change_cutin()
            self._lock_player_change()

    def _next_player(self):

        if self.state.finished:
            return

        self.state.current_player += 1

        if self.state.current_player >= self.state.players:
            self.state.current_player = 0
            self.state.round_no += 1

        self.state.dart_no = 1

        if self.state.round_no > self.state.rounds:
            self.state.result_reason = "round_limit"
            self.state.finished = True

    def _set_turn_start_snapshot(self):

        player = self.state.current_player
        round_index = self.state.round_no - 1

        if round_index < 0 or round_index >= len(self.state.round_scores):
            return

        self.state.turn_start_scores[player] = self.state.scores[player]
        self.state.turn_start_round_scores[player] = (
            self.state.round_scores[round_index][player]
        )

    # --------------------------------------------------
    # Awards
    # --------------------------------------------------
    def _get_current_turn_throws(self):
        return [
            t for t in self.state.throw_history
            if t["round_no"] == self.state.round_no
            and t["player"] == self.state.current_player
        ][-3:]

    def _play_award(self, awards):

        if not awards:
            self.state.current_award = None
            return False

        priority = [
            "bust",
            "ton_80",
            "shisa_eye",
            "hat_trick",
            "high_ton",
            "3_in_a_bed",
            "low_ton",
        ]

        for award in priority:
            if award in awards:
                self.state.current_award = award

                self.state.input_locked_until = time.time() + AWARD_INPUT_LOCK_SEC

                self.engine.video.play_with_intro(
                    award,
                    black_seconds=2.0,
                    poll_callback=self._poll_award_input
                )

                return True

        self.state.current_award = None
        return False

    def _poll_award_input(self):
        led = getattr(self.engine, "led", None)

        events = self.engine.input.poll()

        for e in events:
            if e.type == EventType.BUTTON_PRESSED and e.payload == ButtonType.ENTER:
                self.state.throw_collect_confirmed = True

                if led is not None:
                    led.restore_button_leds()
                    led.update()

                return True

        if led is not None:
            led.set_enter_blink_only()
            led.update()

        return False

    # --------------------------------------------------
    # Cutin / lock
    # --------------------------------------------------
    def _start_player_change_cutin(self):

        self.state.cutin_active = True
        self.state.cutin_start_time = time.time()

    def _lock_player_change(self):

        self.state.current_award = None
        self.state.input_locked_until = time.time() + PLAYER_CHANGE_LOCK_SEC

    # --------------------------------------------------
    # Options
    # --------------------------------------------------
    def set_out_option(self, out_option):

        if out_option not in rules.VALID_OUT_OPTIONS:
            return False

        self.state.out_option = out_option
        return True

    def cycle_out_option(self, direction=1):

        values = ["open", "double", "master"]

        current = self.state.out_option

        if current not in values:
            index = 0
        else:
            index = values.index(current)

        index = (index + direction) % len(values)
        self.state.out_option = values[index]

        return self.state.out_option

    def toggle_count_miss_as_throw(self):
        self.state.count_miss_as_throw = not self.state.count_miss_as_throw

    # --------------------------------------------------
    # Undo
    # --------------------------------------------------
    def _save_snapshot(self):

        self.state.last_snapshot = {
            "scores": self.state.scores.copy(),
            "total_scores": self.state.total_scores.copy(),
            "round_scores": [
                row.copy() for row in self.state.round_scores
            ],
            "turn_start_scores": self.state.turn_start_scores.copy(),
            "turn_start_round_scores": self.state.turn_start_round_scores.copy(),
            "throw_history": self.state.throw_history.copy(),
            "current_player": self.state.current_player,
            "round_no": self.state.round_no,
            "dart_no": self.state.dart_no,
            "finished": self.state.finished,
            "winner": self.state.winner,
            "result_reason": self.state.result_reason,
            "out_option": self.state.out_option,
            "bust_pending": self.state.bust_pending,
            "bust_at": self.state.bust_at,
            "finish_pending": self.state.finish_pending,
            "finish_at": self.state.finish_at,
            "pending_bust_restore": (
                self.state.pending_bust_restore.copy()
                if self.state.pending_bust_restore is not None
                else None
            ),
        }

    def can_undo(self):
        if self.state.last_snapshot is None:
            return False

        if self.state.undo_limit == -1:
            return True

        return self.state.undo_used < self.state.undo_limit

    def get_undo_remaining_text(self):
        if self.state.undo_limit == -1:
            return "制限なし"

        remaining = self.state.undo_limit - self.state.undo_used
        if remaining < 0:
            remaining = 0

        return f"{remaining}回"

    def undo(self):
        if not self.can_undo():
            self.engine.audio.play("miss")
            return False

        self._undo()
        return True

    def _undo(self):

        if self.state.last_snapshot is None:
            self.engine.audio.play("miss")
            return

        if self.state.undo_limit != -1:
            if self.state.undo_used >= self.state.undo_limit:
                self.engine.audio.play("miss")
                return

        snap = self.state.last_snapshot

        self.state.scores = snap["scores"].copy()

        self.state.pending_bust_restore = (
            snap["pending_bust_restore"].copy()
            if snap.get("pending_bust_restore") is not None
            else None
        )

        self.state.total_scores = snap["total_scores"].copy()
        self.state.round_scores = [
            row.copy() for row in snap["round_scores"]
        ]

        self.state.turn_start_scores = snap["turn_start_scores"].copy()
        self.state.turn_start_round_scores = snap["turn_start_round_scores"].copy()
        self.state.throw_history = snap["throw_history"].copy()

        self.state.current_player = snap["current_player"]
        self.state.round_no = snap["round_no"]
        self.state.dart_no = snap["dart_no"]
        self.state.finished = snap["finished"]
        self.state.winner = snap["winner"]
        self.state.result_reason = snap["result_reason"]
        self.state.out_option = snap["out_option"]

        self.state.bust_pending = snap["bust_pending"]
        self.state.bust_at = snap["bust_at"]
        self.state.finish_pending = snap["finish_pending"]
        self.state.finish_at = snap["finish_at"]

        self.state.waiting_for_throw_collect = False
        self.state.pending_next_player = False
        self.state.throw_collect_confirmed = False
        self.state.throw_collect_ready_at = 0.0
        self.state.pending_awards = []
        self.state.pending_award_active = False
        self.state.pending_award_ready_at = 0.0
        self.state.current_award = None

        self.state.last_snapshot = None
        self.state.undo_used += 1

        self.engine.audio.play("cancel")