# games/zero1/view.py

import numpy as np
from PIL import Image, ImageDraw, ImageFont

from . import rules


FONT_MONO = "/opt/shisa/current/assets/fonts/ChivoMono-VariableFont_wght.ttf"
SCORE_FONT_PATH = "/opt/shisa/current/assets/fonts/ChivoMono-VariableFont_wght.ttf"


class Zero1View:

    def __init__(self, renderer, font_manager, controller):

        self.r = renderer
        self.fm = font_manager
        self.controller = controller

        self.W, self.H = renderer.get_logical_size()

        self.score_font = ImageFont.truetype(SCORE_FONT_PATH, 450)

        self.player_colors = [
            (255, 80, 80, 255),
            (80, 180, 255, 255),
            (80, 255, 140, 255),
            (255, 220, 80, 255),
        ]

        self._score_cache_key = None
        self._score_cache_value = None
        self._panel_cache = {}

        self._player_score_cache = {}

        self._round_history_cache_key = None
        self._round_history_cache_value = None
        self._arrange_cache_key = None
        self._arrange_cache_value = None

    # --------------------------------------------------
    def draw(self, show_enter_indicator=True):

        state = self.controller.state

        self._draw_mode_name(state)
        self._draw_round_history(state)
        self._draw_main_score(state)
        self._draw_arrange_panel(state)
        self._draw_current_round_throws(state)
        self._draw_player_score_bar(state)

        if show_enter_indicator:
            self._draw_enter_indicator(state)

    # --------------------------------------------------
    def _draw_mode_name(self, state):

        mode_text = self._format_mode_name(state.mode_id)

        x = 60
        y = 40

        tex, w, h = self.fm.get_text_texture(
            mode_text,
            "mono_italic",
            56,
            (230, 230, 230, 255)
        )

        self.r.ui_draw_texture(
            x,
            y,
            w,
            h,
            tex
        )

        line_img = Image.new("RGBA", (w, 3), (200, 200, 200, 200))

        self.r.ui_draw_texture(
            x,
            y + h + 4,
            w,
            3,
            np.array(line_img, dtype=np.uint8)
        )

    # --------------------------------------------------
    def _draw_main_score(self, state):

        player = state.current_player
        remaining = state.scores[player]

        text = str(remaining)

        score_color = self.player_colors[player % len(self.player_colors)]

        cache_key = (
            text,
            player,
            score_color,
        )

        if self._score_cache_key != cache_key:
            self._score_cache_key = cache_key
            self._score_cache_value = self._create_gradient_text(
                text=text,
                font=self.score_font,
                top_color=(255, 255, 255, 255),
                bottom_color=score_color
            )

        tex, w, h = self._score_cache_value

        x = (self.W - w) // 2
        y = int(self.H * 0.24)

        self.r.ui_draw_texture(x, y, w, h, tex)

        label = f"PLAYER {player + 1}"

        tex2, w2, h2 = self.fm.get_text_texture(
            label,
            "mono",
            52,
            self.player_colors[player % len(self.player_colors)]
        )

        self.r.ui_draw_texture(
            (self.W - w2) // 2,
            y - 100,
            w2,
            h2,
            tex2
        )

    # --------------------------------------------------
    def _draw_arrange_panel(self, state):

        player = state.current_player
        remaining = state.scores[player]
        out_option = state.out_option

        remaining_darts = max(1, 4 - state.dart_no)

        suggestions = rules.suggest_outs(
            remaining=remaining,
            out_option=out_option,
            limit=3,
            max_darts=remaining_darts,
        )

        key = (
            remaining,
            out_option,
            tuple(tuple(row) for row in suggestions),
        )

        margin_x = 60

        panel_w = 260
        panel_h = 600
        x = self.W - panel_w - margin_x
        y = 240

        if self._arrange_cache_key == key and self._arrange_cache_value is not None:
            tex, w, h = self._arrange_cache_value
            self.r.ui_draw_texture(x, y, w, h, tex)
            return

        img = Image.new("RGBA", (panel_w, panel_h), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        draw.rounded_rectangle(
            [0, 0, panel_w - 1, panel_h - 1],
            radius=8,
            fill=(18, 18, 18, 255),
            outline=(70, 70, 70, 255),
            width=2
        )

        title_font = self.fm.get_font("mono", 48)
        sub_font = self.fm.get_font("mono", 30)
        line_font = self.fm.get_font("mono", 38)
        small_font = self.fm.get_font("mono", 26)

        draw.text(
            (24, 22),
            "ARRANGE",
            font=title_font,
            fill=(230, 230, 230, 255)
        )

        draw.text(
            (28, 84),
            f"OUT {out_option.upper()}",
            font=sub_font,
            fill=(150, 150, 150, 255)
        )

        if remaining > 170:
            draw.text(
                (36, 170),
                "NO OUT",
                font=line_font,
                fill=(120, 120, 120, 255)
            )

        elif remaining <= 0:
            draw.text(
                (36, 170),
                "FINISH",
                font=line_font,
                fill=self.player_colors[player % len(self.player_colors)]
            )

        elif not suggestions:
            draw.text(
                (36, 170),
                "NO ROUTE",
                font=line_font,
                fill=(120, 120, 120, 255)
            )

        else:
            line_y = 145

            num_x = 34
            value_x = 90 

            for index, row in enumerate(suggestions):
                route_no = f"{index + 1}."

                # 番号
                draw.text(
                    (num_x, line_y),
                    route_no,
                    font=small_font,
                    fill=(130, 130, 130, 255)
                )

                # 1投目
                if row:
                    draw.text(
                        (value_x, line_y),
                        row[0],
                        font=line_font,
                        fill=(245, 245, 245, 255)
                    )

                dart_y = line_y + 44

                # 2投目以降
                for dart in row[1:]:
                    draw.text(
                        (value_x, dart_y),
                        dart,
                        font=line_font,
                        fill=(245, 245, 245, 255)
                    )
                    dart_y += 44

                line_y = dart_y + 18

        tex = np.array(img, dtype=np.uint8)

        self._arrange_cache_key = key
        self._arrange_cache_value = (tex, panel_w, panel_h)

        self.r.ui_draw_texture(x, y, panel_w, panel_h, tex)

    # --------------------------------------------------
    def _draw_current_round_throws(self, state):

        throws = self._get_current_round_throws(state)

        box_w = 250
        box_h = 84
        gap = 30

        total_w = box_w * 3 + gap * 2
        base_x = (self.W - total_w) // 2
        y = int(self.H * 0.68)

        for i in range(3):

            x = base_x + i * (box_w + gap)

            active = i == state.dart_no - 1 and not state.waiting_for_throw_collect
            filled = i < len(throws)

            if filled:
                text = self._format_throw_hit(throws[i])
                border = (230, 230, 230, 255)
                fill = (35, 35, 35, 255)
                text_color = (255, 255, 255, 255)

                if throws[i].get("finish"):
                    border = (255, 220, 80, 255)
                    text_color = (255, 220, 80, 255)

                elif throws[i].get("bust"):
                    border = (255, 80, 80, 255)
                    text_color = (255, 80, 80, 255)

            else:
                text = str(i + 1)
                border = (90, 90, 90, 255)
                fill = (18, 18, 18, 255)
                text_color = (80, 80, 80, 255)

            if active:
                border = self.player_colors[state.current_player % len(self.player_colors)]

            self._draw_panel(x, y, box_w, box_h, fill, border, radius=8, width=3)

            tex, w, h = self.fm.get_text_texture(
                text,
                "mono_italic",
                40,
                text_color
            )

            self.r.ui_draw_texture(
                x + (box_w - w) // 2,
                y + (box_h - h) // 2,
                w,
                h,
                tex
            )

    # --------------------------------------------------
    def _draw_round_history(self, state):

        x = 60
        y = 170
        panel_w = 360
        panel_h = 680

        player = state.current_player

        visible_count = 10

        if state.round_no <= visible_count:
            start_round = 1
            end_round = min(state.rounds, visible_count)
        else:
            end_round = state.round_no
            start_round = end_round - visible_count + 1

        history_key = (
            player,
            state.round_no,
            start_round,
            end_round,
            tuple(
                state.round_scores[i][player] if i < len(state.round_scores) else 0
                for i in range(start_round - 1, end_round)
            ),
        )

        if (
            self._round_history_cache_key == history_key
            and self._round_history_cache_value is not None
        ):
            tex, w, h = self._round_history_cache_value
            self.r.ui_draw_texture(x, y, w, h, tex)
            return

        img = Image.new("RGBA", (panel_w, panel_h), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        draw.rounded_rectangle(
            [0, 0, panel_w - 1, panel_h - 1],
            radius=8,
            fill=(18, 18, 18, 255),
            outline=(70, 70, 70, 255),
            width=2
        )

        title_font = self.fm.get_font("mono", 48)
        line_font = self.fm.get_font("mono", 48)

        draw.text(
            (24, 22),
            "ROUND SCORE",
            font=title_font,
            fill=(230, 230, 230, 255)
        )

        line_y = 100
        line_gap = 55

        for round_no in range(start_round, end_round + 1):

            round_index = round_no - 1

            if round_index < len(state.round_scores):
                score = state.round_scores[round_index][player]
            else:
                score = 0

            if round_no == state.round_no:
                color = self.player_colors[player % len(self.player_colors)]
            elif round_no < state.round_no:
                color = (160, 160, 160, 255)
            else:
                color = (80, 80, 80, 255)

            text = f"R{round_no:02d}   {score:>3}"

            draw.text(
                (48, line_y),
                text,
                font=line_font,
                fill=color
            )

            line_y += line_gap

        tex = np.array(img, dtype=np.uint8)

        self._round_history_cache_key = history_key
        self._round_history_cache_value = (tex, panel_w, panel_h)

        self.r.ui_draw_texture(x, y, panel_w, panel_h, tex)

    # --------------------------------------------------
    def _draw_player_score_bar(self, state):

        players = state.players

        bar_y = int(self.H * 0.82)
        bar_w = self.W - 160
        bar_h = 170

        gap = 24

        layout_slots = {
            1: 2,
            2: 3,
            3: 4,
            4: 4,
        }.get(players, 4)

        box_w = (bar_w - gap * (layout_slots - 1)) // layout_slots
        box_h = bar_h

        total_w = box_w * players + gap * (players - 1)
        bar_x = (self.W - total_w) // 2

        for i in range(players):

            x = bar_x + i * (box_w + gap)
            y = bar_y

            is_current = i == state.current_player

            base_color = self.player_colors[i % len(self.player_colors)]

            if is_current:
                fill = (35, 35, 35, 255)
                outline = base_color
                text_color = (255, 255, 255, 255)
                label_color = base_color
                width = 5
            else:
                fill = (14, 14, 14, 255)
                outline = (55, 55, 55, 255)
                text_color = (95, 95, 95, 255)
                label_color = (80, 80, 80, 255)
                width = 2

            self._draw_panel(
                x,
                y,
                box_w,
                box_h,
                fill=fill,
                outline=outline,
                radius=8,
                width=width
            )

            label = f"PLAYER {i + 1}"
            score = str(state.scores[i])

            tex, w, h = self.fm.get_text_texture(
                label,
                "mono",
                32,
                label_color
            )

            self.r.ui_draw_texture(
                x + 28,
                y + 24,
                w,
                h,
                tex
            )

            key = (i, score, text_color)

            if key not in self._player_score_cache:
                self._player_score_cache[key] = self.fm.get_text_texture(
                    score,
                    "mono",
                    100,
                    text_color
                )

            tex2, w2, h2 = self._player_score_cache[key]

            self.r.ui_draw_texture(
                x + box_w - w2 - 32,
                y + 70,
                w2,
                h2,
                tex2
            )

    # --------------------------------------------------
    def _draw_panel(self, x, y, w, h, fill, outline, radius=8, width=2):

        key = (
            w,
            h,
            fill,
            outline,
            radius,
            width,
        )

        if key not in self._panel_cache:
            img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
            draw = ImageDraw.Draw(img)

            draw.rounded_rectangle(
                [0, 0, w - 1, h - 1],
                radius=radius,
                fill=fill,
                outline=outline,
                width=width
            )

            self._panel_cache[key] = np.array(img, dtype=np.uint8)

        tex = self._panel_cache[key]

        self.r.ui_draw_texture(
            x,
            y,
            w,
            h,
            tex
        )

    # --------------------------------------------------
    def _draw_enter_indicator(self, state):

        import time
        import math

        if not state.waiting_for_throw_collect:
            return

        if state.throw_collect_confirmed:
            return

        if not (
            state.throw_collect_blink_immediate
            or time.time() >= state.throw_collect_ready_at
        ):
            return

        t = time.time()

        pulse = 0.5 + 0.5 * math.sin(t * 5.0)
        alpha = int(120 + 135 * pulse)
        alpha = (alpha // 16) * 16

        player_color = self.player_colors[
            state.current_player % len(self.player_colors)
        ]

        accent = (
            player_color[0],
            player_color[1],
            player_color[2],
            alpha,
        )

        fill = (18, 18, 18, int(170 + 55 * pulse))
        outline = accent

        label = "PRESS ENTER"

        icon_w = 72
        icon_h = 72
        icon_tex = self._get_enter_button_icon_texture(
            size=icon_w,
            alpha=alpha
        )

        label_tex, label_w, label_h = self.fm.get_text_texture(
            label,
            "mono",
            44,
            (255, 255, 255, alpha)
        )

        gap = 18
        pad_x = 34
        pad_y = 18

        content_w = icon_w + gap + label_w
        content_h = max(icon_h, label_h)

        box_w = content_w + pad_x * 2
        box_h = content_h + pad_y * 2

        margin_x = 80
        margin_y = 40

        x = self.W - box_w - margin_x
        y = margin_y

        glow_pad = 10

        self._draw_panel(
            x - glow_pad,
            y - glow_pad,
            box_w + glow_pad * 2,
            box_h + glow_pad * 2,
            fill=(0, 0, 0, 0),
            outline=(
                player_color[0],
                player_color[1],
                player_color[2],
                int(55 + 80 * pulse),
            ),
            radius=18,
            width=4
        )

        self._draw_panel(
            x,
            y,
            box_w,
            box_h,
            fill=fill,
            outline=outline,
            radius=14,
            width=3
        )

        icon_x = x + pad_x
        icon_y = y + (box_h - icon_h) // 2

        label_x = icon_x + icon_w + gap
        label_y = y + (box_h - label_h) // 2

        self.r.ui_draw_texture(
            icon_x,
            icon_y,
            icon_w,
            icon_h,
            icon_tex
        )

        self.r.ui_draw_texture(
            label_x,
            label_y,
            label_w,
            label_h,
            label_tex
        )

    # --------------------------------------------------
    def _get_enter_button_icon_texture(self, size, alpha):

        key = (
            "enter_button_icon",
            size,
            alpha,
        )

        if key in self._panel_cache:
            return self._panel_cache[key]

        img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        cx = size // 2
        cy = size // 2

        outer_r = size // 2 - 2
        inner_r = int(size * 0.34)

        draw.ellipse(
            [
                cx - outer_r,
                cy - outer_r,
                cx + outer_r,
                cy + outer_r,
            ],
            fill=(255, 40, 40, int(alpha * 0.22))
        )

        draw.ellipse(
            [
                cx - inner_r,
                cy - inner_r,
                cx + inner_r,
                cy + inner_r,
            ],
            fill=(255, 45, 45, alpha),
            outline=(255, 180, 180, alpha),
            width=3
        )

        highlight_r = int(size * 0.10)
        draw.ellipse(
            [
                cx - int(size * 0.13) - highlight_r,
                cy - int(size * 0.16) - highlight_r,
                cx - int(size * 0.13) + highlight_r,
                cy - int(size * 0.16) + highlight_r,
            ],
            fill=(255, 255, 255, int(alpha * 0.55))
        )

        tex = np.array(img, dtype=np.uint8)
        self._panel_cache[key] = tex

        return tex

    # --------------------------------------------------
    def _create_gradient_text(self, text, font, top_color, bottom_color):

        x0, y0, x1, y1 = font.getbbox(text)

        w = max(1, x1 - x0)
        h = max(1, y1 - y0)

        mask_img = Image.new("L", (w, h), 0)
        mask_draw = ImageDraw.Draw(mask_img)
        mask_draw.text((-x0, -y0), text, font=font, fill=255)

        gradient = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        grad_pixels = gradient.load()

        for yy in range(h):
            t = yy / max(1, h - 1)

            r = int(top_color[0] * (1 - t) + bottom_color[0] * t)
            g = int(top_color[1] * (1 - t) + bottom_color[1] * t)
            b = int(top_color[2] * (1 - t) + bottom_color[2] * t)
            a = int(top_color[3] * (1 - t) + bottom_color[3] * t)

            for xx in range(w):
                grad_pixels[xx, yy] = (r, g, b, a)

        gradient.putalpha(mask_img)

        return np.array(gradient, dtype=np.uint8), w, h

    # --------------------------------------------------
    def _format_throw_hit(self, t):

        ring = t.get("ring")
        number = t.get("number")

        if t.get("is_skip") or ring == "SKIP":
            return "SKIP"

        if t.get("is_miss") or ring == "MISS":
            return "MISS"

        if ring == "INNER_BULL":
            return "D-BULL"

        if ring == "OUTER_BULL":
            return "S-BULL"

        if ring in ("INNER_SINGLE", "OUTER_SINGLE"):
            return f"SINGLE {number}"

        if ring == "DOUBLE":
            return f"DOUBLE {number}"

        if ring == "TRIPLE":
            return f"TRIPLE {number}"

        return "-"

    # --------------------------------------------------
    def _get_current_round_throws(self, state):

        result = []

        for t in reversed(state.throw_history):
            if (
                t["round_no"] == state.round_no
                and t["player"] == state.current_player
            ):
                result.append(t)

                if len(result) >= 3:
                    break

        result.reverse()
        return result

    # --------------------------------------------------
    def _format_mode_name(self, mode_id):

        if mode_id == "301":
            return "301 GAME"

        if mode_id == "501":
            return "501 GAME"

        if mode_id == "701":
            return "701 GAME"

        if mode_id == "901":
            return "901 GAME"

        if mode_id == "1101":
            return "1101 GAME"

        if mode_id == "1501":
            return "1501 GAME"

        return str(mode_id).upper()