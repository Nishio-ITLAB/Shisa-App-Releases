# games/zero1/factory.py

from .state import Zero1State
from .controller import Zero1Controller


VALID_MODES = {
    "301",
    "501",
    "701",
    "901",
    "1101",
    "1501",
}

VALID_OUT_OPTIONS = {
    "open",
    "double",
    "master",
}

MIN_PLAYERS = 1
MAX_PLAYERS = 4


def create_game(engine, mode_id, players):
    """
    01ゲーム生成入口。
    MenuSceneから呼ばれる。

    - mode_id: "301" / "501" / "701" / "901" / "1101" / "1501"
    - players: 1〜4
    """

    if mode_id not in VALID_MODES:
        raise ValueError(f"Unknown zero1 mode_id: {mode_id}")

    players = int(players)

    if players < MIN_PLAYERS or players > MAX_PLAYERS:
        raise ValueError(f"Invalid players: {players}")

    settings = engine.game_config.get_settings("zero1")

    start_score = int(mode_id)
    rounds = int(engine.game_config.get_zero1_rounds(mode_id))
    undo_limit = int(settings.get("undo_limit", 5))

    out_option = str(settings.get("out_option", "master"))

    if out_option not in VALID_OUT_OPTIONS:
        out_option = "master"

    state = Zero1State(
        mode_id=mode_id,
        players=players,
        rounds=rounds,
        undo_limit=undo_limit,
        start_score=start_score,
        out_option=out_option,
    )

    controller = Zero1Controller(
        engine=engine,
        state=state,
    )

    return controller