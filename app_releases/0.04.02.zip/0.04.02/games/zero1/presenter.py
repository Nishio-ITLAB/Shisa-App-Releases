# games/zero1/presenter.py

import time


def build_debug_view(state):
    """
    01 stateをデバッグ表示用に左右カラムへ分割する。
    描画はしない。
    """

    undo_limit_text = "UNLIMITED" if state.undo_limit == -1 else str(state.undo_limit)

    if state.stuck_dart_message and time.time() < state.stuck_dart_until:
        stuck_warning = state.stuck_dart_message
    else:
        stuck_warning = None

    if state.waiting_for_throw_collect and time.time() >= state.throw_collect_ready_at:
        collect_message = "矢を抜いてENTERを押してください"
    else:
        collect_message = None

    left_lines = [
        "01 DEBUG STATE",
        "",
        f"mode_id        : {state.mode_id}",
        f"players        : {state.players}",
        f"rounds         : {state.rounds}",
        f"undo_limit     : {undo_limit_text}",
        f"start_score    : {state.start_score}",
        f"out_option     : {state.out_option}",
        f"count_miss_as_throw : {state.count_miss_as_throw}",
        f"remaining      : {state.scores}",
        f"total_scores   : {state.total_scores}",
        f"current_player : {state.current_player + 1}",
        f"round_no       : {state.round_no}",
        f"dart_no        : {state.dart_no}",
        f"finished       : {state.finished}",
        f"winner         : {None if state.winner is None else state.winner + 1}",
        f"result_reason  : {state.result_reason}",
        f"bust_pending   : {state.bust_pending}",
        f"undo_used      : {state.undo_used}",
        f"can_undo       : {state.last_snapshot is not None}",
        "",
        f"stuck_warning  : {stuck_warning}",
        f"collect_message: {collect_message}",
    ]

    right_lines = [
        "ROUND SCORES",
        "",
    ]

    for round_index, row in enumerate(state.round_scores):
        round_no = round_index + 1
        scores_text = " / ".join(
            f"P{player_index + 1}:{score}"
            for player_index, score in enumerate(row)
        )
        right_lines.append(f"R{round_no:02d}  {scores_text}")

    right_lines.extend([
        "",
        "RECENT THROWS",
        "",
    ])

    recent_throws = state.throw_history[-8:]

    if not recent_throws:
        right_lines.append("(none)")
    else:
        for t in recent_throws:
            flags = []

            if t.get("bust"):
                flags.append("BUST")

            if t.get("finish"):
                flags.append("FINISH")

            if t.get("is_skip"):
                flags.append("SKIP")

            if t.get("is_miss"):
                flags.append("MISS")

            flag_text = ""
            if flags:
                flag_text = " " + ",".join(flags)

            right_lines.append(
                f"R{t['round_no']:02d} "
                f"P{t['player'] + 1} "
                f"D{t['dart_no']} "
                f"-{t.get('effective_score', 0)} "
                f"REM:{t.get('remaining_after')}"
                f"{flag_text}"
            )

    return {
        "left": left_lines,
        "right": right_lines,
    }


# 互換用。古いroot.pyが get_debug_lines() を使っていても一応動くようにする。
def build_debug_lines(state):
    view = build_debug_view(state)
    return view["left"] + ["", "--- RIGHT ---", ""] + view["right"]