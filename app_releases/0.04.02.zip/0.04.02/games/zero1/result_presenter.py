# games/zero1/result_presenter.py

def build_result_view(state):
    """
    01用リザルト表示データを構築する。
    描画はしない。
    """

    players = state.players
    rounds = state.rounds

    player_results = []

    for player_index in range(players):

        remaining = state.scores[player_index]
        total_score = state.total_scores[player_index]

        round_scores = [
            state.round_scores[round_index][player_index]
            for round_index in range(rounds)
        ]

        high_round = max(round_scores) if round_scores else 0

        player_throws = [
            t for t in state.throw_history
            if t.get("player") == player_index
        ]

        dart_count = len(player_throws)

        miss_count = sum(
            1 for t in player_throws
            if t.get("is_miss") or t.get("ring") == "MISS"
        )

        bust_count = sum(
            1 for t in player_throws
            if t.get("bust")
        )

        finish_count = sum(
            1 for t in player_throws
            if t.get("finish")
        )

        ppd = 0.0
        if dart_count > 0:
            ppd = total_score / dart_count

        player_results.append({
            "player": player_index,
            "label": f"PLAYER {player_index + 1}",

            # 共通ResultScene互換。
            # 01では順位・表示用スコアとして「残り点」を入れる。
            "total_score": remaining,

            # 01固有値
            "remaining": remaining,
            "scored": total_score,

            "round_scores": round_scores,
            "high_round": high_round,
            "dart_count": dart_count,
            "ppd": ppd,
            "miss_count": miss_count,
            "bust_count": bust_count,
            "finish_count": finish_count,
            "finished": state.winner == player_index,
        })

    ranking = sorted(
        player_results,
        key=lambda x: (
            0 if x["finished"] else 1,
            x["remaining"],
            -x["scored"],
        )
    )

    _apply_competition_ranking(ranking)

    round_table = []

    for round_index in range(rounds):
        row = {
            "round_no": round_index + 1,
            "scores": [
                state.round_scores[round_index][player_index]
                for player_index in range(players)
            ]
        }
        round_table.append(row)

    return {
        "mode": _format_mode_name(state.mode_id),
        "players": players,
        "rounds": rounds,
        "start_score": state.start_score,
        "out_option": state.out_option,
        "winner": state.winner,
        "winner_label": _format_winner(state),
        "result_reason": state.result_reason,
        "ranking": ranking,
        "players_detail": player_results,
        "round_table": round_table,

        # 既存ResultScene互換。
        # 01では totals は「残り点」として扱う。
        "totals": state.scores.copy(),

        # 01固有表示用。
        "remaining": state.scores.copy(),
        "total_scores": state.total_scores.copy(),
    }


def _apply_competition_ranking(rows):
    """
    同点は competition ranking 方式。
    例: 100, 100, 80 => 1st, 1st, 3rd

    01では順位キーを
    - finish済み優先
    - 残り点が少ない方
    - 削った点が多い方
    とする。
    """

    previous_key = None
    previous_rank = 0

    for index, row in enumerate(rows):
        rank = index + 1

        key = (
            row["finished"],
            row["remaining"],
        )

        if previous_key is not None and key == previous_key:
            row["rank"] = previous_rank
        else:
            row["rank"] = rank
            previous_rank = rank

        row["rank_label"] = _format_rank(row["rank"])
        previous_key = key


def _format_winner(state):
    if state.winner is None:
        return None

    return f"PLAYER {state.winner + 1}"


def _format_rank(rank):

    if rank == 1:
        return "1st"

    if rank == 2:
        return "2nd"

    if rank == 3:
        return "3rd"

    return f"{rank}th"


def _format_mode_name(mode_id):

    if mode_id == "301":
        return "301 GAME"

    if mode_id == "501":
        return "501 GAME"

    if mode_id == "701":
        return "701 GAME"

    if mode_id == "901":
        return "901 GAME"

    if mode_id == "1101":
        return "1101 GAME"

    if mode_id == "1501":
        return "1501 GAME"

    return str(mode_id).upper()