# games/zero1/rules.py

from framework.input_types import DartHit, DartRing


VALID_MODES = {
    "301",
    "501",
    "701",
    "901",
    "1101",
    "1501",
}

VALID_OUT_OPTIONS = {
    "open",
    "double",
    "master",
}


def apply_hit(state, hit: DartHit) -> dict:
    """
    DartHitを01ゲームルールで評価する。
    state自体は更新しない。
    controller側で戻り値をstateへ反映する。
    """

    if not isinstance(hit, DartHit):
        return build_empty_result(state, hit=None, valid=False)

    if state.mode_id not in VALID_MODES:
        raise ValueError(f"Unknown zero1 mode_id: {state.mode_id}")

    player = state.current_player

    remaining_before = state.scores[player]
    hit_score = score_hit(hit)

    remaining_after = remaining_before - hit_score

    bust = False
    finish = False
    valid_finish = False

    if remaining_after < 0:
        bust = True

    elif remaining_after == 0:
        valid_finish = is_valid_out_hit(hit, state.out_option)

        if valid_finish:
            finish = True
        else:
            bust = True

    elif remaining_after == 1 and state.out_option in ("double", "master"):
        bust = True

    effective_score = hit_score

    if bust:
        remaining_after = state.turn_start_scores[player]
        effective_score = 0

    return {
        "score": hit_score,
        "effective_score": effective_score,
        "remaining_before": remaining_before,
        "remaining_after": remaining_after,
        "bust": bust,
        "finish": finish,
        "valid_finish": valid_finish,
        "valid": True,
    }


def build_empty_result(state, hit: DartHit | None, valid: bool = False) -> dict:
    """
    MISS、SKIPなど、得点が発生しない結果を作る。
    """

    player = state.current_player
    remaining = state.scores[player]

    return {
        "score": 0,
        "effective_score": 0,
        "remaining_before": remaining,
        "remaining_after": remaining,
        "bust": False,
        "finish": False,
        "valid_finish": False,
        "valid": valid,
    }


def build_miss_result(state) -> dict:
    """
    MISS用。
    1投として扱うかどうかはcontroller側で判断する。
    """
    return build_empty_result(state, hit=None, valid=False)


def score_hit(hit: DartHit) -> int:
    """
    DartHitを01ゲームの得点に変換する。
    """

    if hit.ring == DartRing.OUTER_BULL:
        return 25

    if hit.ring == DartRing.INNER_BULL:
        return 50

    if hit.number is None:
        return 0

    multiplier = _ring_multiplier(hit.ring)
    return hit.number * multiplier


def is_valid_out_hit(hit: DartHit, out_option: str) -> bool:
    """
    OUT条件を満たすヒットかどうか。
    """

    if out_option not in VALID_OUT_OPTIONS:
        out_option = "master"

    if out_option == "open":
        return True

    if out_option == "double":
        return _is_double_out_hit(hit)

    if out_option == "master":
        return _is_master_out_hit(hit)

    return False


def build_throw_record(
    state,
    result: dict,
    hit: DartHit | None,
    is_miss: bool = False,
    is_skip: bool = False,
) -> dict:
    """
    throw_historyへ保存する1投分の記録を作る。
    """

    if is_miss:
        number = None
        ring = "MISS"
    elif is_skip:
        number = None
        ring = "SKIP"
    elif hit is not None:
        number = hit.number
        ring = hit.ring.name
    else:
        number = None
        ring = "UNKNOWN"

    return {
        "round_no": state.round_no,
        "player": state.current_player,
        "dart_no": state.dart_no,
        "mode_id": state.mode_id,

        "number": number,
        "ring": ring,

        "score": result.get("score", 0),
        "effective_score": result.get("effective_score", 0),

        "remaining_before": result.get("remaining_before"),
        "remaining_after": result.get("remaining_after"),

        "bust": result.get("bust", False),
        "finish": result.get("finish", False),
        "valid_finish": result.get("valid_finish", False),
        "valid": result.get("valid", False),

        "out_option": state.out_option,

        "is_miss": bool(is_miss),
        "is_skip": bool(is_skip),
    }


def evaluate_turn_awards(turn_throws: list[dict]) -> list[str]:
    """
    1ラウンド3投分のアワードを判定する。
    COUNT-UP系のTON/BULL/3 IN A BEDを流用する。
    Bustしたターンはアワード対象外。
    """

    awards = []

    if not turn_throws:
        return awards

    for t in turn_throws:
        if t.get("bust"):
            return awards

    effective_throws = [
        t for t in turn_throws
        if not t.get("is_skip")
        and not t.get("is_miss")
        and t.get("valid")
    ]

    if not effective_throws:
        return awards

    turn_score = sum(
        int(t.get("score", 0))
        for t in effective_throws
    )

    if _is_ton80(effective_throws):
        awards.append("ton_80")

    elif turn_score >= 150:
        awards.append("high_ton")

    elif turn_score >= 100:
        awards.append("low_ton")

    if _is_shisa_eye(effective_throws):
        awards.append("shisa_eye")

    elif _is_hat_trick(effective_throws):
        awards.append("hat_trick")

    if _is_3_in_a_bed(effective_throws):
        awards.append("3_in_a_bed")

    return awards


def suggest_outs(
    remaining: int,
    out_option: str,
    limit: int = 3,
    max_darts: int = 3,
) -> list[list[str]]:
    """
    上がり目候補を最大limit件返す。
    0〜170以外は候補なし。
    """

    remaining = int(remaining)

    if remaining <= 0:
        return []

    if remaining > 170:
        return []

    darts = _build_dart_options()

    if out_option in ("double", "master"):
        arrange_darts = [
            d for d in darts
            if not d["label"].startswith("S")
            or d["label"] == "S-BULL"
        ]
    else:
        arrange_darts = darts

    finish_darts = [
        d for d in darts
        if is_valid_out_label(d["label"], out_option)
    ]

    suggestions = []

    # 1本上がり
    for d1 in finish_darts:
        if d1["score"] == remaining:
            suggestions.append([d1["label"]])

    # 2本上がり
    if max_darts >= 2:
        for d1 in arrange_darts:
            for d2 in finish_darts:
                if d1["score"] + d2["score"] == remaining:
                    suggestions.append([d1["label"], d2["label"]])

    # 3本上がり
    if max_darts >= 3:
        for d1 in arrange_darts:
            for d2 in arrange_darts:
                for d3 in finish_darts:
                    if d1["score"] + d2["score"] + d3["score"] == remaining:
                        suggestions.append([d1["label"], d2["label"], d3["label"]])

    # 表示順を先に正規化する
    suggestions = [
        _normalize_suggestion_order(row)
        for row in suggestions
    ]

    # 正規化後にソートする
    suggestions = _sort_out_suggestions(suggestions)

    unique = []
    seen = set()

    for row in suggestions:
        key = tuple(row)
        if key in seen:
            continue

        seen.add(key)
        unique.append(row)

        if len(unique) >= limit:
            break

    return unique


def _label_score(label: str) -> int:
    if label == "S-BULL":
        return 25

    if label == "D-BULL":
        return 50

    if len(label) < 2:
        return 0

    prefix = label[0]
    try:
        number = int(label[1:])
    except ValueError:
        return 0

    if prefix == "S":
        return number

    if prefix == "D":
        return number * 2

    if prefix == "T":
        return number * 3

    return 0


def _normalize_suggestion_order(row: list[str]) -> list[str]:
    """
    アレンジ候補の表示順を整える。
    投順違いは同一候補として扱うため、全投を得点降順に並べる。
    """

    return sorted(
        row,
        key=lambda label: (
            -_label_score(label),
            label,
        )
    )


def is_valid_out_label(label: str, out_option: str) -> bool:
    if out_option not in VALID_OUT_OPTIONS:
        out_option = "master"

    if out_option == "open":
        return True

    if out_option == "double":
        return label.startswith("D") or label == "D-BULL"

    if out_option == "master":
        return (
            label.startswith("D")
            or label.startswith("T")
            or label in ("S-BULL", "D-BULL")
        )

    return False


def is_game_finished(state) -> bool:
    if state.finished:
        return True

    if state.round_no > state.rounds:
        return True

    return False


def build_ranking(state) -> list[dict]:
    """
    リザルト用ランキングを作る。
    finish済み優先。
    未finishは残り点が少ない方を上位にする。
    """

    rows = []

    for player in range(state.players):
        finished = state.winner == player

        rows.append({
            "player": player,
            "label": f"PLAYER {player + 1}",
            "remaining": state.scores[player],
            "score": state.total_scores[player],
            "finished": finished,
        })

    rows.sort(
        key=lambda x: (
            0 if x["finished"] else 1,
            x["remaining"],
            -x["score"],
        )
    )

    previous_key = None
    previous_rank = 0

    for index, row in enumerate(rows):
        rank = index + 1
        key = (
            row["finished"],
            row["remaining"],
        )

        if previous_key is not None and key == previous_key:
            row["rank"] = previous_rank
        else:
            row["rank"] = rank
            previous_rank = rank

        row["rank_label"] = _format_rank(row["rank"])
        previous_key = key

    return rows


def _build_dart_options() -> list[dict]:
    darts = []

    for n in range(1, 21):
        darts.append({
            "label": f"S{n}",
            "score": n,
            "rank": 300 + n,
        })

    for n in range(1, 21):
        darts.append({
            "label": f"D{n}",
            "score": n * 2,
            "rank": 200 + n,
        })

    for n in range(1, 21):
        darts.append({
            "label": f"T{n}",
            "score": n * 3,
            "rank": 100 + n,
        })

    darts.append({
        "label": "S-BULL",
        "score": 25,
        "rank": 250,
    })

    darts.append({
        "label": "D-BULL",
        "score": 50,
        "rank": 150,
    })

    return darts


def _sort_out_suggestions(suggestions: list[list[str]]) -> list[list[str]]:
    def key(row):
        scores = sorted(
            [_label_score(label) for label in row],
            reverse=True
        )

        while len(scores) < 3:
            scores.append(0)

        return (
            len(row),
            -scores[0],
            -scores[1],
            -scores[2],
            row,
        )

    return sorted(suggestions, key=key)


def _suggestion_rank(row: list[str]) -> int:
    return -sum(_label_score(label) for label in row)


def _is_double_out_hit(hit: DartHit) -> bool:
    if hit.ring == DartRing.INNER_BULL:
        return True

    return hit.ring == DartRing.DOUBLE


def _is_master_out_hit(hit: DartHit) -> bool:
    if hit.ring in (
        DartRing.DOUBLE,
        DartRing.TRIPLE,
        DartRing.OUTER_BULL,
        DartRing.INNER_BULL,
    ):
        return True

    return False


def _ring_multiplier(ring: DartRing) -> int:
    if ring == DartRing.INNER_SINGLE:
        return 1

    if ring == DartRing.OUTER_SINGLE:
        return 1

    if ring == DartRing.DOUBLE:
        return 2

    if ring == DartRing.TRIPLE:
        return 3

    return 0


def _is_ton80(turn_throws: list[dict]) -> bool:
    if len(turn_throws) < 3:
        return False

    for t in turn_throws:
        if t.get("number") != 20:
            return False

        if t.get("ring") != "TRIPLE":
            return False

    return True


def _is_3_in_a_bed(turn_throws: list[dict]) -> bool:
    """
    3投すべてが同じナンバーのDOUBLEまたはTRIPLEならTrue。
    BullはHat Trick扱いとするため除外。
    """

    if len(turn_throws) < 3:
        return False

    first = turn_throws[0]

    if first.get("number") is None:
        return False

    if first.get("ring") not in ("DOUBLE", "TRIPLE"):
        return False

    target_number = first.get("number")
    target_ring = first.get("ring")

    for t in turn_throws:
        if t.get("number") != target_number:
            return False

        if t.get("ring") != target_ring:
            return False

        if int(t.get("score", 0)) <= 0:
            return False

    return True


def _is_shisa_eye(turn_throws: list[dict]) -> bool:
    """
    3投すべてがINNER_BULLならTrue。
    Hat Trickの上位版。
    """

    if len(turn_throws) < 3:
        return False

    for t in turn_throws:
        if t.get("ring") != "INNER_BULL":
            return False

    return True


def _is_hat_trick(turn_throws: list[dict]) -> bool:
    """
    3投すべてがBullならTrue。
    """

    if len(turn_throws) < 3:
        return False

    for t in turn_throws:
        if t.get("ring") not in ("INNER_BULL", "OUTER_BULL"):
            return False

    return True


def _format_rank(rank: int) -> str:
    if rank == 1:
        return "1st"

    if rank == 2:
        return "2nd"

    if rank == 3:
        return "3rd"

    return f"{rank}th"