# games/countup/result_presenter.py


def build_result_view(state):
    """
    COUNT-UP用リザルト表示データを構築する。
    描画はしない。
    """

    players = state.players
    rounds = state.rounds

    player_results = []

    for player_index in range(players):

        total_score = state.scores[player_index]

        round_scores = [
            state.round_scores[round_index][player_index]
            for round_index in range(rounds)
        ]

        high_round = max(round_scores) if round_scores else 0

        player_throws = [
            t for t in state.throw_history
            if t.get("player") == player_index
        ]

        dart_count = len(player_throws)

        miss_count = sum(
            1 for t in player_throws
            if t.get("ring") == "MISS"
        )

        ppd = 0.0
        if dart_count > 0:
            ppd = total_score / dart_count

        player_results.append({
            "player": player_index,
            "label": f"PLAYER {player_index + 1}",
            "total_score": total_score,
            "round_scores": round_scores,
            "high_round": high_round,
            "dart_count": dart_count,
            "ppd": ppd,
            "miss_count": miss_count,
        })

    ranking = sorted(
        player_results,
        key=lambda x: x["total_score"],
        reverse=True
    )

    _apply_competition_ranking(ranking)

    round_table = []

    for round_index in range(rounds):
        row = {
            "round_no": round_index + 1,
            "scores": [
                state.round_scores[round_index][player_index]
                for player_index in range(players)
            ]
        }
        round_table.append(row)

    return {
        "mode": _format_mode_name(state.mode_id),
        "players": players,
        "rounds": rounds,
        "ranking": ranking,
        "players_detail": player_results,
        "round_table": round_table,
        "totals": state.scores.copy(),
    }


def _apply_competition_ranking(rows):
    previous_score = None
    previous_rank = 0

    for index, row in enumerate(rows):
        rank = index + 1

        if previous_score is not None and row["total_score"] == previous_score:
            row["rank"] = previous_rank
        else:
            row["rank"] = rank
            previous_rank = rank

        row["rank_label"] = _format_rank(row["rank"])
        previous_score = row["total_score"]


def _format_rank(rank):

    if rank == 1:
        return "1st"

    if rank == 2:
        return "2nd"

    if rank == 3:
        return "3rd"

    return f"{rank}th"


def _format_mode_name(mode_id):

    if mode_id == "count_up":
        return "COUNT-UP"

    if mode_id == "cr_count_up":
        return "CRICKET COUNT-UP"

    return str(mode_id).upper()