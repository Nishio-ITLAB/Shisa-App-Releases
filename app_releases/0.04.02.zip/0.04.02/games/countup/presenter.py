# games/countup/presenter.py

import time

def build_debug_view(state):
    """
    COUNT-UP stateをデバッグ表示用に左右カラムへ分割する。
    描画はしない。
    """

    undo_limit_text = "UNLIMITED" if state.undo_limit == -1 else str(state.undo_limit)

    if state.stuck_dart_message and time.time() < state.stuck_dart_until:
        stuck_warning = state.stuck_dart_message
    else:
        stuck_warning = None

    if state.waiting_for_throw_collect and time.time() >= state.throw_collect_ready_at:
        collect_message = "矢を抜いてENTERを押してください"
    else:
        collect_message = None

    left_lines = [
        "COUNT-UP DEBUG STATE",
        "",
        f"mode_id        : {state.mode_id}",
        f"players        : {state.players}",
        f"rounds         : {state.rounds}",
        f"undo_limit     : {undo_limit_text}",
        f"count_miss_as_throw : {state.count_miss_as_throw}",
        f"scores         : {state.scores}",
        f"current_player : {state.current_player + 1}",
        f"round_no       : {state.round_no}",
        f"dart_no        : {state.dart_no}",
        f"finished       : {state.finished}",
        f"undo_used      : {state.undo_used}",
        f"can_undo       : {state.last_snapshot is not None}",
        "",
        f"stuck_warning : {stuck_warning}",
        f"collect_message : {collect_message}",
    ]

    right_lines = [
        "ROUND SCORES",
        "",
    ]

    for round_index, row in enumerate(state.round_scores):
        round_no = round_index + 1
        scores_text = " / ".join(
            f"P{player_index + 1}:{score}"
            for player_index, score in enumerate(row)
        )
        right_lines.append(f"R{round_no:02d}  {scores_text}")

    right_lines.extend([
        "",
        "RECENT THROWS",
        "",
    ])

    recent_throws = state.throw_history[-8:]

    if not recent_throws:
        right_lines.append("(none)")
    else:
        for t in recent_throws:
            right_lines.append(
                f"R{t['round_no']:02d} "
                f"P{t['player'] + 1} "
                f"D{t['dart_no']} "
                f"+{t['score']}"
            )

    return {
        "left": left_lines,
        "right": right_lines,
    }


# 互換用。古いroot.pyが get_debug_lines() を使っていても一応動くようにする。
def build_debug_lines(state):
    view = build_debug_view(state)
    return view["left"] + ["", "--- RIGHT ---", ""] + view["right"]