# main.py

import signal
import os
from framework.engine import Engine
import RPi.GPIO as GPIO


def get_version_info():
    try:
        with open("/opt/shisa/current/version.txt", "r") as f:
            lines = f.read().splitlines()

        version = lines[0].strip() if len(lines) > 0 else "unknown"
        build = lines[1].strip() if len(lines) > 1 else ""

        required_assets = ""

        for line in lines[2:]:
            line = line.strip()
            if line.startswith("required_assets="):
                required_assets = line.split("=", 1)[1].strip()

        return version, build, required_assets

    except Exception:
        return "unknown", "", ""


def main():

    # --------------------------------------------------
    # VERSION表示（最初に出す）
    # --------------------------------------------------
    version, build, required_assets = get_version_info()

    print("===== SHISA START =====")

    if build:
        print(f"VERSION: {version} ({build})")
    else:
        print(f"VERSION: {version}")

    if required_assets:
        print(f"REQUIRED ASSETS: {required_assets}")
    else:
        print("REQUIRED ASSETS: none")

    # --------------------------------------------------
    # GPIO初期化（起動時はコイン電源OFF）
    # --------------------------------------------------
    GPIO.setmode(GPIO.BCM)
    GPIO.setup(9, GPIO.OUT)
    GPIO.output(9, GPIO.LOW)

    engine = Engine()

    # --------------------------------------------------
    # SIGTERM / SIGINT handler
    # --------------------------------------------------
    def handle_exit(signum, frame):
        print("Signal received. Stopping engine...")

        # コイン電源OFF
        GPIO.output(9, GPIO.LOW)

        engine.stop()

    signal.signal(signal.SIGTERM, handle_exit)
    signal.signal(signal.SIGINT, handle_exit)

    engine.run()


if __name__ == "__main__":
    main()