# hw_platform/io/led_manager.py

import time
import RPi.GPIO as GPIO
from enum import Enum, auto
from smbus2 import SMBus

from hw_platform.io.tca9555 import TCA9555


class LedMode(Enum):
    OFF = auto()
    ON = auto()
    BLINK = auto()


class LedManager:
    """
    LED制御クラス

    機能:
    - GPIO直結LED制御
    - ボタンLED制御（TCA9555経由）
    - ENTER LED単独点滅
    """

    BLINK_INTERVAL = 0.5
    ENTER_BLINK_INTERVAL = 0.3

    def __init__(self):
        # --------------------------------------------------
        # Button LEDs via TCA9555
        # --------------------------------------------------
        self.bus = SMBus(1)

        self.tca23 = TCA9555(self.bus, 0x23)
        self.tca24 = TCA9555(self.bus, 0x24)

        # ボタンLED割り当て
        # ENTER LED
        self.enter_led = ("tca24", 1, 6)

        # ENTER以外の5つ
        self.other_button_leds = [
            ("tca24", 0, 0),
            ("tca24", 0, 3),
            ("tca23", 0, 2),
            ("tca24", 1, 3),
            ("tca24", 0, 6),
        ]

        self.button_leds = [
            self.enter_led,
            *self.other_button_leds,
        ]

        self._enter_blink_mode = False
        self._enter_blink_state = True
        self._enter_last_toggle = time.time()

        # 初期状態は全ボタンLED ON
        self.set_all_button_leds(True)

    # --------------------------------------------------
    # GPIO LED PUBLIC
    # --------------------------------------------------

    def set_on(self, pin: int):

        led = self._leds.get(pin)
        if led is None:
            return

        led["mode"] = LedMode.ON
        led["state"] = True

        GPIO.output(pin, GPIO.HIGH)

    def set_off(self, pin: int):

        led = self._leds.get(pin)
        if led is None:
            return

        led["mode"] = LedMode.OFF
        led["state"] = False

        GPIO.output(pin, GPIO.LOW)

    def set_blink(self, pin: int):

        led = self._leds.get(pin)
        if led is None:
            return

        led["mode"] = LedMode.BLINK
        led["last_toggle"] = time.time()

    # --------------------------------------------------
    # BUTTON LED PUBLIC
    # --------------------------------------------------

    def set_all_button_leds(self, state: bool):
        """
        6個のボタンLEDをすべてON/OFFする。
        """

        self._enter_blink_mode = False

        for led in self.button_leds:
            self._set_button_led(led, state)

    def set_enter_led(self, state: bool):
        """
        ENTER LEDのみON/OFFする。
        """

        self._set_button_led(self.enter_led, state)

    def set_other_button_leds(self, state: bool):
        """
        ENTER以外の5個のボタンLEDをON/OFFする。
        """

        for led in self.other_button_leds:
            self._set_button_led(led, state)

    def set_enter_blink_only(self):
        """
        ENTER LEDだけ0.3秒周期で点滅。
        ENTER以外の5個はOFF。
        すでに点滅中ならタイマーをリセットしない。
        """

        if self._enter_blink_mode:
            return

        self.set_other_button_leds(False)

        self._enter_blink_mode = True
        self._enter_blink_state = True
        self._enter_last_toggle = time.time()

        self.set_enter_led(True)

    def restore_button_leds(self):
        """
        通常状態へ復帰。
        すべてのボタンLEDをONに戻す。
        """

        self._enter_blink_mode = False
        self.set_all_button_leds(True)

    # --------------------------------------------------
    # UPDATE
    # --------------------------------------------------

    def update(self):

        now = time.time()

        # ENTER button LED blink
        if self._enter_blink_mode:

            if now - self._enter_last_toggle >= self.ENTER_BLINK_INTERVAL:

                self._enter_blink_state = not self._enter_blink_state
                self._enter_last_toggle = now

                self.set_enter_led(self._enter_blink_state)

    # --------------------------------------------------
    # INTERNAL
    # --------------------------------------------------

    def _set_button_led(self, led, state: bool):

        dev_name, port, bit = led

        if dev_name == "tca23":
            self.tca23.set_bit(port, bit, state)

        elif dev_name == "tca24":
            self.tca24.set_bit(port, bit, state)

    # --------------------------------------------------
    # CLEANUP
    # --------------------------------------------------

    def cleanup(self):

        GPIO.output(self.LED34_PIN, GPIO.LOW)
        GPIO.output(self.LED20_PIN, GPIO.LOW)

        self.set_all_button_leds(False)

        GPIO.cleanup()