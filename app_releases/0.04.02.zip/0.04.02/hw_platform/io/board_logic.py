# hw_platform/io/board_logic.py

from typing import Dict, Optional, Tuple

from framework.input_types import DartHit, DartRing


class BoardLogic:
    """
    ダーツ盤判定ロジック

    DartIO から渡される SI ペアを DartHit に変換する。
    d_mode によって判定テーブルを切り替える。

    注意:
        実機都合により、d_mode の論理は資料上の D_MODE と逆になっているため、
        decode() 内で参照テーブルを反転している。

        - d_mode=True  -> mode_false_map を使う
        - d_mode=False -> mode_true_map  を使う
    """

    def __init__(self):
        self.mode_true_map: Dict[Tuple[int, int], DartHit] = {}
        self.mode_false_map: Dict[Tuple[int, int], DartHit] = {}

        self._build_mode_true()
        self._build_mode_false()

    # =========================================================
    # Public
    # =========================================================

    def decode(
        self,
        active_sis: Tuple[int, int],
        d_mode: bool,
    ) -> Optional[DartHit]:
        """
        active_sis:
            2点の SI 番号タプル
            例: (2, 26)

        d_mode:
            実機 dart_io から渡される論理値
            実際の盤面資料とは逆論理のため、ここで反転して参照する
        """

        if len(active_sis) != 2:
            return None

        key = self._norm_pair(*active_sis)

        # 実機論理に合わせて反転
        table = self.mode_false_map if d_mode else self.mode_true_map
        return table.get(key)

    # =========================================================
    # Internal helpers
    # =========================================================

    @staticmethod
    def _norm_pair(a: int, b: int) -> Tuple[int, int]:
        return (a, b) if a < b else (b, a)

    @staticmethod
    def _hit(number: Optional[int], ring: DartRing) -> DartHit:
        return DartHit(number=number, ring=ring)

    def _add(
        self,
        table: Dict[Tuple[int, int], DartHit],
        a: int,
        b: int,
        number: Optional[int],
        ring: DartRing,
    ) -> None:
        key = self._norm_pair(a, b)
        if key in table:
            raise ValueError(f"Duplicate board mapping: {key}")
        table[key] = self._hit(number, ring)

    # =========================================================
    # D_MODE = True (資料上: LED20=HIGH)
    # =========================================================

    def _build_mode_true(self) -> None:
        t = self.mode_true_map
        add = self._add

        # Bull
        add(t, 7, 23, None, DartRing.INNER_BULL)
        add(t, 7, 25, None, DartRing.OUTER_BULL)

        # 01
        add(t, 22, 23, 1, DartRing.INNER_SINGLE)
        add(t, 21, 23, 1, DartRing.DOUBLE)
        add(t, 20, 23, 1, DartRing.TRIPLE)

        # 02
        add(t, 13, 25, 2, DartRing.INNER_SINGLE)
        add(t, 12, 25, 2, DartRing.DOUBLE)
        add(t, 11, 25, 2, DartRing.TRIPLE)

        # 03
        add(t, 19, 25, 3, DartRing.INNER_SINGLE)
        add(t, 18, 25, 3, DartRing.DOUBLE)
        add(t, 17, 25, 3, DartRing.TRIPLE)

        # 04
        add(t, 10, 24, 4, DartRing.INNER_SINGLE)
        add(t, 9, 24, 4, DartRing.DOUBLE)
        add(t, 8, 24, 4, DartRing.TRIPLE)

        # 05
        add(t, 16, 23, 5, DartRing.INNER_SINGLE)
        add(t, 15, 23, 5, DartRing.DOUBLE)
        add(t, 14, 23, 5, DartRing.TRIPLE)

        # 06
        add(t, 19, 24, 6, DartRing.INNER_SINGLE)
        add(t, 18, 24, 6, DartRing.DOUBLE)
        add(t, 17, 24, 6, DartRing.TRIPLE)

        # 07
        add(t, 10, 25, 7, DartRing.INNER_SINGLE)
        add(t, 9, 25, 7, DartRing.DOUBLE)
        add(t, 8, 25, 7, DartRing.TRIPLE)

        # 08
        add(t, 22, 26, 8, DartRing.INNER_SINGLE)
        add(t, 21, 26, 8, DartRing.DOUBLE)
        add(t, 20, 26, 8, DartRing.TRIPLE)

        # 09
        add(t, 13, 26, 9, DartRing.INNER_SINGLE)
        add(t, 12, 26, 9, DartRing.DOUBLE)
        add(t, 11, 26, 9, DartRing.TRIPLE)

        # 10
        add(t, 16, 24, 10, DartRing.INNER_SINGLE)
        add(t, 15, 24, 10, DartRing.DOUBLE)
        add(t, 14, 24, 10, DartRing.TRIPLE)

        # 11
        add(t, 19, 26, 11, DartRing.INNER_SINGLE)
        add(t, 18, 26, 11, DartRing.DOUBLE)
        add(t, 17, 26, 11, DartRing.TRIPLE)

        # 12
        add(t, 13, 23, 12, DartRing.INNER_SINGLE)
        add(t, 12, 23, 12, DartRing.DOUBLE)
        add(t, 11, 23, 12, DartRing.TRIPLE)

        # 13
        add(t, 22, 24, 13, DartRing.INNER_SINGLE)
        add(t, 21, 24, 13, DartRing.DOUBLE)
        add(t, 20, 24, 13, DartRing.TRIPLE)

        # 14
        add(t, 16, 26, 14, DartRing.INNER_SINGLE)
        add(t, 15, 26, 14, DartRing.DOUBLE)
        add(t, 14, 26, 14, DartRing.TRIPLE)

        # 15
        add(t, 13, 24, 15, DartRing.INNER_SINGLE)
        add(t, 12, 24, 15, DartRing.DOUBLE)
        add(t, 11, 24, 15, DartRing.TRIPLE)

        # 16
        add(t, 10, 26, 16, DartRing.INNER_SINGLE)
        add(t, 9, 26, 16, DartRing.DOUBLE)
        add(t, 8, 26, 16, DartRing.TRIPLE)

        # 17
        add(t, 16, 25, 17, DartRing.INNER_SINGLE)
        add(t, 15, 25, 17, DartRing.DOUBLE)
        add(t, 14, 25, 17, DartRing.TRIPLE)

        # 18
        add(t, 10, 23, 18, DartRing.INNER_SINGLE)
        add(t, 9, 23, 18, DartRing.DOUBLE)
        add(t, 8, 23, 18, DartRing.TRIPLE)

        # 19
        add(t, 22, 25, 19, DartRing.INNER_SINGLE)
        add(t, 21, 25, 19, DartRing.DOUBLE)
        add(t, 20, 25, 19, DartRing.TRIPLE)

        # 20
        add(t, 19, 23, 20, DartRing.INNER_SINGLE)
        add(t, 18, 23, 20, DartRing.DOUBLE)
        add(t, 17, 23, 20, DartRing.TRIPLE)

    # =========================================================
    # D_MODE = False (資料上: LED34=HIGH)
    # =========================================================

    def _build_mode_false(self) -> None:
        t = self.mode_false_map
        add = self._add

        # Bull
        add(t, 2, 26, None, DartRing.INNER_BULL)
        add(t, 1, 26, None, DartRing.OUTER_BULL)

        # 01
        add(t, 22, 25, 1, DartRing.INNER_SINGLE)
        add(t, 12, 25, 1, DartRing.OUTER_SINGLE)
        add(t, 7, 25, 1, DartRing.DOUBLE)
        add(t, 17, 25, 1, DartRing.TRIPLE)

        # 02
        add(t, 20, 24, 2, DartRing.INNER_SINGLE)
        add(t, 10, 24, 2, DartRing.OUTER_SINGLE)
        add(t, 5, 24, 2, DartRing.DOUBLE)
        add(t, 15, 24, 2, DartRing.TRIPLE)

        # 03
        add(t, 18, 24, 3, DartRing.INNER_SINGLE)
        add(t, 8, 24, 3, DartRing.OUTER_SINGLE)
        add(t, 3, 24, 3, DartRing.DOUBLE)
        add(t, 13, 24, 3, DartRing.TRIPLE)

        # 04
        add(t, 20, 25, 4, DartRing.INNER_SINGLE)
        add(t, 10, 25, 4, DartRing.OUTER_SINGLE)
        add(t, 5, 25, 4, DartRing.DOUBLE)
        add(t, 15, 25, 4, DartRing.TRIPLE)

        # 05
        add(t, 19, 26, 5, DartRing.INNER_SINGLE)
        add(t, 9, 26, 5, DartRing.OUTER_SINGLE)
        add(t, 4, 26, 5, DartRing.DOUBLE)
        add(t, 14, 26, 5, DartRing.TRIPLE)

        # 06
        add(t, 18, 25, 6, DartRing.INNER_SINGLE)
        add(t, 8, 25, 6, DartRing.OUTER_SINGLE)
        add(t, 3, 25, 6, DartRing.DOUBLE)
        add(t, 13, 25, 6, DartRing.TRIPLE)

        # 07
        add(t, 21, 23, 7, DartRing.INNER_SINGLE)
        add(t, 11, 23, 7, DartRing.OUTER_SINGLE)
        add(t, 6, 23, 7, DartRing.DOUBLE)
        add(t, 16, 23, 7, DartRing.TRIPLE)

        # 08
        add(t, 19, 23, 8, DartRing.INNER_SINGLE)
        add(t, 9, 23, 8, DartRing.OUTER_SINGLE)
        add(t, 4, 23, 8, DartRing.DOUBLE)
        add(t, 14, 23, 8, DartRing.TRIPLE)

        # 09
        add(t, 21, 26, 9, DartRing.INNER_SINGLE)
        add(t, 11, 26, 9, DartRing.OUTER_SINGLE)
        add(t, 6, 26, 9, DartRing.DOUBLE)
        add(t, 16, 26, 9, DartRing.TRIPLE)

        # 10
        add(t, 22, 24, 10, DartRing.INNER_SINGLE)
        add(t, 12, 24, 10, DartRing.OUTER_SINGLE)
        add(t, 7, 24, 10, DartRing.DOUBLE)
        add(t, 17, 24, 10, DartRing.TRIPLE)

        # 11
        add(t, 18, 23, 11, DartRing.INNER_SINGLE)
        add(t, 8, 23, 11, DartRing.OUTER_SINGLE)
        add(t, 3, 23, 11, DartRing.DOUBLE)
        add(t, 13, 23, 11, DartRing.TRIPLE)

        # 12
        add(t, 20, 26, 12, DartRing.INNER_SINGLE)
        add(t, 10, 26, 12, DartRing.OUTER_SINGLE)
        add(t, 5, 26, 12, DartRing.DOUBLE)
        add(t, 15, 26, 12, DartRing.TRIPLE)

        # 13
        add(t, 19, 25, 13, DartRing.INNER_SINGLE)
        add(t, 9, 25, 13, DartRing.OUTER_SINGLE)
        add(t, 4, 25, 13, DartRing.DOUBLE)
        add(t, 14, 25, 13, DartRing.TRIPLE)

        # 14
        add(t, 22, 26, 14, DartRing.INNER_SINGLE)
        add(t, 12, 26, 14, DartRing.OUTER_SINGLE)
        add(t, 7, 26, 14, DartRing.DOUBLE)
        add(t, 17, 26, 14, DartRing.TRIPLE)

        # 15
        add(t, 21, 24, 15, DartRing.INNER_SINGLE)
        add(t, 11, 24, 15, DartRing.OUTER_SINGLE)
        add(t, 6, 24, 15, DartRing.DOUBLE)
        add(t, 16, 24, 15, DartRing.TRIPLE)

        # 16
        add(t, 20, 23, 16, DartRing.INNER_SINGLE)
        add(t, 10, 23, 16, DartRing.OUTER_SINGLE)
        add(t, 5, 23, 16, DartRing.DOUBLE)
        add(t, 15, 23, 16, DartRing.TRIPLE)

        # 17
        add(t, 19, 24, 17, DartRing.INNER_SINGLE)
        add(t, 9, 24, 17, DartRing.OUTER_SINGLE)
        add(t, 4, 24, 17, DartRing.DOUBLE)
        add(t, 14, 24, 17, DartRing.TRIPLE)

        # 18
        add(t, 21, 25, 18, DartRing.INNER_SINGLE)
        add(t, 11, 25, 18, DartRing.OUTER_SINGLE)
        add(t, 6, 25, 18, DartRing.DOUBLE)
        add(t, 16, 25, 18, DartRing.TRIPLE)

        # 19
        add(t, 22, 23, 19, DartRing.INNER_SINGLE)
        add(t, 12, 23, 19, DartRing.OUTER_SINGLE)
        add(t, 7, 23, 19, DartRing.DOUBLE)
        add(t, 17, 23, 19, DartRing.TRIPLE)

        # 20
        add(t, 18, 26, 20, DartRing.INNER_SINGLE)
        add(t, 8, 26, 20, DartRing.OUTER_SINGLE)
        add(t, 3, 26, 20, DartRing.DOUBLE)
        add(t, 13, 26, 20, DartRing.TRIPLE)