# hw_platform/io/dart_io.py

import time
import RPi.GPIO as GPIO
from smbus2 import SMBus

from framework.input_types import (
    EventType,
    ButtonType,
    InputEvent,
)

from hw_platform.io.tca9555 import TCA9555
from hw_platform.io.board_logic import BoardLogic


class DartIO:
    """
    実機 I/O 統合クラス

    方針:
    - ダーツ盤判定は Arduino IDE 版に寄せる
    - SIペア探索ではなく、MCP20/MCP21 の raw mask 完全一致で判定する
    - BoardLogic の既存 SI ペア表から raw mask 判定表を自動生成する
    """

    # =========================================================
    # Debug
    # =========================================================

    DEBUG_BUTTON_EVENTS = False
    DEBUG_MCP_EVENTS = False
    DEBUG_RAW_TCA = False
    DEBUG_INPUT_EVENTS = True
    DEBUG_RAW_DART = False

    # =========================================================
    # GPIO (BCM)
    # =========================================================

    GPIO_INT = 17
    GPIO_LED34 = 10
    GPIO_LED20 = 22
    GPIO_COINV = 9

    # =========================================================
    # Timing
    # =========================================================

    TCA_POLL_INTERVAL = 0.005
    MCP_FALLBACK_POLL_INTERVAL = 0.005

    DART_HIT_SETTLE_SEC = 0.002
    DART_CAPTURE_WINDOW_SEC = 0.020

    COIN_GUARD_SEC = 0.2
    SHOCK_GUARD_SEC = 0.2

    BUTTON_LONG_PRESS_SEC = 1.0
    BUTTON_DEBOUNCE_COUNT = 1

    DART_LONG_PRESS_SEC = 1.0
    DART_LONG_PRESS_REPEAT_SEC = 1.0

    # 通常DART_RELEASEDは出さないが、
    # 次のDART_HIT受付再開のために内部状態だけ解除する
    DART_RELEASE_DEBOUNCE_SEC = 0.002

    STARTUP_IGNORE_SEC = 0.1

    # =========================================================
    # MCP23017 registers
    # =========================================================

    MCP_IODIRA = 0x00
    MCP_IODIRB = 0x01
    MCP_GPINTENA = 0x04
    MCP_GPINTENB = 0x05
    MCP_DEFVALA = 0x06
    MCP_DEFVALB = 0x07
    MCP_INTCONA = 0x08
    MCP_INTCONB = 0x09
    MCP_IOCON = 0x0A
    MCP_GPPUA = 0x0C
    MCP_GPPUB = 0x0D
    MCP_INTFA = 0x0E
    MCP_INTFB = 0x0F
    MCP_INTCAPA = 0x10
    MCP_INTCAPB = 0x11
    MCP_GPIOA = 0x12
    MCP_GPIOB = 0x13

    # MIRROR=1, ODR=1
    MCP_IOCON_VALUE = 0b01000100

    # =========================================================
    # SI bit mapping
    # =========================================================

    SI_MAP_20_A = [19, 20, 22, 21, 25, 26, 24, 23]
    SI_MAP_20_B = [17, 18, 16, 15, 13, 14, 12, 11]

    SI_MAP_21_A = [3, 4, 6, 5, 7, 8, 10, 9]
    SI_MAP_21_B = [1, 2, None, None, None, None, None, None]

    # =========================================================
    # TCA output defaults
    # =========================================================

    TCA22_OUT0_DEFAULT = 0x00
    TCA22_OUT1_DEFAULT = 0x00

    # P01 BTN6check = LOW
    # P02 BTN6LED   = HIGH
    TCA23_OUT0_DEFAULT = 0b00000100
    TCA23_OUT1_DEFAULT = 0x00

    # P00 BTN5LED = HIGH
    # P03 BTN4LED = HIGH
    # P06 BTN3LED = HIGH
    TCA24_OUT0_DEFAULT = 0b01001001

    # P13 BTN1LED = HIGH
    # P16 BTN2LED = HIGH
    TCA24_OUT1_DEFAULT = 0b01001000

    # =========================================================
    # INIT
    # =========================================================

    def __init__(self):

        # --------------------------------------------------
        # I2C bus / devices
        # --------------------------------------------------

        self.bus = SMBus(1)

        self.tca22 = TCA9555(self.bus, 0x22)
        self.tca23 = TCA9555(self.bus, 0x23)
        self.tca24 = TCA9555(self.bus, 0x24)
        self._debug_last_tca_poll = 0.0

        # --------------------------------------------------
        # TCA init
        # --------------------------------------------------

        self.tca22.disable_polarity_inversion()
        self.tca23.disable_polarity_inversion()
        self.tca24.disable_polarity_inversion()

        self.tca22.write_port0(self.TCA22_OUT0_DEFAULT)
        self.tca22.write_port1(self.TCA22_OUT1_DEFAULT)

        self.tca23.write_port0(self.TCA23_OUT0_DEFAULT)
        self.tca23.write_port1(self.TCA23_OUT1_DEFAULT)

        self.tca24.write_port0(self.TCA24_OUT0_DEFAULT)
        self.tca24.write_port1(self.TCA24_OUT1_DEFAULT)

        # ADDR22
        # Port0: P06 S_MODE in, P07 D_MODE in
        # Port1: all output
        self.tca22.set_direction(
            0b11000000,
            0b00000000,
        )

        # ADDR23
        # Port0: P00 BTN6IN in, P03 COINVcheck in
        # Port1: all output
        self.tca23.set_direction(
            0b00001001,
            0b00000000,
        )

        # ADDR24
        # Port0: P02 BTN5IN in, P05 BTN4IN in
        # Port1: P11 BTN1IN in, P14 BTN2IN in, P17 BTN3IN in
        self.tca24.set_direction(
            0b00100100,
            0b10010010,
        )

        self.tca22.write_port0(self.TCA22_OUT0_DEFAULT)
        self.tca22.write_port1(self.TCA22_OUT1_DEFAULT)

        self.tca23.write_port0(self.TCA23_OUT0_DEFAULT)
        self.tca23.write_port1(self.TCA23_OUT1_DEFAULT)

        self.tca24.write_port0(self.TCA24_OUT0_DEFAULT)
        self.tca24.write_port1(self.TCA24_OUT1_DEFAULT)

        # --------------------------------------------------
        # MCP init
        # --------------------------------------------------

        self._init_mcp20()
        self._init_mcp21()

        # --------------------------------------------------
        # GPIO init
        # --------------------------------------------------

        GPIO.setmode(GPIO.BCM)

        GPIO.setup(self.GPIO_INT, GPIO.IN, pull_up_down=GPIO.PUD_UP)

        GPIO.setup(self.GPIO_LED34, GPIO.OUT)
        GPIO.setup(self.GPIO_LED20, GPIO.OUT)
        GPIO.setup(self.GPIO_COINV, GPIO.OUT)

        GPIO.output(self.GPIO_LED34, GPIO.LOW)
        GPIO.output(self.GPIO_LED20, GPIO.LOW)
        GPIO.output(self.GPIO_COINV, GPIO.LOW)

        # --------------------------------------------------
        # Internal state
        # --------------------------------------------------

        self.board_logic = BoardLogic()

        self._si_to_raw = self._build_si_to_raw_map()
        self._raw_true_map = self._build_raw_map(self.board_logic.mode_true_map)
        self._raw_false_map = self._build_raw_map(self.board_logic.mode_false_map)

        self.last_tca_poll_monotonic = 0.0
        self.last_mcp_poll_monotonic = 0.0
        self.last_coin_time_monotonic = 0.0
        self.last_shock_time_monotonic = 0.0

        self._dmode = False

        self._button_samples = {
            button: []
            for button in ButtonType
        }

        self._button_pressed = {
            button: False
            for button in ButtonType
        }

        self._button_press_time = {
            button: 0.0
            for button in ButtonType
        }

        self._button_long_sent = {
            button: False
            for button in ButtonType
        }

        self._last_raw20 = 0x0000
        self._last_raw21 = 0x0000
        self._dart_capture_raw20 = 0x0000
        self._dart_capture_raw21 = 0x0000
        self._dart_capture_started = 0.0

        self._dart_pressed = False
        self._dart_press_time = 0.0
        self._dart_long_sent = False
        self._dart_last_hit = None
        self._dart_current_active = False
        self._dart_release_candidate_time = 0.0
        self._dart_last_long_press_sent_monotonic = 0.0

        self._sync_dmode_from_input()
        self._flush_startup_inputs()

        self._startup_ignore_until = time.monotonic() + self.STARTUP_IGNORE_SEC

        if self.DEBUG_INPUT_EVENTS:
            print("DartIO initialized")

    # =========================================================
    # MCP init
    # =========================================================

    def _init_mcp20(self):
        addr = 0x20

        self.bus.write_byte_data(addr, self.MCP_IOCON, self.MCP_IOCON_VALUE)

        self.bus.write_byte_data(addr, self.MCP_IODIRA, 0xFF)
        self.bus.write_byte_data(addr, self.MCP_IODIRB, 0xFF)

        self.bus.write_byte_data(addr, self.MCP_GPPUA, 0xFF)
        self.bus.write_byte_data(addr, self.MCP_GPPUB, 0xFF)

        self.bus.write_byte_data(addr, self.MCP_INTCONA, 0x00)
        self.bus.write_byte_data(addr, self.MCP_INTCONB, 0x00)

        self.bus.write_byte_data(addr, self.MCP_GPINTENA, 0xFF)
        self.bus.write_byte_data(addr, self.MCP_GPINTENB, 0xFF)

        self.bus.read_byte_data(addr, self.MCP_GPIOA)
        self.bus.read_byte_data(addr, self.MCP_GPIOB)

    def _init_mcp21(self):
        addr = 0x21

        self.bus.write_byte_data(addr, self.MCP_IOCON, self.MCP_IOCON_VALUE)

        self.bus.write_byte_data(addr, self.MCP_IODIRA, 0xFF)
        self.bus.write_byte_data(addr, self.MCP_GPPUA, 0xFF)

        # B0,B1,B6,B7 input / B2..B5 output
        iodirb = 0b11000011
        gppub = 0b11000011

        self.bus.write_byte_data(addr, self.MCP_IODIRB, iodirb)
        self.bus.write_byte_data(addr, self.MCP_GPPUB, gppub)

        # B2..B5 output LOW
        self.bus.write_byte_data(addr, self.MCP_GPIOB, 0x00)

        self.bus.write_byte_data(addr, self.MCP_INTCONA, 0x00)
        self.bus.write_byte_data(addr, self.MCP_INTCONB, 0x00)

        self.bus.write_byte_data(addr, self.MCP_GPINTENA, 0xFF)
        self.bus.write_byte_data(addr, self.MCP_GPINTENB, 0b11000011)

        self.bus.read_byte_data(addr, self.MCP_GPIOA)
        self.bus.read_byte_data(addr, self.MCP_GPIOB)

    # =========================================================
    # Raw board map
    # =========================================================

    def _build_si_to_raw_map(self):
        """
        SI番号を MCP20/MCP21 の raw active mask に変換する表を作る。

        raw20:
            bit0..7   MCP20 A0..A7
            bit8..15  MCP20 B0..B7

        raw21:
            bit0..7   MCP21 A0..A7
            bit8..15  MCP21 B0..B7
        """

        m = {}

        for bit, si_no in enumerate(self.SI_MAP_20_A):
            if si_no is not None:
                m[si_no] = (1 << bit, 0x0000)

        for bit, si_no in enumerate(self.SI_MAP_20_B):
            if si_no is not None:
                m[si_no] = (1 << (8 + bit), 0x0000)

        for bit, si_no in enumerate(self.SI_MAP_21_A):
            if si_no is not None:
                m[si_no] = (0x0000, 1 << bit)

        for bit, si_no in enumerate(self.SI_MAP_21_B):
            if si_no is not None:
                m[si_no] = (0x0000, 1 << (8 + bit))

        return m

    def _build_raw_map(self, si_pair_map):
        """
        BoardLogic の SIペア表を raw mask 完全一致表へ変換する。
        """

        raw_map = {}

        for pair, hit in si_pair_map.items():
            a, b = pair

            if a not in self._si_to_raw:
                raise ValueError(f"Unknown SI number: {a}")

            if b not in self._si_to_raw:
                raise ValueError(f"Unknown SI number: {b}")

            raw20_a, raw21_a = self._si_to_raw[a]
            raw20_b, raw21_b = self._si_to_raw[b]

            raw20 = raw20_a | raw20_b
            raw21 = raw21_a | raw21_b

            key = (raw20, raw21)

            if key in raw_map:
                raise ValueError(f"Duplicate raw board mapping: {key}")

            raw_map[key] = hit

        return raw_map

    def _decode_raw_hit(self, raw20: int, raw21: int):
        """
        Arduino方式の raw mask 完全一致判定。
        d_modeの反転論理は BoardLogic.decode() と同じにする。
        """

        table = self._raw_false_map if self._dmode else self._raw_true_map
        return table.get((raw20, raw21))

    # =========================================================
    # Startup flush
    # =========================================================

    def _flush_startup_inputs(self):
        try:
            self._clear_mcp_interrupts()

            g20a, g20b, g21a, g21b = self._read_mcp_gpio()
            gpio_raw20, gpio_raw21 = self._gpio_to_raw(g20a, g20b, g21a, g21b)

            self._last_raw20 = gpio_raw20
            self._last_raw21 = gpio_raw21

            self._clear_dart_state()

            self.last_mcp_poll_monotonic = time.monotonic()
            self.last_coin_time_monotonic = 0.0
            self.last_shock_time_monotonic = 0.0

            if self.DEBUG_INPUT_EVENTS:
                print("Startup input flush complete")

        except Exception as e:
            print("Startup flush error:", e)

    # =========================================================
    # Public
    # =========================================================

    def poll(self):
        now_mono = time.monotonic()
        now_ts = time.time()

        if now_mono < self._startup_ignore_until:
            return []

        events = []

        # --------------------------------------------------
        # MCP INT / fallback
        # --------------------------------------------------

        try:
            if GPIO.input(self.GPIO_INT) == GPIO.LOW:

                now_mono = time.monotonic()
                now_ts = time.time()

                events.extend(
                    self._handle_mcp(
                        now_mono,
                        now_ts,
                        use_intcap=True,
                    )
                )

        except Exception as e:
            if self.DEBUG_MCP_EVENTS:
                print("MCP error:", e)

        # --------------------------------------------------
        # TCA poll
        # --------------------------------------------------

        if (now_mono - self.last_tca_poll_monotonic) >= self.TCA_POLL_INTERVAL:

            if self._debug_last_tca_poll != 0.0:
                dt_ms = (now_mono - self._debug_last_tca_poll) * 1000.0

                #if dt_ms > 10.0:
                #    print(f"[TCA POLL GAP] {dt_ms:.2f} ms")

            self._debug_last_tca_poll = now_mono

            self.last_tca_poll_monotonic = now_mono
            events.extend(self._handle_tca(now_mono, now_ts))

        # --------------------------------------------------
        # Long press checks
        # --------------------------------------------------

        events.extend(self._check_button_long_press(now_mono, now_ts))
        events.extend(self._check_dart_long_press(now_mono, now_ts))

        return events

    # =========================================================
    # D_MODE / LED
    # =========================================================

    def _sync_dmode_from_input(self):
        p0_22, _ = self.tca22.read_inputs()

        # LEDロジック反転
        self._dmode = not bool(p0_22 & (1 << 7))
        self._apply_dmode_led()

    def _apply_dmode_led(self):
        if self._dmode:
            GPIO.output(self.GPIO_LED20, GPIO.HIGH)
            GPIO.output(self.GPIO_LED34, GPIO.LOW)
        else:
            GPIO.output(self.GPIO_LED20, GPIO.LOW)
            GPIO.output(self.GPIO_LED34, GPIO.HIGH)

    # =========================================================
    # TCA
    # =========================================================

    def _handle_tca(self, now_mono: float, now_ts: float):
        events = []

        p0_22, _ = self.tca22.read_inputs()
        p0_23, _ = self.tca23.read_inputs()
        p0_24, p1_24 = self.tca24.read_inputs()

        new_dmode = not bool(p0_22 & (1 << 7))
        if new_dmode != self._dmode:
            self._dmode = new_dmode
            self._apply_dmode_led()

        raw_button_map = {
            ButtonType.SERVICE: not (p0_22 & (1 << 6)),
            ButtonType.NAV_UP: not (p0_23 & (1 << 0)),
            ButtonType.NAV_DOWN: not (p0_24 & (1 << 2)),
            ButtonType.NAV_LEFT: not (p0_24 & (1 << 5)),
            ButtonType.CANCEL: not (p1_24 & (1 << 1)),
            ButtonType.ENTER: not (p1_24 & (1 << 4)),
            ButtonType.NAV_RIGHT: not (p1_24 & (1 << 7)),
        }

        for button, raw_pressed in raw_button_map.items():
            events.extend(
                self._update_button_state(
                    button=button,
                    raw_pressed=raw_pressed,
                    now_mono=now_mono,
                    now_ts=now_ts,
                )
            )

        return events

    # =========================================================
    # Button state machine
    # =========================================================

    def _update_button_state(
        self,
        button: ButtonType,
        raw_pressed: bool,
        now_mono: float,
        now_ts: float,
    ):
        events = []

        samples = self._button_samples[button]
        samples.append(raw_pressed)

        if len(samples) > self.BUTTON_DEBOUNCE_COUNT:
            samples.pop(0)

        if len(samples) < self.BUTTON_DEBOUNCE_COUNT:
            return events

        stable_pressed = all(samples)

        if stable_pressed == self._button_pressed[button]:
            return events

        self._button_pressed[button] = stable_pressed

        if stable_pressed:
            self._button_press_time[button] = now_mono
            self._button_long_sent[button] = False

            if self.DEBUG_INPUT_EVENTS:
                print(f"INPUT BUTTON {button.name}")

            events.append(
                InputEvent(
                    type=EventType.BUTTON_PRESSED,
                    payload=button,
                    timestamp=now_ts,
                )
            )

            if self.DEBUG_BUTTON_EVENTS:
                print("BUTTON_PRESSED:", button.name)

        else:
            if self._button_long_sent[button]:
                events.append(
                    InputEvent(
                        type=EventType.BUTTON_LONG_PRESS_RELEASED,
                        payload=button,
                        timestamp=now_ts,
                    )
                )

                if self.DEBUG_BUTTON_EVENTS:
                    print("BUTTON_LONG_PRESS_RELEASED:", button.name)

            events.append(
                InputEvent(
                    type=EventType.BUTTON_RELEASED,
                    payload=button,
                    timestamp=now_ts,
                )
            )

            if self.DEBUG_BUTTON_EVENTS:
                print("BUTTON_RELEASED:", button.name)

            self._button_press_time[button] = 0.0
            self._button_long_sent[button] = False

        return events

    def _check_button_long_press(self, now_mono: float, now_ts: float):
        events = []

        for button in ButtonType:
            if not self._button_pressed[button]:
                continue

            if self._button_long_sent[button]:
                continue

            if (now_mono - self._button_press_time[button]) >= self.BUTTON_LONG_PRESS_SEC:
                self._button_long_sent[button] = True

                events.append(
                    InputEvent(
                        type=EventType.BUTTON_LONG_PRESS,
                        payload=button,
                        timestamp=now_ts,
                    )
                )

                if self.DEBUG_BUTTON_EVENTS:
                    print("BUTTON_LONG_PRESS:", button.name)

        return events

    # =========================================================
    # MCP raw read / handle
    # =========================================================

    def _read_mcp_intcap(self):
        a20 = self.bus.read_byte_data(0x20, self.MCP_INTCAPA)
        b20 = self.bus.read_byte_data(0x20, self.MCP_INTCAPB)
        a21 = self.bus.read_byte_data(0x21, self.MCP_INTCAPA)
        b21 = self.bus.read_byte_data(0x21, self.MCP_INTCAPB)

        return a20, b20, a21, b21

    def _read_mcp_gpio(self):
        g20a = self.bus.read_byte_data(0x20, self.MCP_GPIOA)
        g20b = self.bus.read_byte_data(0x20, self.MCP_GPIOB)
        g21a = self.bus.read_byte_data(0x21, self.MCP_GPIOA)
        g21b = self.bus.read_byte_data(0x21, self.MCP_GPIOB)

        return g20a, g20b, g21a, g21b

    def _gpio_to_raw(self, g20a, g20b, g21a, g21b):
        """
        GPIO値から active-low の raw mask を作る。
        Arduinoの IO0result / IO1result 相当。
        """

        raw20 = ((~g20a) & 0xFF) | (((~g20b) & 0xFF) << 8)
        raw21 = ((~g21a) & 0xFF) | (((~g21b) & 0xFF) << 8)

        return raw20 & 0xFFFF, raw21 & 0xFFFF

    def _handle_mcp(self, now_mono: float, now_ts: float, use_intcap: bool = False):
        events = []

        # --------------------------------------------------
        # INTF: 今回どのポートで割り込みが発生したか
        # --------------------------------------------------
        intf20a = self.bus.read_byte_data(0x20, self.MCP_INTFA)
        intf20b = self.bus.read_byte_data(0x20, self.MCP_INTFB)
        intf21a = self.bus.read_byte_data(0x21, self.MCP_INTFA)
        intf21b = self.bus.read_byte_data(0x21, self.MCP_INTFB)

        # --------------------------------------------------
        # INTCAP: 割り込みキャプチャ
        # --------------------------------------------------
        a20, b20, a21, b21 = self._read_mcp_intcap()
        cap20, cap21 = self._gpio_to_raw(a20, b20, a21, b21)

        valid20 = 0x0000
        valid21 = 0x0000

        if intf20a:
            valid20 |= cap20 & 0x00FF

        if intf20b:
            valid20 |= cap20 & 0xFF00

        if intf21a:
            valid21 |= cap21 & 0x00FF

        if intf21b:
            valid21 |= cap21 & 0xFF00

        # --------------------------------------------------
        # GPIO current: 現在値 / release判定 / INTクリア用
        # --------------------------------------------------
        g20a, g20b, g21a, g21b = self._read_mcp_gpio()
        gpio_raw20, gpio_raw21 = self._gpio_to_raw(g20a, g20b, g21a, g21b)

        # --------------------------------------------------
        # SHOCK / COIN
        # --------------------------------------------------
        shock_active = bool(
            (valid21 | gpio_raw21) & (1 << (8 + 6))
        )

        if shock_active:
            if (now_mono - self.last_shock_time_monotonic) >= self.SHOCK_GUARD_SEC:
                self.last_shock_time_monotonic = now_mono

                if self.DEBUG_INPUT_EVENTS:
                    print("INPUT MISS")

                events.append(
                    InputEvent(
                        type=EventType.MISS,
                        payload=None,
                        timestamp=now_ts,
                    )
                )

            self._last_raw20 = 0x0000
            self._last_raw21 = 0x0000
            self._clear_dart_state()
            self._clear_mcp_interrupts()

            return events

        coin_active = bool(
            (valid21 | gpio_raw21) & (1 << (8 + 7))
        )

        if coin_active:
            if (now_mono - self.last_coin_time_monotonic) >= self.COIN_GUARD_SEC:
                self.last_coin_time_monotonic = now_mono

                if self.DEBUG_INPUT_EVENTS:
                    print("INPUT COIN")

                events.append(
                    InputEvent(
                        type=EventType.COIN,
                        payload=None,
                        timestamp=now_ts,
                    )
                )

        # --------------------------------------------------
        # Dart release
        # --------------------------------------------------
        dart_cap_raw20 = valid20
        dart_cap_raw21 = valid21 & 0x03FF

        dart_gpio_raw20 = gpio_raw20
        dart_gpio_raw21 = gpio_raw21 & 0x03FF

        current_active = bool(dart_gpio_raw20 or dart_gpio_raw21)

        events.extend(
            self._handle_dart_release_if_needed(
                current_active,
                now_mono,
                now_ts
            )
        )

        # --------------------------------------------------
        # Dart capture latch
        # --------------------------------------------------
        self._update_dart_capture(
            dart_cap_raw20,
            dart_cap_raw21,
            now_mono
        )

        # --------------------------------------------------
        # Dart hit
        # --------------------------------------------------
        if not self._dart_pressed and self._dart_capture_started != 0.0:

            hit = self._decode_raw_hit(
                self._dart_capture_raw20,
                self._dart_capture_raw21
            )

            if hit is not None:

                if self.DEBUG_INPUT_EVENTS:
                    print(f"INPUT DART_HIT {hit}")

                events.append(
                    InputEvent(
                        type=EventType.DART_HIT,
                        payload=hit,
                        timestamp=now_ts,
                    )   
                )
                
                if current_active:
                    self._dart_pressed = True
                    self._dart_press_time = now_mono
                    self._dart_long_sent = False
                    self._dart_last_hit = hit
                    self._dart_current_active = True
                    self._dart_release_candidate_time = 0.0
                else:
                    self._clear_dart_state()

                self._clear_dart_capture()

            elif now_mono - self._dart_capture_started >= self.DART_CAPTURE_WINDOW_SEC:
                self._clear_dart_capture()

        self._last_raw20 = dart_gpio_raw20
        self._last_raw21 = dart_gpio_raw21

        if not current_active:
            self._last_raw20 = 0x0000
            self._last_raw21 = 0x0000

        self._clear_mcp_interrupts()

        return events

    def _clear_mcp_interrupts(self):
        try:
            self.bus.read_byte_data(0x20, self.MCP_GPIOA)
            self.bus.read_byte_data(0x20, self.MCP_GPIOB)
            self.bus.read_byte_data(0x21, self.MCP_GPIOA)
            self.bus.read_byte_data(0x21, self.MCP_GPIOB)
        except Exception:
            pass

    def _read_mcp_interrupt_sequence_for_clear(self):
        """
        DART_LONG_PRESS後のMCPラッチ解除用。
        通常INT処理と同じ順序で読み、最後のGPIO現在値を内部状態へ同期する。
        """
        try:
            # INTF
            self.bus.read_byte_data(0x20, self.MCP_INTFA)
            self.bus.read_byte_data(0x20, self.MCP_INTFB)
            self.bus.read_byte_data(0x21, self.MCP_INTFA)
            self.bus.read_byte_data(0x21, self.MCP_INTFB)

            # INTCAP
            self.bus.read_byte_data(0x20, self.MCP_INTCAPA)
            self.bus.read_byte_data(0x20, self.MCP_INTCAPB)
            self.bus.read_byte_data(0x21, self.MCP_INTCAPA)
            self.bus.read_byte_data(0x21, self.MCP_INTCAPB)

            # GPIO current
            g20a = self.bus.read_byte_data(0x20, self.MCP_GPIOA)
            g20b = self.bus.read_byte_data(0x20, self.MCP_GPIOB)
            g21a = self.bus.read_byte_data(0x21, self.MCP_GPIOA)
            g21b = self.bus.read_byte_data(0x21, self.MCP_GPIOB)

            gpio_raw20, gpio_raw21 = self._gpio_to_raw(
                g20a,
                g20b,
                g21a,
                g21b,
            )

            dart_gpio_raw20 = gpio_raw20
            dart_gpio_raw21 = gpio_raw21 & 0x03FF

            current_active = bool(dart_gpio_raw20 or dart_gpio_raw21)

            self._last_raw20 = dart_gpio_raw20
            self._last_raw21 = dart_gpio_raw21
            self._dart_current_active = current_active

            if not current_active:
                self._last_raw20 = 0x0000
                self._last_raw21 = 0x0000
                self._dart_release_candidate_time = 0.0

            return current_active

        except Exception:
            return self._dart_current_active


    # =========================================================
    # Dart press / release
    # =========================================================

    def _handle_dart_release_if_needed(
        self,
        current_active: bool,
        now_mono: float,
        now_ts: float,
    ):
        events = []

        if not self._dart_pressed:
            self._dart_current_active = current_active
            return events

        if current_active:
            self._dart_release_candidate_time = 0.0
            self._dart_current_active = True
            return events

        if not current_active:

            if self._dart_long_sent:
                if self.DEBUG_INPUT_EVENTS:
                    print(f"INPUT DART_LONG_PRESS_RELEASED {self._dart_last_hit}")

                events.append(
                    InputEvent(
                        type=EventType.DART_LONG_PRESS_RELEASED,
                        payload=self._dart_last_hit,
                        timestamp=now_ts,
                    )
                )

            # 通常リリースはイベントを出さず、内部状態だけ即クリア
            self._clear_dart_state()

            return events

    def _check_dart_long_press(self, now_mono: float, now_ts: float):
        events = []

        if not self._dart_pressed:
            return events

        if not self._dart_long_sent:
            if (now_mono - self._dart_press_time) < self.DART_LONG_PRESS_SEC:
                return events

            self._dart_long_sent = True
            self._dart_last_long_press_sent_monotonic = now_mono

            if self.DEBUG_INPUT_EVENTS:
                print(f"INPUT DART_LONG_PRESS {self._dart_last_hit}")

            events.append(
                InputEvent(
                    type=EventType.DART_LONG_PRESS,
                    payload=self._dart_last_hit,
                    timestamp=now_ts,
                )
            )

            # DART_LONG_PRESS発生後だけ、MCPのINT/INTCAPラッチ解除目的でGPIO read
            self._read_mcp_interrupt_sequence_for_clear()

            return events
        if (now_mono - self._dart_last_long_press_sent_monotonic) >= self.DART_LONG_PRESS_REPEAT_SEC:
            self._dart_last_long_press_sent_monotonic = now_mono

            if self.DEBUG_INPUT_EVENTS:
                print(f"INPUT DART_LONG_PRESS {self._dart_last_hit}")

            events.append(
                InputEvent(
                    type=EventType.DART_LONG_PRESS,
                    payload=self._dart_last_hit,
                    timestamp=now_ts,
                )
            )

            # DART_LONG_PRESS発生後だけ、MCPのINT/INTCAPラッチ解除目的でGPIO read
            self._read_mcp_interrupt_sequence_for_clear()

        return events

    def _clear_dart_state(self):
        self._dart_pressed = False
        self._dart_press_time = 0.0
        self._dart_long_sent = False
        self._dart_last_hit = None
        self._dart_current_active = False
        self._dart_release_candidate_time = 0.0
        self._dart_last_long_press_sent_monotonic = 0.0

        self._clear_dart_capture()

    def _update_dart_capture(self, raw20: int, raw21: int, now_mono: float):

        if raw20 == 0 and raw21 == 0:
            return

        if self._dart_capture_started == 0.0:
            self._dart_capture_started = now_mono

        self._dart_capture_raw20 |= raw20
        self._dart_capture_raw21 |= raw21

    def _clear_dart_capture(self):

        self._dart_capture_raw20 = 0x0000
        self._dart_capture_raw21 = 0x0000
        self._dart_capture_started = 0.0

    # =========================================================
    # Public helpers
    # =========================================================

    def set_coin_power(self, enable: bool):
        GPIO.output(self.GPIO_COINV, GPIO.HIGH if enable else GPIO.LOW)

    def cleanup(self):
        try:
            GPIO.output(self.GPIO_COINV, GPIO.LOW)
        except Exception:
            pass

        GPIO.cleanup()