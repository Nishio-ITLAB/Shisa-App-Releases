# hw_platform/io/tca9555.py

from smbus2 import SMBus


class TCA9555:
    """
    TCA9555 16bit IO expander
    """

    INPUT_PORT0 = 0x00
    INPUT_PORT1 = 0x01

    OUTPUT_PORT0 = 0x02
    OUTPUT_PORT1 = 0x03

    POLARITY_PORT0 = 0x04
    POLARITY_PORT1 = 0x05

    CONFIG_PORT0 = 0x06
    CONFIG_PORT1 = 0x07

    def __init__(self, bus: SMBus, address: int):
        self.bus = bus
        self.addr = address

        # 初回writeを必ず通す
        self.output_cache0 = None
        self.output_cache1 = None

    # --------------------------------------------------
    # config
    # --------------------------------------------------

    def set_direction(self, port0_mask: int, port1_mask: int):
        """
        1=input
        0=output
        """
        self.bus.write_byte_data(self.addr, self.CONFIG_PORT0, port0_mask)
        self.bus.write_byte_data(self.addr, self.CONFIG_PORT1, port1_mask)

    def disable_polarity_inversion(self):
        self.bus.write_byte_data(self.addr, self.POLARITY_PORT0, 0x00)
        self.bus.write_byte_data(self.addr, self.POLARITY_PORT1, 0x00)

    # --------------------------------------------------
    # read
    # --------------------------------------------------

    def read_inputs(self):
        p0 = self.bus.read_byte_data(self.addr, self.INPUT_PORT0)
        p1 = self.bus.read_byte_data(self.addr, self.INPUT_PORT1)
        return p0, p1

    def read_output_ports(self):
        p0 = self.bus.read_byte_data(self.addr, self.OUTPUT_PORT0)
        p1 = self.bus.read_byte_data(self.addr, self.OUTPUT_PORT1)
        return p0, p1

    def read_config_ports(self):
        p0 = self.bus.read_byte_data(self.addr, self.CONFIG_PORT0)
        p1 = self.bus.read_byte_data(self.addr, self.CONFIG_PORT1)
        return p0, p1

    # --------------------------------------------------
    # write
    # --------------------------------------------------

    def write_port0(self, value: int):
        value &= 0xFF
        if self.output_cache0 != value:
            self.output_cache0 = value
            self.bus.write_byte_data(self.addr, self.OUTPUT_PORT0, value)

    def write_port1(self, value: int):
        value &= 0xFF
        if self.output_cache1 != value:
            self.output_cache1 = value
            self.bus.write_byte_data(self.addr, self.OUTPUT_PORT1, value)

    def set_bit(self, port: int, bit: int, value: bool):

        if port == 0:
            v = 0 if self.output_cache0 is None else self.output_cache0
            if value:
                v |= (1 << bit)
            else:
                v &= ~(1 << bit)
            self.write_port0(v)

        else:
            v = 0 if self.output_cache1 is None else self.output_cache1
            if value:
                v |= (1 << bit)
            else:
                v &= ~(1 << bit)
            self.write_port1(v)