# hw_platform/io/mcp23017.py

from smbus2 import SMBus


class MCP23017:
    """
    MCP23017 I/O Expander Driver
    """

    # registers
    IODIRA = 0x00
    IODIRB = 0x01

    IOCON = 0x0A

    GPPUA = 0x0C
    GPPUB = 0x0D

    INTFA = 0x0E
    INTFB = 0x0F

    INTCAPA = 0x10
    INTCAPB = 0x11

    GPIOA = 0x12
    GPIOB = 0x13

    def __init__(self, bus: SMBus, address: int):
        self.bus = bus
        self.addr = address

    # --------------------------------------------------
    # init
    # --------------------------------------------------

    def initialize_inputs(self):
        """
        すべて入力 + pullup + interrupt
        """

        # all input
        self.bus.write_byte_data(self.addr, self.IODIRA, 0xFF)
        self.bus.write_byte_data(self.addr, self.IODIRB, 0xFF)

        # pull-up enable
        self.bus.write_byte_data(self.addr, self.GPPUA, 0xFF)
        self.bus.write_byte_data(self.addr, self.GPPUB, 0xFF)

        # IOCON
        # MIRROR=1 (INTA/Bまとめる)
        # ODR=1 (open drain)
        self.bus.write_byte_data(self.addr, self.IOCON, 0b01000100)

    # --------------------------------------------------
    # snapshot
    # --------------------------------------------------

    def read_interrupt_capture(self):
        """
        INTCAP snapshot
        """

        a = self.bus.read_byte_data(self.addr, self.INTCAPA)
        b = self.bus.read_byte_data(self.addr, self.INTCAPB)

        return a, b

    # --------------------------------------------------

    def read_gpio(self):
        """
        GPIO read (fallback)
        """

        a = self.bus.read_byte_data(self.addr, self.GPIOA)
        b = self.bus.read_byte_data(self.addr, self.GPIOB)

        return a, b

    # --------------------------------------------------

    def read_interrupt_flag(self):
        """
        INTF read
        """

        a = self.bus.read_byte_data(self.addr, self.INTFA)
        b = self.bus.read_byte_data(self.addr, self.INTFB)

        return a, b