# games/cricket/rules.py

from framework.input_types import DartHit, DartRing


CRICKET_TARGETS = {
    15,
    16,
    17,
    18,
    19,
    20,
}

BULL_TARGET = "BULL"

VALID_MODES = {
    "standard",
    "cut_throat",
}


def apply_hit(state, hit: DartHit) -> dict:
    """
    DartHitをクリケットルールで評価する。
    state自体は更新しない。
    controller側で戻り値をstateへ反映する。
    """

    if not isinstance(hit, DartHit):
        return build_empty_result(state, hit=None, valid=False)

    if state.mode_id not in VALID_MODES:
        raise ValueError(f"Unknown cricket mode_id: {state.mode_id}")

    target = _hit_to_target(hit)

    if target is None:
        return build_empty_result(state, hit=hit, valid=False)

    hit_marks = _hit_to_marks(hit)

    if hit_marks <= 0:
        return build_empty_result(state, hit=hit, valid=False)

    player = state.current_player
    marks_before = state.marks[player][target]

    need_marks = max(0, 3 - marks_before)
    applied_marks = min(hit_marks, need_marks)
    overflow_marks = hit_marks - applied_marks
    marks_after = min(3, marks_before + applied_marks)

    score_deltas = [0 for _ in range(state.players)]

    if overflow_marks > 0:
        score_deltas = _calculate_score_deltas(
            state=state,
            target=target,
            overflow_marks=overflow_marks,
            marks_after=marks_after,
        )

    closed = marks_before < 3 and marks_after >= 3

    return {
        "target": target,
        "hit_marks": hit_marks,
        "target_score": _target_score(target),
        "marks_before": marks_before,
        "marks_after": marks_after,
        "applied_marks": applied_marks,
        "overflow_marks": overflow_marks,
        "score_deltas": score_deltas,
        "closed": closed,
        "valid": True,
    }


def build_empty_result(state, hit: DartHit | None, valid: bool = False) -> dict:
    """
    MISS、SKIP、対象外ナンバーなど、マークも得点も発生しない結果を作る。
    """

    return {
        "target": None,
        "hit_marks": 0,
        "target_score": 0,
        "marks_before": None,
        "marks_after": None,
        "applied_marks": 0,
        "overflow_marks": 0,
        "score_deltas": [0 for _ in range(state.players)],
        "closed": False,
        "valid": valid,
    }


def build_miss_result(state) -> dict:
    """
    MISS用。
    1投として扱うかどうかはcontroller側で判断する。
    """
    return build_empty_result(state, hit=None, valid=False)


def build_throw_record(
    state,
    result: dict,
    hit: DartHit | None,
    is_miss: bool = False,
    is_skip: bool = False,
    closed_target_count: int = 0,
) -> dict:
    """
    throw_historyへ保存する1投分の記録を作る。
    """

    if is_miss:
        number = None
        ring = "MISS"
    elif is_skip:
        number = None
        ring = "SKIP"
    elif hit is not None:
        number = hit.number
        ring = hit.ring.name
    else:
        number = None
        ring = "UNKNOWN"

    return {
        "round_no": state.round_no,
        "player": state.current_player,
        "dart_no": state.dart_no,
        "mode_id": state.mode_id,

        "number": number,
        "ring": ring,

        "target": result.get("target"),
        "hit_marks": result.get("hit_marks", 0),
        "target_score": result.get("target_score", 0),

        "marks_before": result.get("marks_before"),
        "marks_after": result.get("marks_after"),
        "applied_marks": result.get("applied_marks", 0),
        "overflow_marks": result.get("overflow_marks", 0),

        "score_deltas": result.get(
            "score_deltas",
            [0 for _ in range(state.players)]
        ),

        "closed": result.get("closed", False),
        "valid": result.get("valid", False),

        # この投げを反映した後の、自プレイヤーのclosed済みターゲット数
        # 80%ルール用: 6エリアclosed到達dartを判定するために使う
        "closed_target_count": closed_target_count,


        "is_miss": bool(is_miss),
        "is_skip": bool(is_skip),
    }


def evaluate_turn_awards(turn_throws: list[dict]) -> list[str]:

    awards = []

    if len(turn_throws) < 3:
        return awards

    # 有効投球のみ抽出
    effective_throws = [
        t for t in turn_throws
        if _is_effective_throw(t)
    ]

    if len(effective_throws) < 3:
        return awards

    total_marks = sum(
        int(t.get("hit_marks", 0))
        for t in effective_throws
    )

    # パターン系（優先）
    if _is_white_horse(effective_throws):
        awards.append("white_horse")

    if _is_hat_trick(effective_throws):
        awards.append("hat_trick")

    if _is_3_in_a_bed(effective_throws):
        awards.append("3_in_a_bed")

    # mark系（完全一致）
    if total_marks == 9:
        awards.append("9_mark")

    elif total_marks == 7:
        awards.append("7_mark")

    elif total_marks == 5:
        awards.append("5_mark")

    return awards


def is_game_finished(state) -> bool:
    """
    ゲーム終了判定。
    - 全エリアクローズかつ得点トップなら即終了
    - ラウンド上限超過でも終了
    """

    if state.finished:
        return True

    if state.round_no > state.rounds:
        return True

    player = state.current_player

    if not is_all_closed(state, player):
        return False

    return is_score_leader(state, player)


def is_all_closed(state, player: int) -> bool:
    for target in state.targets:
        if state.marks[player][target] < 3:
            return False

    return True


def is_score_leader(state, player: int) -> bool:
    player_score = state.scores[player]

    if state.mode_id == "standard":
        for i, score in enumerate(state.scores):
            if i == player:
                continue

            if score > player_score:
                return False

        return True

    if state.mode_id == "cut_throat":
        for i, score in enumerate(state.scores):
            if i == player:
                continue

            if score < player_score:
                return False

        return True

    raise ValueError(f"Unknown cricket mode_id: {state.mode_id}")


def build_ranking(state) -> list[dict]:
    """
    リザルト用ランキングを作る。
    同点は competition ranking 方式。
    例: 100, 100, 80 => 1st, 1st, 3rd
    """

    rows = []

    for player in range(state.players):
        rows.append({
            "player": player,
            "label": f"PLAYER {player + 1}",
            "score": state.scores[player],
            "closed_count": count_closed_targets(state, player),
            "total_marks": count_total_marks(state, player),
        })

    rows.sort(
        key=lambda x: x["score"],
        reverse=(state.mode_id == "standard")
    )

    previous_score = None
    previous_rank = 0

    for index, row in enumerate(rows):
        rank = index + 1

        if previous_score is not None and row["score"] == previous_score:
            row["rank"] = previous_rank
        else:
            row["rank"] = rank
            previous_rank = rank

        row["rank_label"] = _format_rank(row["rank"])
        previous_score = row["score"]

    return rows


def count_closed_targets(state, player: int) -> int:
    count = 0

    for target in state.targets:
        if state.marks[player][target] >= 3:
            count += 1

    return count


def count_total_marks(state, player: int) -> int:
    total = 0

    for target in state.targets:
        total += min(3, state.marks[player][target])

    return total


def _calculate_score_deltas(state, target, overflow_marks: int, marks_after: int) -> list[int]:
    score_deltas = [0 for _ in range(state.players)]

    player = state.current_player
    score = _target_score(target) * overflow_marks

    if score <= 0:
        return score_deltas

    if state.mode_id == "standard":
        if marks_after >= 3 and _has_unclosed_opponent(state, player, target):
            score_deltas[player] += score

        return score_deltas

    if state.mode_id == "cut_throat":
        for opponent in range(state.players):
            if opponent == player:
                continue

            if state.marks[opponent][target] < 3:
                score_deltas[opponent] += score

        return score_deltas

    raise ValueError(f"Unknown cricket mode_id: {state.mode_id}")


def _has_unclosed_opponent(state, player: int, target) -> bool:
    """
    相手の誰かが対象エリアを未クローズならTrue。
    1人プレイでは練習モードとして常にTrue。
    """

    if state.players <= 1:
        return True

    for opponent in range(state.players):
        if opponent == player:
            continue

        if state.marks[opponent][target] < 3:
            return True

    return False


def _hit_to_target(hit: DartHit):
    if hit.ring == DartRing.OUTER_BULL:
        return BULL_TARGET

    if hit.ring == DartRing.INNER_BULL:
        return BULL_TARGET

    if hit.number in CRICKET_TARGETS:
        return hit.number

    return None


def _hit_to_marks(hit: DartHit) -> int:
    if hit.ring == DartRing.OUTER_BULL:
        return 1

    if hit.ring == DartRing.INNER_BULL:
        return 2

    return _ring_multiplier(hit.ring)


def _target_score(target) -> int:
    if target == BULL_TARGET:
        return 25

    if isinstance(target, int):
        return target

    return 0


def _ring_multiplier(ring: DartRing) -> int:
    if ring == DartRing.INNER_SINGLE:
        return 1

    if ring == DartRing.OUTER_SINGLE:
        return 1

    if ring == DartRing.DOUBLE:
        return 2

    if ring == DartRing.TRIPLE:
        return 3

    return 0


def _is_white_horse(turn_throws: list[dict]) -> bool:
    """
    WHITE HORSE:
    3投すべてが異なるクリケットナンバーのTRIPLE。
    Bullは除外。
    """

    if len(turn_throws) < 3:
        return False

    targets = set()

    for t in turn_throws:
        if not t.get("valid"):
            return False

        if t.get("target") == BULL_TARGET:
            return False

        if t.get("ring") != "TRIPLE":
            return False

        targets.add(t.get("target"))

    return len(targets) == 3


def _is_3_in_a_bed(turn_throws: list[dict]) -> bool:
    """
    3投すべてが同じクリケットナンバーのDOUBLEまたはTRIPLEならTrue。
    BullはHat Trick扱いとするため除外。
    """

    if len(turn_throws) < 3:
        return False

    first = turn_throws[0]

    if not first.get("valid"):
        return False

    if first.get("target") == BULL_TARGET:
        return False

    if first.get("ring") not in ("DOUBLE", "TRIPLE"):
        return False

    target = first.get("target")
    ring = first.get("ring")

    for t in turn_throws:
        if not t.get("valid"):
            return False

        if t.get("target") != target:
            return False

        if t.get("ring") != ring:
            return False

    return True


def _is_hat_trick(turn_throws: list[dict]) -> bool:
    """
    3投すべてがBullならTrue。
    S-BULL / D-BULL 混在可。
    """

    if len(turn_throws) < 3:
        return False

    for t in turn_throws:
        if t.get("target") != BULL_TARGET:
            return False

    return True

def _is_effective_throw(t: dict) -> bool:
    if not t.get("valid"):
        return False

    if int(t.get("applied_marks", 0)) > 0:
        return True

    if any(delta != 0 for delta in t.get("score_deltas", [])):
        return True

    return False

def _format_rank(rank: int) -> str:
    if rank == 1:
        return "1st"

    if rank == 2:
        return "2nd"

    if rank == 3:
        return "3rd"

    return f"{rank}th"