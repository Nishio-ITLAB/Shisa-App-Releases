# games/countup/rules.py

from framework.input_types import DartHit, DartRing


CRICKET_TARGETS = {15, 16, 17, 18, 19, 20}


def score_hit(mode_id: str, hit: DartHit) -> int:
    """
    DartHitをCOUNT-UP系ゲームの得点に変換する。
    """

    if mode_id == "count_up":
        return _score_normal_countup(hit)

    if mode_id == "cr_count_up":
        return _score_cricket_countup(hit)

    raise ValueError(f"Unknown countup mode_id: {mode_id}")


def score_miss() -> int:
    """
    MISSは0点。
    1投として扱うかどうかはcontroller側で判断する。
    """
    return 0


def _score_normal_countup(hit: DartHit) -> int:
    """
    通常COUNT-UP。
    全ナンバー得点対象。
    """

    if hit.ring == DartRing.OUTER_BULL:
        return 25

    if hit.ring == DartRing.INNER_BULL:
        return 50

    if hit.number is None:
        return 0

    multiplier = _ring_multiplier(hit.ring)
    return hit.number * multiplier


def _score_cricket_countup(hit: DartHit) -> int:
    """
    CR.COUNT-UP。
    15〜20 + BULLのみ得点対象。
    対象外は0点。ただし投数は進む。
    """

    if hit.ring == DartRing.OUTER_BULL:
        return 25

    if hit.ring == DartRing.INNER_BULL:
        return 50

    if hit.number not in CRICKET_TARGETS:
        return 0

    multiplier = _ring_multiplier(hit.ring)
    return hit.number * multiplier


def _ring_multiplier(ring: DartRing) -> int:
    if ring == DartRing.INNER_SINGLE:
        return 1

    if ring == DartRing.OUTER_SINGLE:
        return 1

    if ring == DartRing.DOUBLE:
        return 2

    if ring == DartRing.TRIPLE:
        return 3

    return 0


def build_throw_record(state, score: int, hit: DartHit | None, is_miss: bool = False) -> dict:
    """
    throw_historyへ保存する1投分の記録を作る。
    """

    if is_miss:
        number = None
        ring = "MISS"
    elif hit is not None:
        number = hit.number
        ring = hit.ring.name
    else:
        number = None
        ring = "UNKNOWN"

    return {
        "round_no": state.round_no,
        "player": state.current_player,
        "dart_no": state.dart_no,
        "mode_id": state.mode_id,
        "score": score,
        "number": number,
        "ring": ring,
    }


def evaluate_turn_awards(turn_throws: list[dict]) -> list[str]:
    awards = []

    if not turn_throws:
        return awards

    turn_score = sum(t["score"] for t in turn_throws)

    # TON系
    if _is_ton80(turn_throws):
        awards.append("ton_80")

    elif turn_score >= 150:
        awards.append("high_ton")

    elif turn_score >= 100:
        awards.append("low_ton")

    # Shisa Eye（Inner Bull × 3）
    if _is_shisa_eye(turn_throws):
        awards.append("shisa_eye")

    # Hat Trick
    if _is_hat_trick(turn_throws):
        awards.append("hat_trick")

    # THREE IN A BED
    if _is_3_in_a_bed(turn_throws):
        awards.append("3_in_a_bed")     

    return awards


def _is_ton80(turn_throws: list[dict]) -> bool:
    if len(turn_throws) < 3:
        return False

    for t in turn_throws:
        if t["number"] != 20:
            return False
        if t["ring"] != "TRIPLE":
            return False

    return True


def _is_3_in_a_bed(turn_throws: list[dict]) -> bool:
    """
    3投すべてが同じナンバーのTRIPLEならTrue。
    BullはHat Trick扱いとするため除外。
    CR.COUNT-UPでは15〜20のみ対象。
    """

    if len(turn_throws) < 3:
        return False

    first = turn_throws[0]

    if first["number"] is None:
        return False

    if first["ring"] != "TRIPLE":
        return False

    # CR.COUNT-UPでは15〜20のみ対象
    if first["mode_id"] == "cr_count_up" and first["number"] not in CRICKET_TARGETS:
        return False

    for t in turn_throws:
        if t["number"] != first["number"]:
            return False

        if t["ring"] != "TRIPLE":
            return False

        if t["score"] <= 0:
            return False

    return True


def _is_shisa_eye(turn_throws: list[dict]) -> bool:
    """
    3投すべてがINNER_BULLならTrue。
    Hat Trickの上位版。
    """

    if len(turn_throws) < 3:
        return False

    for t in turn_throws:
        if t["ring"] != "INNER_BULL":
            return False

    return True


def _is_hat_trick(turn_throws: list[dict]) -> bool:
    """
    3投すべてがBullならTrue
    """

    if len(turn_throws) < 3:
        return False

    for t in turn_throws:
        if t["ring"] not in ("INNER_BULL", "OUTER_BULL"):
            return False

    return True


def is_game_finished(state) -> bool:
    return state.round_no > state.rounds