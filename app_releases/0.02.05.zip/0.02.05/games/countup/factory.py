# games/countup/factory.py

from .state import CountupState
from .controller import CountupController


VALID_MODES = {
    "count_up",
    "cr_count_up",
}

MIN_PLAYERS = 1
MAX_PLAYERS = 4


def create_game(engine, mode_id, players):
    """
    COUNT-UPゲーム生成入口。
    MenuSceneから呼ばれる。

    - mode_id: "count_up" / "cr_count_up"
    - players: 1〜4
    """

    if mode_id not in VALID_MODES:
        raise ValueError(f"Unknown countup mode_id: {mode_id}")

    players = int(players)

    if players < MIN_PLAYERS or players > MAX_PLAYERS:
        raise ValueError(f"Invalid players: {players}")

    settings = engine.game_config.get_settings("countup")

    rounds = int(settings.get("rounds", 8))
    undo_limit = int(settings.get("undo_limit", 5))

    state = CountupState(
        mode_id=mode_id,
        players=players,
        rounds=rounds,
        undo_limit=undo_limit,
    )

    controller = CountupController(
        engine=engine,
        state=state,
    )

    return controller