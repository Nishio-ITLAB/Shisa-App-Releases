# games/countup/state.py

class CountupState:

    def __init__(self, mode_id, players, rounds, undo_limit):
        self.mode_id = mode_id
        self.players = players
        self.rounds = rounds
        self.undo_limit = undo_limit

        # 各プレイヤーの合計点
        self.scores = [0 for _ in range(players)]

        # 各ラウンドのプレイヤー別得点
        # round_scores[round_index][player_index]
        self.round_scores = [
            [0 for _ in range(players)]
            for _ in range(rounds)
        ]

        # 各投の履歴
        self.throw_history = []

        self.current_player = 0
        self.round_no = 1
        self.dart_no = 1

        self.finished = False

        # 次投までのウェイト
        self.waiting_for_throw_collect = False
        self.throw_collect_ready_at = 0.0
        self.pending_next_player = False
        self.throw_collect_message = None
        self.start_sequence_active = True
        self.start_ready_at = 0.0
        self.finish_pending = False
        self.finish_at = 0.0
        self.throw_collect_blink_immediate = False
        self.pending_awards = []
        self.pending_award_ready_at = 0.0
        self.pending_award_active = False

        # Undo用
        self.last_snapshot = None
        self.undo_used = 0

        # 一時オプション
        self.count_miss_as_throw = True

        # カットイン表示
        self.cutin_active = False
        self.cutin_start_time = 0.0

        # ポーズモード
        self.pause_mode = False
        self.pause_index = 0
        self.pause_confirm_mode = False
        self.pause_confirm_target = None

        # 長押し警告表示用
        self.stuck_dart_message = None
        self.stuck_dart_until = 0.0      

        # 入力ロック
        self.input_locked_until = 0.0

        # 今再生中の演出（デバッグ/拡張用）
        self.current_award = None