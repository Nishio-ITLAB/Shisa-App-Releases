# framework/renderer.py

import os
os.environ["PYOPENGL_PLATFORM"] = "egl"

import ctypes
import sdl2
from ctypes import c_void_p
import numpy as np
from OpenGL import GL


class Renderer:
    """
    Dual pipeline renderer

    [VIDEO PIPELINE] 旧互換（NDC固定フルスクリーンクアッド）
      - draw_solid(): swap内包
      - blit_rgba_frame(): swap内包
      ※ video_player.py はこの挙動を前提にしている

    [UI PIPELINE] 左上原点ピクセル座標
      - ui_clear(): swapしない
      - ui_draw_*(): swapしない
      - ui_swap(): swapする（Scene側が1フレーム1回呼ぶ）
    """

    def __init__(self, width=1280, height=720):
        self.width = width
        self.height = height

        self.window = None
        self.ctx = None

        # ---- VIDEO pipeline resources ----
        self.prog_video = None
        self.vbo_video = None
        self.tex_video = None
        self.u_tex_loc_video = None

        # ---- UI pipeline resources ----
        self.prog_ui = None
        self.vbo_ui = None
        self.tex_ui = None
        self.u_tex_loc_ui = None
        self.u_screen_loc_ui = None

        self._init_sdl_gl()
        self._init_video_pipeline()  # 旧互換を最優先
        self._init_ui_pipeline()

    # --------------------------------------------------
    # SDL + GL INIT
    # --------------------------------------------------
    def _init_sdl_gl(self):
        sdl2.SDL_Init(sdl2.SDL_INIT_VIDEO)

        sdl2.SDL_GL_SetAttribute(sdl2.SDL_GL_CONTEXT_MAJOR_VERSION, 2)
        sdl2.SDL_GL_SetAttribute(sdl2.SDL_GL_CONTEXT_MINOR_VERSION, 0)
        sdl2.SDL_GL_SetAttribute(
            sdl2.SDL_GL_CONTEXT_PROFILE_MASK,
            sdl2.SDL_GL_CONTEXT_PROFILE_ES
        )

        self.window = sdl2.SDL_CreateWindow(
            b"SHISA",
            sdl2.SDL_WINDOWPOS_CENTERED,
            sdl2.SDL_WINDOWPOS_CENTERED,
            self.width, self.height,
            sdl2.SDL_WINDOW_OPENGL
        )

        self.ctx = sdl2.SDL_GL_CreateContext(self.window)
        sdl2.SDL_GL_MakeCurrent(self.window, self.ctx)

        # vsync要求（環境により無視される場合あり）
        sdl2.SDL_GL_SetSwapInterval(1)

        sdl2.SDL_ShowCursor(sdl2.SDL_DISABLE)

        GL.glViewport(0, 0, self.width, self.height)

    # --------------------------------------------------
    # Shader compile helper
    # --------------------------------------------------
    def _compile_program(self, vs_src: str, fs_src: str):
        vs = GL.glCreateShader(GL.GL_VERTEX_SHADER)
        GL.glShaderSource(vs, vs_src)
        GL.glCompileShader(vs)

        fs = GL.glCreateShader(GL.GL_FRAGMENT_SHADER)
        GL.glShaderSource(fs, fs_src)
        GL.glCompileShader(fs)

        prog = GL.glCreateProgram()
        GL.glAttachShader(prog, vs)
        GL.glAttachShader(prog, fs)
        GL.glLinkProgram(prog)

        return prog

    # --------------------------------------------------
    # VIDEO PIPELINE (旧互換: NDC固定)
    # --------------------------------------------------
    def _init_video_pipeline(self):
        # ★完全に元の設計（NDC固定）に戻す
        vs_src = """
        attribute vec2 a_pos;
        attribute vec2 a_uv;
        varying vec2 v_uv;
        void main() {
            gl_Position = vec4(a_pos, 0.0, 1.0);
            v_uv = a_uv;
        }
        """

        fs_src = """
        precision mediump float;
        varying vec2 v_uv;
        uniform sampler2D u_tex;
        void main() {
            gl_FragColor = texture2D(u_tex, v_uv);
        }
        """

        self.prog_video = self._compile_program(vs_src, fs_src)
        GL.glUseProgram(self.prog_video)

        # 旧互換フルスクリーンクアッド（TRIANGLE_STRIP）
        quad = np.array([
            -1.0, -1.0, 0.0, 1.0,
             1.0, -1.0, 1.0, 1.0,
            -1.0,  1.0, 0.0, 0.0,
             1.0,  1.0, 1.0, 0.0,
        ], dtype=np.float32)

        self.vbo_video = GL.glGenBuffers(1)
        GL.glBindBuffer(GL.GL_ARRAY_BUFFER, self.vbo_video)
        GL.glBufferData(GL.GL_ARRAY_BUFFER, quad.nbytes, quad, GL.GL_STATIC_DRAW)

        pos_loc = GL.glGetAttribLocation(self.prog_video, "a_pos")
        uv_loc = GL.glGetAttribLocation(self.prog_video, "a_uv")

        GL.glEnableVertexAttribArray(pos_loc)
        GL.glVertexAttribPointer(pos_loc, 2, GL.GL_FLOAT, GL.GL_FALSE, 16, c_void_p(0))

        GL.glEnableVertexAttribArray(uv_loc)
        GL.glVertexAttribPointer(uv_loc, 2, GL.GL_FLOAT, GL.GL_FALSE, 16, c_void_p(8))

        self.tex_video = GL.glGenTextures(1)
        GL.glActiveTexture(GL.GL_TEXTURE0)
        GL.glBindTexture(GL.GL_TEXTURE_2D, self.tex_video)

        GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MIN_FILTER, GL.GL_LINEAR)
        GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MAG_FILTER, GL.GL_LINEAR)
        GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_WRAP_S, GL.GL_CLAMP_TO_EDGE)
        GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_WRAP_T, GL.GL_CLAMP_TO_EDGE)

        self.u_tex_loc_video = GL.glGetUniformLocation(self.prog_video, "u_tex")
        if self.u_tex_loc_video != -1:
            GL.glUniform1i(self.u_tex_loc_video, 0)

    def _use_video(self):
        GL.glUseProgram(self.prog_video)
        GL.glViewport(0, 0, self.width, self.height)

        GL.glDisable(GL.GL_BLEND)

        GL.glBindBuffer(GL.GL_ARRAY_BUFFER, self.vbo_video)

        GL.glActiveTexture(GL.GL_TEXTURE0)
        GL.glBindTexture(GL.GL_TEXTURE_2D, self.tex_video)

        # attrib pointer は VBO/Program に依存するので毎回セット（安全側）
        pos_loc = GL.glGetAttribLocation(self.prog_video, "a_pos")
        uv_loc = GL.glGetAttribLocation(self.prog_video, "a_uv")

        GL.glEnableVertexAttribArray(pos_loc)
        GL.glVertexAttribPointer(pos_loc, 2, GL.GL_FLOAT, GL.GL_FALSE, 16, c_void_p(0))

        GL.glEnableVertexAttribArray(uv_loc)
        GL.glVertexAttribPointer(uv_loc, 2, GL.GL_FLOAT, GL.GL_FALSE, 16, c_void_p(8))

    # ---- VIDEO API（旧互換）----
    def draw_solid(self, r, g, b):
        self._use_video()
        GL.glClearColor(r, g, b, 1.0)
        GL.glClear(GL.GL_COLOR_BUFFER_BIT)
        sdl2.SDL_GL_SwapWindow(self.window)

    def blit_rgba_frame(self, width, height, rgba_np):
        self._use_video()

        GL.glTexImage2D(
            GL.GL_TEXTURE_2D, 0, GL.GL_RGBA,
            int(width), int(height), 0,
            GL.GL_RGBA, GL.GL_UNSIGNED_BYTE, rgba_np
        )

        GL.glClear(GL.GL_COLOR_BUFFER_BIT)
        GL.glDrawArrays(GL.GL_TRIANGLE_STRIP, 0, 4)

        sdl2.SDL_GL_SwapWindow(self.window)

    # --------------------------------------------------
    # UI PIPELINE (左上原点ピクセル座標)
    # --------------------------------------------------
    def _init_ui_pipeline(self):
        vs_src = """
        attribute vec2 a_pos;
        attribute vec2 a_uv;
        varying vec2 v_uv;

        uniform vec2 u_screen;

        void main() {
            vec2 ndc = vec2(
                (a_pos.x / u_screen.x) * 2.0 - 1.0,
                1.0 - (a_pos.y / u_screen.y) * 2.0
            );
            gl_Position = vec4(ndc, 0.0, 1.0);
            v_uv = a_uv;
        }
        """

        fs_src = """
        precision mediump float;
        varying vec2 v_uv;
        uniform sampler2D u_tex;

        void main() {
            gl_FragColor = texture2D(u_tex, v_uv);
        }
        """

        self.prog_ui = self._compile_program(vs_src, fs_src)
        GL.glUseProgram(self.prog_ui)

        self.vbo_ui = GL.glGenBuffers(1)
        GL.glBindBuffer(GL.GL_ARRAY_BUFFER, self.vbo_ui)

        pos_loc = GL.glGetAttribLocation(self.prog_ui, "a_pos")
        uv_loc = GL.glGetAttribLocation(self.prog_ui, "a_uv")

        GL.glEnableVertexAttribArray(pos_loc)
        GL.glVertexAttribPointer(pos_loc, 2, GL.GL_FLOAT, GL.GL_FALSE, 16, c_void_p(0))

        GL.glEnableVertexAttribArray(uv_loc)
        GL.glVertexAttribPointer(uv_loc, 2, GL.GL_FLOAT, GL.GL_FALSE, 16, c_void_p(8))

        self.tex_ui = GL.glGenTextures(1)
        GL.glActiveTexture(GL.GL_TEXTURE0)
        GL.glBindTexture(GL.GL_TEXTURE_2D, self.tex_ui)

        GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MIN_FILTER, GL.GL_LINEAR)
        GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MAG_FILTER, GL.GL_LINEAR)
        GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_WRAP_S, GL.GL_CLAMP_TO_EDGE)
        GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_WRAP_T, GL.GL_CLAMP_TO_EDGE)

        self.u_tex_loc_ui = GL.glGetUniformLocation(self.prog_ui, "u_tex")
        if self.u_tex_loc_ui != -1:
            GL.glUniform1i(self.u_tex_loc_ui, 0)

        self.u_screen_loc_ui = GL.glGetUniformLocation(self.prog_ui, "u_screen")
        if self.u_screen_loc_ui != -1:
            GL.glUniform2f(self.u_screen_loc_ui, float(self.width), float(self.height))

    def _use_ui(self):
        GL.glUseProgram(self.prog_ui)
        GL.glViewport(0, 0, self.width, self.height)

        GL.glEnable(GL.GL_BLEND)
        GL.glBlendFunc(GL.GL_SRC_ALPHA, GL.GL_ONE_MINUS_SRC_ALPHA)

        GL.glBindBuffer(GL.GL_ARRAY_BUFFER, self.vbo_ui)

        GL.glActiveTexture(GL.GL_TEXTURE0)
        GL.glBindTexture(GL.GL_TEXTURE_2D, self.tex_ui)

        pos_loc = GL.glGetAttribLocation(self.prog_ui, "a_pos")
        uv_loc = GL.glGetAttribLocation(self.prog_ui, "a_uv")

        GL.glEnableVertexAttribArray(pos_loc)
        GL.glVertexAttribPointer(pos_loc, 2, GL.GL_FLOAT, GL.GL_FALSE, 16, c_void_p(0))

        GL.glEnableVertexAttribArray(uv_loc)
        GL.glVertexAttribPointer(uv_loc, 2, GL.GL_FLOAT, GL.GL_FALSE, 16, c_void_p(8))

        # u_screen はピクセル座標変換に必須
        if self.u_screen_loc_ui != -1:
            GL.glUniform2f(self.u_screen_loc_ui, float(self.width), float(self.height))

    # ---- UI API ----
    def ui_clear(self, r, g, b, a=1.0):
        self._use_ui()
        GL.glClearColor(r, g, b, a)
        GL.glClear(GL.GL_COLOR_BUFFER_BIT)

    def ui_swap(self):
        sdl2.SDL_GL_SwapWindow(self.window)

    def ui_draw_texture(self, x, y, w, h, rgba_np):
        self._use_ui()

        ww = int(w)
        hh = int(h)
        if ww <= 0 or hh <= 0:
            return

        GL.glTexImage2D(
            GL.GL_TEXTURE_2D, 0, GL.GL_RGBA,
            ww, hh, 0,
            GL.GL_RGBA, GL.GL_UNSIGNED_BYTE, rgba_np
        )

        # 2 triangles (6 vertices)
        vertices = np.array([
            x,     y,     0.0, 0.0,
            x + w, y,     1.0, 0.0,
            x,     y + h, 0.0, 1.0,

            x + w, y,     1.0, 0.0,
            x + w, y + h, 1.0, 1.0,
            x,     y + h, 0.0, 1.0,
        ], dtype=np.float32)

        GL.glBufferData(GL.GL_ARRAY_BUFFER, vertices.nbytes, vertices, GL.GL_DYNAMIC_DRAW)
        GL.glDrawArrays(GL.GL_TRIANGLES, 0, 6)

    def ui_draw_rect(self, x, y, w, h, color):
        r, g, b, a = color
        ww = int(w)
        hh = int(h)
        if ww <= 0 or hh <= 0:
            return

        img = np.empty((hh, ww, 4), dtype=np.uint8)
        img[..., 0] = int(max(0.0, min(1.0, r)) * 255)
        img[..., 1] = int(max(0.0, min(1.0, g)) * 255)
        img[..., 2] = int(max(0.0, min(1.0, b)) * 255)
        img[..., 3] = int(max(0.0, min(1.0, a)) * 255)

        self.ui_draw_texture(x, y, w, h, img)

    # --------------------------------------------------
    def pump_events(self):
        ev = sdl2.SDL_Event()
        while sdl2.SDL_PollEvent(ctypes.byref(ev)) != 0:
            if ev.type == sdl2.SDL_QUIT:
                return False
        return True
