# framework/engine.py

import time
from pathlib import Path

from framework.renderer import Renderer
from framework.audio_player import AudioPlayer
from framework.video_player import VideoPlayer
from framework.input_manager import InputManager
from framework.scenes.boot import BootScene

from framework.config.system_config import SystemConfig
from framework.config.game_config import GameConfig
from framework.overlay import Overlay
from framework.input_types import EventType

from hw_platform.io.led_manager import LedManager


class Engine:
    """
    Engine = オーケストレータ
    """

    def __init__(self):
        self.running = True

        self.renderer = Renderer(1920, 1080)

        self.audio = AudioPlayer()
        self.video = VideoPlayer(self.renderer, self.audio)
        self.input = InputManager()

        self.led = LedManager()

        # 当config内で各persistの初期値を定義
        self.system_config = SystemConfig()
        self.game_config = GameConfig()

        # ★ Overlayも同一config参照
        self.overlay = Overlay(self)

        self.asset_check = self._check_assets_version()

        self.scene = BootScene(self)

    def _parse_version_tuple(self, version_str):
        try:
            return tuple(int(p) for p in version_str.strip().split("."))
        except Exception:
            return None

    def _read_required_assets_version(self):
        try:
            path = Path("/opt/shisa/current/version.txt")
            lines = path.read_text().splitlines()

            for line in lines[2:]:
                line = line.strip()
                if line.startswith("required_assets="):
                    return line.split("=", 1)[1].strip()

            return ""

        except Exception as e:
            print("READ REQUIRED ASSETS ERROR:", e)
            return ""

    def _read_current_assets_version(self):
        try:
            path = Path("/opt/shisa/current/assets/version.txt")
            lines = path.read_text().splitlines()
            return lines[0].strip() if lines else ""

        except Exception as e:
            print("READ CURRENT ASSETS ERROR:", e)
            return ""

    def _check_assets_version(self):
        required = self._read_required_assets_version()
        current = self._read_current_assets_version()

        result = {
            "ok": True,
            "reason": "",
            "required": required if required else "-",
            "current": current if current else "-",
        }

        if not required:
            result["ok"] = True
            result["reason"] = "NO REQUIRED ASSETS"
            print("ASSET CHECK: no required_assets")
            return result

        if not current:
            result["ok"] = False
            result["reason"] = "ASSET VERSION MISSING"
            print("ASSET CHECK NG: current assets version missing")
            return result

        req_tuple = self._parse_version_tuple(required)
        cur_tuple = self._parse_version_tuple(current)

        if req_tuple is None:
            result["ok"] = False
            result["reason"] = "REQUIRED ASSETS VERSION INVALID"
            print("ASSET CHECK NG: required assets version invalid")
            return result

        if cur_tuple is None:
            result["ok"] = False
            result["reason"] = "CURRENT ASSETS VERSION INVALID"
            print("ASSET CHECK NG: current assets version invalid")
            return result

        if cur_tuple < req_tuple:
            result["ok"] = False
            result["reason"] = "ASSET VERSION TOO OLD"
            print(f"ASSET CHECK NG: required={required}, current={current}")
            return result

        result["ok"] = True
        result["reason"] = "ASSET VERSION OK"
        print(f"ASSET CHECK OK: required={required}, current={current}")
        return result

    def stop(self):
        self.running = False

    def run(self):
        while self.running and self.scene is not None:

            # -------------------------
            # 1. 入力取得
            # -------------------------
            events = self.input.poll()

            # -------------------------
            # 2. Engineレベル処理
            # -------------------------
            for e in events:
                if e.type == EventType.COIN:
                    self.system_config.insert_coin()
                    self.audio.play("coin")

            # -------------------------
            # 3. Sceneへ渡す
            # -------------------------
            self.scene.set_events(events)

            # -------------------------
            # 4. Scene実行
            # -------------------------
            self.scene = self.scene.run()

            time.sleep(0.001)
