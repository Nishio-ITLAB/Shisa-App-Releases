# framework/config/game_config.py

import json
import os
from pathlib import Path


class GameConfig:
    """
    ゲーム設定管理クラス
    まずは各モードの有効/無効のみ管理する
    """

    DEFAULT_COUNTUP_DATA = {
        "schema_version": 1,
        "settings": {
            "undo_limit": 5,
            "rounds": 8
        },
        "modes": {
            "count_up": True,
            "cr_count_up": True,
        }
    }

    DEFAULT_ZERO1_DATA = {
        "schema_version": 1,
        "settings": {
            "undo_limit": 5,
            "rounds": {
                "301": 10,
                "501": 15,
                "701": 20,
                "901": 20,
                "1101": 20,
                "1501": 20,
            }
        },
        "modes": {
            "301": True,
            "501": True,
            "701": True,
            "901": True,
            "1101": True,
            "1501": True,
        }
    }

    DEFAULT_CRICKET_DATA = {
        "schema_version": 1,
        "settings": {
            "undo_limit": 5,
            "rounds": 20
        },
        "modes": {
            "standard": True,
            "cut_throat": True,
        }
    }

    def __init__(self):
        base_dir = Path(__file__).resolve().parents[4]
        self._persist_dir = base_dir / "persist" / "games"

        self._countup_path = self._persist_dir / "countup.json"
        self._zero1_path = self._persist_dir / "zero1.json"
        self._cricket_path = self._persist_dir / "cricket.json"

        self._countup_data = {}
        self._zero1_data = {}
        self._cricket_data = {}

        self._persist_dir.mkdir(parents=True, exist_ok=True)

        self._ensure_storage()
        self._load_all()

    # --------------------------------------------------
    # init
    # --------------------------------------------------

    def _ensure_storage(self):
        self._ensure_file(self._countup_path, self.DEFAULT_COUNTUP_DATA)
        self._ensure_file(self._zero1_path, self.DEFAULT_ZERO1_DATA)
        self._ensure_file(self._cricket_path, self.DEFAULT_CRICKET_DATA)

    def _ensure_file(self, path: Path, default_data: dict):
        if not path.exists():
            self._atomic_save(path, default_data)

    def _load_all(self):
        self._countup_data = self._load_with_defaults(
            self._countup_path,
            self.DEFAULT_COUNTUP_DATA
        )
        self._zero1_data = self._load_with_defaults(
            self._zero1_path,
            self.DEFAULT_ZERO1_DATA
        )
        self._cricket_data = self._load_with_defaults(
            self._cricket_path,
            self.DEFAULT_CRICKET_DATA
        )

    def reload(self):
        self._load_all()

    # --------------------------------------------------
    # load/save helpers
    # --------------------------------------------------

    def _load_with_defaults(self, path: Path, default_data: dict):
        try:
            with open(path, "r", encoding="utf-8") as f:
                loaded = json.load(f)
        except Exception:
            loaded = {}

        merged = {
            "schema_version": default_data["schema_version"],
            "modes": default_data["modes"].copy()
        }

        if "settings" in default_data:
            merged["settings"] = self._deep_copy(default_data["settings"])

        if isinstance(loaded, dict):
            if isinstance(loaded.get("modes"), dict):
                merged["modes"].update(loaded["modes"])

            if "settings" in merged and isinstance(loaded.get("settings"), dict):
                self._deep_update(merged["settings"], loaded["settings"])

        if loaded.get("schema_version") != default_data["schema_version"]:
            self._atomic_save(path, merged)

        return merged

    def _atomic_save(self, path: Path, data: dict):
        tmp_path = path.with_suffix(path.suffix + ".tmp")

        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
            f.flush()
            os.fsync(f.fileno())

        os.replace(tmp_path, path)

    def _deep_copy(self, value):
        if isinstance(value, dict):
            return {
                k: self._deep_copy(v)
                for k, v in value.items()
            }

        return value

    def _deep_update(self, base: dict, override: dict):
        for key, value in override.items():
            if (
                key in base
                and isinstance(base[key], dict)
                and isinstance(value, dict)
            ):
                self._deep_update(base[key], value)
            else:
                base[key] = value

    # --------------------------------------------------
    # getters
    # --------------------------------------------------

    def is_mode_enabled(self, family: str, mode_id: str) -> bool:
        data = self._get_family_data(family)
        return bool(data["modes"].get(mode_id, False))

    def get_settings(self, family: str) -> dict:
        data = self._get_family_data(family)
        return data.get("settings", {}).copy()

    def get_enabled_modes(self, family: str) -> dict:
        data = self._get_family_data(family)
        return data["modes"].copy()

    def _get_family_data(self, family: str) -> dict:
        if family == "countup":
            return self._countup_data
        elif family == "zero1":
            return self._zero1_data
        elif family == "cricket":
            return self._cricket_data
        else:
            raise ValueError(f"Unknown game family: {family}")

    # --------------------------------------------------
    # setters
    # --------------------------------------------------

    def set_mode_enabled(self, family: str, mode_id: str, enabled: bool):
        data = self._get_family_data(family)

        if mode_id not in data["modes"]:
            raise ValueError(f"Unknown mode_id: {family}/{mode_id}")

        data["modes"][mode_id] = bool(enabled)
        self._save_family(family)

    def set_setting(self, family: str, key: str, value):
        data = self._get_family_data(family)

        if "settings" not in data:
            data["settings"] = {}

        data["settings"][key] = value
        self._save_family(family)

    def _save_family(self, family: str):
        if family == "countup":
            self._atomic_save(self._countup_path, self._countup_data)
        elif family == "zero1":
            self._atomic_save(self._zero1_path, self._zero1_data)
        elif family == "cricket":
            self._atomic_save(self._cricket_path, self._cricket_data)
        else:
            raise ValueError(f"Unknown game family: {family}")            

    def get_zero1_rounds(self, mode_id: str) -> int:
        rounds = self._zero1_data.get("settings", {}).get("rounds", {})
        return int(rounds.get(mode_id, self.DEFAULT_ZERO1_DATA["settings"]["rounds"][mode_id]))

    def set_zero1_rounds(self, mode_id: str, rounds: int):
        if mode_id not in self._zero1_data["modes"]:
            raise ValueError(f"Unknown zero1 mode_id: {mode_id}")

        if "settings" not in self._zero1_data:
            self._zero1_data["settings"] = {}

        if not isinstance(self._zero1_data["settings"].get("rounds"), dict):
            self._zero1_data["settings"]["rounds"] = {}

        self._zero1_data["settings"]["rounds"][mode_id] = int(rounds)
        self._save_family("zero1")


