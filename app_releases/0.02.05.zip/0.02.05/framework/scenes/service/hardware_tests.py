# framework/scenes/service/hardware_tests.py

import math
import time
import numpy as np
from PIL import Image, ImageDraw, ImageFont

from framework.scene import Scene
from framework.input_types import EventType, ButtonType, DartRing

# --- AUTO TEST ADD ---
from framework.scenes.service.hardware_auto_test import HardwareAutoTest


FONT_PATH = "/opt/shisa/current/system_assets/fonts/NotoSansMono-Regular.ttf"


class HardwareTestsScene(Scene):

    def __init__(self, engine):
        super().__init__(engine)

        self.r = self.engine.renderer
        self.W = self.r.width
        self.H = self.r.height

        self.title_font = ImageFont.truetype(FONT_PATH, int(self.H * 0.06))
        self.info_font = ImageFont.truetype(FONT_PATH, int(self.H * 0.04))

        # 数字サイズを少し小さく
        self.num_font = ImageFont.truetype(FONT_PATH, int(self.H * 0.028))

        # --- AUTO TEST ADD ---
        # ログ表示はさらに小さく
        self.log_font = ImageFont.truetype(FONT_PATH, int(self.H * 0.020))

        self.text_cache = {}

        self.cx = self.W // 2

        # 盤を少し上に移動
        self.cy = int(self.H * 0.52)

        self.board_radius = int(self.H * 0.38)

        self.numbers = [
            20, 1, 18, 4, 13, 6, 10, 15, 2, 17,
            3, 19, 7, 16, 8, 11, 14, 9, 12, 5
        ]

        self.number_index = {n: i for i, n in enumerate(self.numbers)}

        self.last_hit = None
        self.last_state = "IDLE"
        self.last_miss = False

        self.visited = set()

        self.board_texture = self._create_board_texture()

        # --- AUTO TEST ADD ---
        self.auto_test = HardwareAutoTest()

        self._dirty = True

    # --------------------------------------------------

    def _get_text_texture(self, text, font, color):

        key = (text, font.size, color)

        if key in self.text_cache:
            return self.text_cache[key]

        w = max(1, int(font.getlength(text)))
        ascent, descent = font.getmetrics()
        h = max(1, ascent + descent)

        img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        draw.text((0, 0), text, font=font, fill=color)

        arr = np.array(img, dtype=np.uint8)

        self.text_cache[key] = (arr, w, h)

        return arr, w, h

    # --------------------------------------------------
    # GEOMETRY
    # --------------------------------------------------

    def _ring_radii(self):

        R = self.board_radius

        return {

            "double_outer": R,
            "double_inner": int(R * 0.92),

            "outer_single_outer": int(R * 0.92),
            "outer_single_inner": int(R * 0.60),

            "triple_outer": int(R * 0.60),
            "triple_inner": int(R * 0.52),

            "inner_single_outer": int(R * 0.52),

            # BULLに近づける
            "inner_single_inner": int(R * 0.08),

            "outer_bull": int(R * 0.07),
            "inner_bull": int(R * 0.03),
        }

    def _segment_angles(self, number):

        index = self.number_index[number]

        a0 = index * 18 - 9
        a1 = a0 + 18

        return a0, a1

    def _annular_sector_points(
        self,
        cx,
        cy,
        r_outer,
        r_inner,
        start_deg,
        end_deg,
        steps=24,
    ):

        pts = []

        for i in range(steps + 1):

            deg = start_deg + (end_deg - start_deg) * (i / steps)
            rad = math.radians(deg)

            x = cx + r_outer * math.sin(rad)
            y = cy - r_outer * math.cos(rad)

            pts.append((x, y))

        for i in range(steps, -1, -1):

            deg = start_deg + (end_deg - start_deg) * (i / steps)
            rad = math.radians(deg)

            x = cx + r_inner * math.sin(rad)
            y = cy - r_inner * math.cos(rad)

            pts.append((x, y))

        return pts

    def _draw_annular_sector(
        self,
        draw,
        cx,
        cy,
        r_outer,
        r_inner,
        start_deg,
        end_deg,
        fill,
    ):

        pts = self._annular_sector_points(
            cx,
            cy,
            r_outer,
            r_inner,
            start_deg,
            end_deg,
        )

        draw.polygon(pts, fill=fill)

    def _draw_ring_for_hit(self, draw, cx, cy, number, ring, color):

        radii = self._ring_radii()

        if number is None:

            if ring == DartRing.OUTER_BULL:

                r = radii["outer_bull"]

                draw.ellipse(
                    [cx - r, cy - r, cx + r, cy + r],
                    fill=color
                )

            elif ring == DartRing.INNER_BULL:

                r = radii["inner_bull"]

                draw.ellipse(
                    [cx - r, cy - r, cx + r, cy + r],
                    fill=color
                )

            return

        a0, a1 = self._segment_angles(number)

        if ring == DartRing.DOUBLE:

            self._draw_annular_sector(
                draw, cx, cy,
                radii["double_outer"], radii["double_inner"],
                a0, a1, color
            )

        elif ring == DartRing.OUTER_SINGLE:

            self._draw_annular_sector(
                draw, cx, cy,
                radii["outer_single_outer"], radii["outer_single_inner"],
                a0, a1, color
            )

        elif ring == DartRing.TRIPLE:

            self._draw_annular_sector(
                draw, cx, cy,
                radii["triple_outer"], radii["triple_inner"],
                a0, a1, color
            )

        elif ring == DartRing.INNER_SINGLE:

            self._draw_annular_sector(
                draw, cx, cy,
                radii["inner_single_outer"], radii["inner_single_inner"],
                a0, a1, color
            )

    # --------------------------------------------------
    # BOARD
    # --------------------------------------------------

    def _create_board_texture(self):

        size = self.board_radius * 2 + 20

        img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        cx = size // 2
        cy = size // 2

        radii = self._ring_radii()

        R = self.board_radius

        red = (200, 0, 0, 255)
        black = (20, 20, 20, 255)

        light = (215, 215, 215, 255)
        dark = (80, 80, 80, 255)

        for i, number in enumerate(self.numbers):

            a0, a1 = self._segment_angles(number)

            ring_color = red if i % 2 == 0 else black
            single_color = light if i % 2 == 0 else dark

            self._draw_annular_sector(
                draw, cx, cy,
                radii["double_outer"], radii["double_inner"],
                a0, a1, ring_color
            )

            self._draw_annular_sector(
                draw, cx, cy,
                radii["outer_single_outer"], radii["outer_single_inner"],
                a0, a1, single_color
            )

            self._draw_annular_sector(
                draw, cx, cy,
                radii["triple_outer"], radii["triple_inner"],
                a0, a1, ring_color
            )

            self._draw_annular_sector(
                draw, cx, cy,
                radii["inner_single_outer"], radii["inner_single_inner"],
                a0, a1, single_color
            )

        draw.ellipse(
            [
                cx - radii["outer_bull"], cy - radii["outer_bull"],
                cx + radii["outer_bull"], cy + radii["outer_bull"]
            ],
            fill=(0, 140, 0, 255)
        )

        draw.ellipse(
            [
                cx - radii["inner_bull"], cy - radii["inner_bull"],
                cx + radii["inner_bull"], cy + radii["inner_bull"]
            ],
            fill=(220, 0, 0, 255)
        )

        circle_line = (150, 150, 150, 255)

        draw.ellipse([cx - R, cy - R, cx + R, cy + R], outline=circle_line, width=3)

        for i in range(20):

            angle = math.radians(i * 18 - 9)

            x = cx + R * math.sin(angle)
            y = cy - R * math.cos(angle)

            draw.line([cx, cy, x, y], fill=(100, 100, 100, 255), width=2)

        # 放射線の上から中心部を再描画して、BULL周辺の線を消す

        # BULL外側の黒円
        r_black = radii["inner_single_inner"]

        draw.ellipse(
            [
                cx - r_black, cy - r_black,
                cx + r_black, cy + r_black
            ],
            fill=(20, 20, 20, 255)
        )

        # OUTER BULL 緑
        draw.ellipse(
            [
                cx - radii["outer_bull"], cy - radii["outer_bull"],
                cx + radii["outer_bull"], cy + radii["outer_bull"]
            ],
            fill=(0, 140, 0, 255)
        )

        # INNER BULL 赤
        draw.ellipse(
            [
                cx - radii["inner_bull"], cy - radii["inner_bull"],
                cx + radii["inner_bull"], cy + radii["inner_bull"]
            ],
            fill=(220, 0, 0, 255)
        )

        return np.array(img, dtype=np.uint8)

    # --------------------------------------------------
    # OVERLAY
    # --------------------------------------------------

    def _draw_overlay(self):

        size = self.board_texture.shape[0]

        img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        cx = size // 2
        cy = size // 2

        visited_color = (0, 200, 255, 150)
        current_color = (255, 255, 0, 210)

        for number, ring in self.visited:

            self._draw_ring_for_hit(
                draw, cx, cy,
                number,
                ring,
                visited_color
            )

        if self.last_hit:

            self._draw_ring_for_hit(
                draw, cx, cy,
                self.last_hit.number,
                self.last_hit.ring,
                current_color
            )

        return np.array(img, dtype=np.uint8)

    # --------------------------------------------------
    # INPUT
    # --------------------------------------------------

    def _handle_input(self):

        events = self.get_events()

        for e in events:

            # --- AUTO TEST ADD ---
            if e.type == EventType.BUTTON_PRESSED and e.payload == ButtonType.SERVICE:
                self.auto_test.start()
                self._dirty = True
                return None

            if e.type == EventType.DART_HIT:
                self.last_hit = e.payload
                self.last_state = "PRESSED"
                self.last_miss = False
                self.visited.add((e.payload.number, e.payload.ring))
                self._dirty = True
                continue

            elif e.type == EventType.DART_LONG_PRESS:

                self.last_state = "LONG PRESS"
                self._dirty = True
                continue

            elif e.type == EventType.DART_LONG_PRESS_RELEASED:

                self.last_state = "LONG RELEASE"
                self._dirty = True
                continue

            elif e.type == EventType.DART_RELEASED:

                self.last_state = "RELEASED"
                self._dirty = True
                continue

            if e.type == EventType.MISS:
                self.last_miss = True
                self.last_state = "MISS"
                self._dirty = True
                continue

            if e.type == EventType.BUTTON_PRESSED and e.payload == ButtonType.CANCEL:
                from framework.scenes.service.system import SystemMenuScene
                return SystemMenuScene(self.engine)

    # --------------------------------------------------
    # DRAW
    # --------------------------------------------------

    def _draw_numbers(self):

        radii = self._ring_radii()

        for i, number in enumerate(self.numbers):

            angle = math.radians(i * 18)

            rr = (self.board_radius + radii["double_inner"]) / 2.0

            x = self.cx + rr * math.sin(angle)
            y = self.cy - rr * math.cos(angle)

            tex, w, h = self._get_text_texture(
                str(number),
                self.num_font,
                (255, 255, 255, 255)
            )

            self.r.ui_draw_texture(
                int(x - w / 2),
                int(y - h / 2),
                w,
                h,
                tex
            )

    # --- AUTO TEST ADD ---
    def _draw_auto_test_log(self):

        if not self.auto_test.log:
            return

        left = int(self.W * 0.04)
        top = int(self.H * 0.63)
        width = int(self.W * 0.92)
        height = int(self.H * 0.28)

        # 背景ボックス
        box_img = Image.new("RGBA", (width, height), (0, 0, 0, 0))
        box_draw = ImageDraw.Draw(box_img)
        box_draw.rounded_rectangle(
            [0, 0, width, height],
            radius=18,
            fill=(10, 10, 10, 210),
            outline=(70, 70, 70, 255),
            width=2
        )
        self.r.ui_draw_texture(left, top, width, height, np.array(box_img, dtype=np.uint8))

        # ヘッダ
        header_text = "AUTO TEST LOG"
        if self.auto_test.running:
            header_text = "AUTO TEST RUNNING"

        header_color = (255, 200, 80, 255) if self.auto_test.running else (180, 180, 180, 255)

        tex_h, w_h, h_h = self._get_text_texture(
            header_text,
            self.info_font,
            header_color
        )

        self.r.ui_draw_texture(
            left + 16,
            top + 10,
            w_h,
            h_h,
            tex_h
        )

        # ログ本体
        logs = self.auto_test.log

        result_text = None
        normal_logs = []

        for text in logs:
            upper = text.upper()

            if upper.startswith("TEST PASS") or upper.startswith("TEST FAIL"):
                result_text = text
            else:
                normal_logs.append(text)

        x0 = left + 16
        y0 = top + 16 + h_h
        max_width = width - 32
        line_height = max(18, int(self.H * 0.024))
        item_gap_x = 12

        x = x0
        y = y0

        # 通常ログは従来通り横に並べる
        # 行数制限はしない。通常ログを描画し終えた下に結果を描画する。
        for text in normal_logs:

            upper = text.upper()

            if ("FAIL" in upper) or ("STUCK" in upper) or ("NO RESPONSE" in upper) or ("NG" in upper):
                color = (255, 80, 80, 255)
            else:
                color = (190, 230, 230, 255)

            tex, w, h = self._get_text_texture(
                text,
                self.log_font,
                color
            )

            if x + w > x0 + max_width:
                x = x0
                y += line_height

            # ボックスからはみ出すなら終了
            if y + h > top + height - 8:
                break

            self.r.ui_draw_texture(
                x,
                y,
                w,
                h,
                tex
            )

            x += w + item_gap_x

        # TEST PASS / TEST FAIL は通常ログの下に描画する
        if result_text:

            # 通常ログの行末から次の行へ移動
            if x != x0:
                y += line_height

            # 結果の前に余白を作る
            y += int(self.H * 0.035)

            upper = result_text.upper()

            if "PASS" in upper:
                color = (80, 255, 120, 255)
            else:
                color = (255, 80, 80, 255)

            tex, w, h = self._get_text_texture(
                result_text,
                self.info_font,
                color
            )

            # 結果が入らない場合だけ、下端に合わせる
            if y + h > top + height - 8:
                y = top + height - h - 8

            self.r.ui_draw_texture(
                x0,
                y,
                w,
                h,
                tex
            )

    def _draw(self):

        r = self.r

        r.ui_clear(0, 0, 0)

        size = self.board_texture.shape[0]

        bx = self.cx - size // 2
        by = self.cy - size // 2

        r.ui_draw_texture(bx, by, size, size, self.board_texture)

        overlay = self._draw_overlay()

        r.ui_draw_texture(bx, by, size, size, overlay)

        self._draw_numbers()

        if self.last_miss:

            hit_text = "MISS"

        elif self.last_hit:

            if self.last_hit.number is None:

                hit_text = self.last_hit.ring.name

            else:

                hit_text = f"{self.last_hit.ring.name} {self.last_hit.number}"

        else:

            hit_text = "NONE"

        tex, w, h = self._get_text_texture(
            f"HIT : {hit_text}",
            self.title_font,
            (255, 255, 255, 255)
        )

        r.ui_draw_texture((self.W - w) // 2, int(self.H * 0.05), w, h, tex)

        tex2, w2, h2 = self._get_text_texture(
            f"STATE : {self.last_state}",
            self.info_font,
            (200, 200, 200, 255)
        )

        r.ui_draw_texture((self.W - w2) // 2, int(self.H * 0.92), w2, h2, tex2)

        # --- AUTO TEST ADD ---
        self._draw_auto_test_log()

        self.engine.overlay.draw()
        r.ui_swap()

    # --------------------------------------------------

    def run(self):

        next_scene = self._handle_input()

        before_auto_key = (
            self.auto_test.running,
            len(self.auto_test.log),
        )

        self.auto_test.update()

        after_auto_key = (
            self.auto_test.running,
            len(self.auto_test.log),
        )

        if before_auto_key != after_auto_key:
            self._dirty = True

        if self._dirty:
            self._draw()
            self._dirty = False

        if next_scene:
            return next_scene

        return self