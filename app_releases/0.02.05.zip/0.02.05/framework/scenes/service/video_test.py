# framework/scenes/service/video_test.py

import os
import numpy as np
from PIL import Image, ImageDraw, ImageFont

from framework.scene import Scene
from framework.input_types import EventType, ButtonType


FONT_PATH = "/opt/shisa/current/system_assets/fonts/NotoSansMono-Regular.ttf"
VIDEO_DIR = "/opt/shisa/current/assets/video"


class VideoTestScene(Scene):

    def __init__(self, engine):
        super().__init__(engine)

        self.r = self.engine.renderer
        self.W = self.r.width
        self.H = self.r.height

        # ----------------------------
        # Font
        # ----------------------------
        self.title_font_size = int(self.H * 0.07)
        self.menu_font_size = int(self.H * 0.055)

        self.title_font = ImageFont.truetype(FONT_PATH, self.title_font_size)
        self.menu_font = ImageFont.truetype(FONT_PATH, self.menu_font_size)

        ascent_m, descent_m = self.menu_font.getmetrics()
        self.menu_height = ascent_m + descent_m

        self.text_cache = {}

        # ----------------------------
        # Video list
        # ----------------------------
        self.menu_items = self._scan_videos()
        self.index = 0
        self.spacing = 25
        self.scroll_offset = 0
        self.visible_rows = 6

        # ----------------------------
        # Box
        # ----------------------------
        self.box_width = int(self.W * 0.7)
        self.box_height = int(self.H * 0.6)
        self.box_radius = 40

        self.box_x = (self.W - self.box_width) // 2
        self.box_y = int(self.H * 0.25)

        self._menu_box_texture = self._create_rounded_box()

    # --------------------------------------------------
    def _scan_videos(self):
        items = []

        if os.path.isdir(VIDEO_DIR):
            for name in sorted(os.listdir(VIDEO_DIR)):
                if name.lower().endswith(".mp4"):
                    items.append(os.path.splitext(name)[0])

        return items

    # --------------------------------------------------
    def _create_rounded_box(self):

        img = Image.new("RGBA", (self.box_width, self.box_height), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        draw.rounded_rectangle(
            [0, 0, self.box_width, self.box_height],
            radius=self.box_radius,
            fill=(20, 20, 20, 220)
        )

        return np.array(img, dtype=np.uint8)

    # --------------------------------------------------
    def _get_text_texture(self, text, font, color):

        key = (text, font.size, color)
        if key in self.text_cache:
            return self.text_cache[key]

        w = int(font.getlength(text))
        ascent, descent = font.getmetrics()
        h = ascent + descent

        img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        draw.text((0, 0), text, font=font, fill=color)

        arr = np.array(img, dtype=np.uint8)
        self.text_cache[key] = (arr, w, h)
        return arr, w, h

    # --------------------------------------------------
    def _update_scroll(self):
        if self.index < self.scroll_offset:
            self.scroll_offset = self.index
        elif self.index >= self.scroll_offset + self.visible_rows:
            self.scroll_offset = self.index - self.visible_rows + 1

    # --------------------------------------------------
    def _handle_input(self):

        events = self.get_events()

        for e in events:

            if e.type != EventType.BUTTON_PRESSED:
                continue

            if e.payload == ButtonType.NAV_UP:
                if self.menu_items:
                    self.index = (self.index - 1) % len(self.menu_items)
                    self._update_scroll()

            elif e.payload == ButtonType.NAV_DOWN:
                if self.menu_items:
                    self.index = (self.index + 1) % len(self.menu_items)
                    self._update_scroll()

            elif e.payload == ButtonType.ENTER:
                if self.menu_items:
                    name = self.menu_items[self.index]
                    self.engine.video.play_with_intro(name, black_seconds=2.0)

            elif e.payload == ButtonType.CANCEL:
                from framework.scenes.service.system import SystemMenuScene
                return SystemMenuScene(self.engine)

        return None

    # --------------------------------------------------
    def _draw_empty(self, r, left_x, start_y):
        tex_l, w_l, h_l = self._get_text_texture(
            "NO VIDEO FILE",
            self.menu_font,
            (255, 80, 80, 255)
        )
        r.ui_draw_texture(left_x, start_y, w_l, h_l, tex_l)

    # --------------------------------------------------
    def _draw(self):

        r = self.r
        r.ui_clear(0.0, 0.0, 0.0)

        # Title
        title_text = "VIDEO TEST"
        tex_t, w_t, h_t = self._get_text_texture(
            title_text,
            self.title_font,
            (255, 255, 255, 255)
        )

        r.ui_draw_texture(
            (self.W - w_t) // 2,
            int(self.H * 0.15),
            w_t,
            h_t,
            tex_t
        )

        # Box
        r.ui_draw_texture(
            self.box_x,
            self.box_y,
            self.box_width,
            self.box_height,
            self._menu_box_texture
        )

        left_x = self.box_x + 80
        right_x = self.box_x + self.box_width - 80

        if not self.menu_items:
            self._draw_empty(r, left_x, self.box_y + 80)
            self.engine.overlay.draw()
            r.ui_swap()
            return

        visible_items = self.menu_items[
            self.scroll_offset:self.scroll_offset + self.visible_rows
        ]

        total_menu_height = (
            len(visible_items) * self.menu_height +
            (len(visible_items) - 1) * self.spacing
        )

        start_y = self.box_y + (self.box_height - total_menu_height) // 2

        for row, item in enumerate(visible_items):
            actual_index = self.scroll_offset + row
            y = start_y + row * (self.menu_height + self.spacing)

            color = (255, 80, 80, 255) if actual_index == self.index else (200, 200, 200, 255)

            tex_l, w_l, h_l = self._get_text_texture(
                item.upper(),
                self.menu_font,
                color
            )

            r.ui_draw_texture(left_x, y, w_l, h_l, tex_l)

            tex_v, w_v, h_v = self._get_text_texture(
                "READY",
                self.menu_font,
                (255, 255, 255, 255)
            )

            r.ui_draw_texture(
                right_x - w_v,
                y,
                w_v,
                h_v,
                tex_v
            )

        # scroll hint
        if self.scroll_offset > 0:
            tex_u, w_u, h_u = self._get_text_texture("▲", self.menu_font, (180, 180, 180, 255))
            r.ui_draw_texture(right_x - w_u, self.box_y + 20, w_u, h_u, tex_u)

        if self.scroll_offset + self.visible_rows < len(self.menu_items):
            tex_d, w_d, h_d = self._get_text_texture("▼", self.menu_font, (180, 180, 180, 255))
            r.ui_draw_texture(
                right_x - w_d,
                self.box_y + self.box_height - h_d - 20,
                w_d,
                h_d,
                tex_d
            )

        self.engine.overlay.draw()
        r.ui_swap()

    # --------------------------------------------------
    def run(self):

        next_scene = self._handle_input()
        self._draw()

        if next_scene is not None:
            return next_scene

        return self