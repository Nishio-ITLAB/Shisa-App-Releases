# framework/scenes/boot.py

from framework.scene import Scene
from framework.scenes.menu import MenuScene
from framework.scenes.emergency import EmergencyScene


class BootScene(Scene):

    def run(self):
        check = getattr(self.engine, "asset_check", None)

        if check is not None and not check.get("ok", False):
            return EmergencyScene(
                self.engine,
                reason=check.get("reason", "ASSET VERSION ERROR"),
                required=check.get("required", "-"),
                current=check.get("current", "-"),
            )

        # assets version OK の場合のみ起動動画を再生
        #self.engine.video.play_with_intro("initial", black_seconds=2.0)

        return MenuScene(self.engine)