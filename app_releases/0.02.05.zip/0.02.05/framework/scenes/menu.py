# framework/scenes/menu.py

import numpy as np
from PIL import Image, ImageDraw, ImageFont, Image
import RPi.GPIO as GPIO

from framework.scene import Scene
from framework.input_types import EventType, ButtonType

from games.countup.factory import create_game
from framework.scenes.game.root import GameScene

MENU_FONT_PATH = "/opt/shisa/current/assets/fonts/ChivoMono-Italic-VariableFont_wght.ttf"
NOTE_FONT_PATH = "/opt/shisa/current/assets/fonts/NotoSansJP-Regular.ttf"
LOGO_PATH = "/opt/shisa/current/assets/image/logo.png"


class MenuNode:
    def __init__(self, name, children=None, description=""):
        self.name = name
        self.children = children or []
        self.description = description


class MenuScene(Scene):

    def __init__(self, engine):
        super().__init__(engine)

        # ----------------------------
        # COIN電源ON（メニュー到達時）
        # ----------------------------
        GPIO.setmode(GPIO.BCM)
        GPIO.setup(9, GPIO.OUT)
        GPIO.output(9, GPIO.HIGH)

        self.system_config = self.engine.system_config
        self.game_config = self.engine.game_config

        self.confirm_mode = False
        self.pending_game_info = None

        self.r = self.engine.renderer
        self.W = self.r.width
        self.H = self.r.height

        # ----------------------------
        # 横レイアウト（割合固定）
        # ----------------------------
        self.left_margin = int(self.W * 0.03)
        self.col_widths = [
            int(self.W * 0.27),  # 1階層（ゲーム）
            int(self.W * 0.40),  # 2階層（モード）
            int(self.W * 0.27),  # 3階層（プレイヤー数）
        ]
        self.right_margin = int(self.W * 0.03)

        # ----------------------------
        # 縦レイアウト
        # ----------------------------
        self.logo_height = 100
        self.font_size = int(self.H * 0.08)
        self.note_font_size = int(self.H * 0.038)

        # ----------------------------
        # フォント
        # ----------------------------
        self.menu_font = ImageFont.truetype(MENU_FONT_PATH, self.font_size)
        self.note_font = ImageFont.truetype(NOTE_FONT_PATH, self.note_font_size)
        self.title_font_size = int(self.H * 0.045)
        self.title_font = ImageFont.truetype(MENU_FONT_PATH, self.title_font_size)

        mx0, my0, mx1, my1 = self.menu_font.getbbox("AG09")
        self.font_height = my1 - my0

        nx0, ny0, nx1, ny1 = self.note_font.getbbox("説明あ亜")
        self.note_font_height = ny1 - ny0

        # 行送りは font_height 算出後に決める
        self.line_spacing = int(self.font_height * 1.8)
        self.note_line_spacing = int(self.note_font_height * 1.5)

        self.top_margin = (
            self.logo_height +
            int(self.H * 0.10)
        )

        # メニュー背景は「最大4行 + 余白」だけ確保
        self.menu_visible_rows = 6
        self.menu_panel_padding_y = int(self.font_height * 0.55)
        self.menu_panel_height = (
            self.menu_panel_padding_y * 2 +
            self.font_height +
            self.line_spacing * (self.menu_visible_rows - 1)
        )

        # 説明欄
        self.description_gap = int(self.H * 0.03)
        self.description_padding_x = 18
        self.description_padding_y = 14
        self.description_box_y = self.top_margin - 30 + self.menu_panel_height + self.description_gap
        self.description_box_height = self.H - self.description_box_y - 60

        # ----------------------------
        # ロゴ
        # ----------------------------
        logo_img = Image.open(LOGO_PATH).convert("RGBA")
        ratio = self.logo_height / logo_img.height
        new_w = int(logo_img.width * ratio)
        logo_img = logo_img.resize((new_w, self.logo_height))
        self.logo_rgba = np.array(logo_img, dtype=np.uint8)
        self.logo_w = new_w

        self.text_cache = {}

        # ----------------------------
        # メニュー構造
        # ----------------------------
        self.root = self._build_root_menu()


        self.current = self.root
        self.stack = []
        self.index = 0

        self._dirty = True
        self.wrap_cache = {}

    # --------------------------------------------------
    # TEXT
    # --------------------------------------------------
    def _get_text_texture(self, text, color, font_type="menu"):
        key = (text, color, font_type)
        if key in self.text_cache:
            return self.text_cache[key]

        if font_type == "menu":
            font = self.menu_font
        elif font_type == "note":
            font = self.note_font
        elif font_type == "title":
            font = self.title_font
        else:
            font = self.menu_font

        x0, y0, x1, y1 = font.getbbox(text)
        w = max(1, x1 - x0)
        h = max(1, y1 - y0)

        img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        draw.text((-x0, -y0), text, font=font, fill=color)

        arr = np.array(img, dtype=np.uint8)
        self.text_cache[key] = (arr, w, h)
        return arr, w, h

    def _wrap_text(self, text, max_width, font_type="note"):

        key = (text, max_width, font_type)

        if key in self.wrap_cache:
            return self.wrap_cache[key]

        if not text:
            self.wrap_cache[key] = []
            return []

        font = self.menu_font if font_type == "menu" else self.note_font
        lines = []
        current = ""

        for ch in text:
            if ch == "\n":
                lines.append(current)
                current = ""
                continue

            trial = current + ch
            x0, y0, x1, y1 = font.getbbox(trial)
            trial_w = x1 - x0

            if trial_w <= max_width or not current:
                current = trial
            else:
                lines.append(current)
                current = ch

        if current:
            lines.append(current)

        self.wrap_cache[key] = lines
        return lines

    def _get_selected_node(self):
        children = self.current.children
        if not children:
            return None
        if self.index < 0 or self.index >= len(children):
            return None
        return children[self.index]

    def _build_player_nodes(self, game_name):
        return [
            MenuNode("1 PLAYER", description=f"1人で{game_name}をプレイします。"),
            MenuNode("2 PLAYER", description=f"2人で{game_name}をプレイします。"),
            MenuNode("3 PLAYER", description=f"3人で{game_name}をプレイします。"),
            MenuNode("4 PLAYER", description=f"4人で{game_name}をプレイします。"),
        ]


    def _build_countup_modes(self):
        nodes = []

        if self.game_config.is_mode_enabled("countup", "count_up"):
            nodes.append(
                MenuNode(
                    "COUNT-UP",
                    self._build_player_nodes("COUNT-UP"),
                    description="持ち点を加算していく、通常のカウントアップです。"
                )
            )

        if self.game_config.is_mode_enabled("countup", "cr_count_up"):
            nodes.append(
                MenuNode(
                    "CR.COUNT-UP",
                    self._build_player_nodes("CR. COUNT-UP"),
                    description="クリケットルールのカウントアップです。"
                )
            )

        return nodes


    def _build_zero1_modes(self):
        nodes = []

        zero1_defs = [
            ("301", "301 GAME", "301からスタートする01ゲームです。"),
            ("501", "501 GAME", "501からスタートする01ゲームです。"),
            ("701", "701 GAME", "701からスタートする01ゲームです。"),
            ("901", "901 GAME", "901からスタートする01ゲームです。"),
            ("1101", "1101 GAME", "1101からスタートする01ゲームです。"),
            ("1501", "1501 GAME", "1501からスタートする01ゲームです。"),
        ]

        for mode_id, label, desc in zero1_defs:
            if self.game_config.is_mode_enabled("zero1", mode_id):
                nodes.append(
                    MenuNode(
                        label,
                        self._build_player_nodes(label),
                        description=desc
                    )
                )

        return nodes


    def _build_cricket_modes(self):
        nodes = []

        if self.game_config.is_mode_enabled("cricket", "standard"):
            nodes.append(
                MenuNode(
                    "STANDARD CR.",
                    self._build_player_nodes("STANDARD CR."),
                    description="標準的なクリケットゲームです。"
                )
            )

        if self.game_config.is_mode_enabled("cricket", "cut_throat"):
            nodes.append(
                MenuNode(
                    "CUT-THROAT CR.",
                    self._build_player_nodes("CUT-THROAT CR."),
                    description="カットスロート方式のクリケットです。"
                )
            )

        return nodes


    def _build_root_menu(self):
        root_children = []

        countup_modes = self._build_countup_modes()
        if countup_modes:
            root_children.append(
                MenuNode(
                    "COUNT-UP",
                    countup_modes,
                    description="カウントアップ系ゲームを選択します。"
                )
            )

        zero1_modes = self._build_zero1_modes()
        if zero1_modes:
            root_children.append(
                MenuNode(
                    "01 GAME",
                    zero1_modes,
                    description="01ゲーム系を選択します。"
                )
            )

        cricket_modes = self._build_cricket_modes()
        if cricket_modes:
            root_children.append(
                MenuNode(
                    "CRICKET",
                    cricket_modes,
                    description="クリケット系ゲームを選択します。"
                )
            )

        return MenuNode("ROOT", root_children)


    # --------------------------------------------------
    # INPUT
    # --------------------------------------------------
    def _handle_input(self):

        events = self.get_events()

        for e in events:

            self._dirty = True

            if e.type != EventType.BUTTON_PRESSED:
                continue

            # ----------------------------
            # Confirm Mode
            # ----------------------------
            if self.confirm_mode:

                if e.payload == ButtonType.ENTER:

                    if self.pending_game_info is None:
                        self.confirm_mode = False
                        return None

                    required_credits = self.pending_game_info["required_credits"]

                    # free playでなければクレジット消費
                    if not self.system_config.is_free_play():

                        if self.system_config.get_current_credit() < required_credits:
                            self.engine.audio.play("miss")
                            return None

                        if not self.system_config.consume_credits(required_credits):
                            self.engine.audio.play("miss")
                            return None

                    controller = create_game(
                        self.engine,
                        self.pending_game_info["mode_id"],
                        self.pending_game_info["players"]
                    )

                    self.confirm_mode = False
                    self.pending_game_info = None

                    self.engine.audio.play("enter")
                    return GameScene(self.engine, controller)

                elif e.payload in (ButtonType.CANCEL, ButtonType.NAV_LEFT):
                    self.confirm_mode = False
                    self.pending_game_info = None
                    self.engine.audio.play("cancel")
                    return None

                return None

            children = self.current.children
            total = len(children)

            if e.payload == ButtonType.NAV_UP:
                if total == 0:
                    return None
                self.index = (self.index - 1) % total
                self.engine.audio.play("select")

            elif e.payload == ButtonType.NAV_DOWN:
                if total == 0:
                    return None
                self.index = (self.index + 1) % total
                self.engine.audio.play("select")

            elif e.payload in (ButtonType.ENTER, ButtonType.NAV_RIGHT):

                if total == 0:
                    return None

                selected = children[self.index]

                # ----------------------------
                # 下層がある → 通常の階層移動
                # ----------------------------
                if selected.children:
                    self.stack.append((self.current, self.index))
                    self.current = selected
                    self.index = 0

                    self.engine.audio.play("enter")
                    return None

                # ----------------------------
                # 葉ノード（= PLAYER選択）→ 開始確認へ
                # ----------------------------
                label = selected.name

                if "PLAYER" in label:

                    players = int(label.split()[0])
                    required_credits = players

                    # 親ノードからモード取得
                    mode_node = self.current
                    mode_label = mode_node.name

                    # COUNT-UP系
                    if mode_label == "COUNT-UP":
                        game_name = "COUNT-UP"
                        mode_id = "count_up"
                        mode_name = "COUNT-UP"

                    elif mode_label == "CR.COUNT-UP":
                        game_name = "COUNT-UP"
                        mode_id = "cr_count_up"
                        mode_name = "CR.COUNT-UP"

                    else:
                        return None

                    # ----------------------------
                    # 先にクレジット確認
                    # free playでなく、必要クレジット未満なら確認画面を出さない
                    # ----------------------------
                    if not self.system_config.is_free_play():
                        if self.system_config.get_current_credit() < required_credits:
                            self.engine.audio.play("miss")
                            return None

                    self.pending_game_info = {
                        "game_name": game_name,
                        "mode_id": mode_id,
                        "mode_name": mode_name,
                        "players": players,
                        "required_credits": required_credits,
                    }
                    self.confirm_mode = True

                    self.engine.audio.play("enter")
                    return None

                # ----------------------------
                # その他（何もしない）
                # ----------------------------
                self.engine.audio.play("enter")

            elif e.payload in (ButtonType.CANCEL, ButtonType.NAV_LEFT):

                if self.stack:
                    self.current, self.index = self.stack.pop()
                    self.engine.audio.play("cancel")

            elif e.payload == ButtonType.SERVICE:
                from framework.scenes.service.root import ServiceRootScene
                return ServiceRootScene(self.engine)

        return None

    # --------------------------------------------------
    # DRAW
    # --------------------------------------------------
    def _draw(self):

        r = self.r
        r.ui_clear(0.0, 0.0, 0.0)

        # ロゴ
        r.ui_draw_texture(
            self.left_margin,
            30,
            self.logo_w,
            self.logo_height,
            self.logo_rgba
        )

        # ★「存在する階層だけ」描画（従来通り）
        stack_list = [n for (n, _) in self.stack] + [self.current]
        stack_list = stack_list[:3]  # 最大3階層

        menu_panel_y = self.top_margin - 30

        for depth, node in enumerate(stack_list):

            col_x = self.left_margin + sum(self.col_widths[:depth])

            # 背景（この階層が存在する時だけ出る）
            r.ui_draw_rect(
                col_x,
                menu_panel_y,
                self.col_widths[depth],
                self.menu_panel_height,
                (0.08, 0.08, 0.08, 1.0)
            )

            y = self.top_margin

            selected_index = None
            if depth < len(self.stack):
                selected_index = self.stack[depth][1]
            elif depth == len(stack_list) - 1:
                selected_index = self.index

            for i, child in enumerate(node.children):

                if depth == len(stack_list) - 1:
                    if i == self.index:
                        color = (255, 80, 80, 255)
                        highlight = True
                    else:
                        color = (220, 220, 220, 255)
                        highlight = False
                else:
                    if i == selected_index:
                        color = (200, 200, 200, 255)
                    else:
                        color = (90, 90, 90, 255)
                    highlight = False

                tex, w, h = self._get_text_texture(child.name, color, font_type="menu")

                if highlight:
                    highlight_padding = int(self.font_height * 0.4)
                    r.ui_draw_rect(
                        col_x + 10,
                        y - highlight_padding,
                        self.col_widths[depth] - 20,
                        h + highlight_padding * 2,
                        (0.3, 0.0, 0.0, 1.0)
                    )

                r.ui_draw_texture(
                    col_x + 20,
                    y,
                    w,
                    h,
                    tex
                )

                y += self.line_spacing

        # ----------------------------
        # 選択中メニューの説明文
        # ----------------------------
        selected = self._get_selected_node()
        if selected is not None:
            desc_x = self.left_margin
            desc_y = self.description_box_y
            desc_w = self.W - self.left_margin - self.right_margin
            desc_h = self.description_box_height

            # タイトル
            title_text = f"SELECTED : {selected.name}"
            title_tex, title_w, title_h = self._get_text_texture(
                title_text,
                (180, 180, 180, 255),
                font_type="title"
            )
            r.ui_draw_texture(
                desc_x + self.description_padding_x,
                desc_y + self.description_padding_y,
                title_w,
                title_h,
                title_tex
            )

            # 本文
            body_x = desc_x + self.description_padding_x
            body_y = desc_y + self.description_padding_y + title_h + 14
            body_max_w = desc_w - self.description_padding_x * 2
            body_max_h = desc_h - (body_y - desc_y) - self.description_padding_y

            desc_text = selected.description if selected.description else "この項目の説明は未設定です。"
            lines = self._wrap_text(desc_text, body_max_w, font_type="note")

            max_lines = max(1, body_max_h // self.note_line_spacing)
            lines = lines[:max_lines]

            for line in lines:
                tex, w, h = self._get_text_texture(
                    line,
                    (220, 220, 220, 255),
                    font_type="note"
                )
                r.ui_draw_texture(
                    body_x,
                    body_y,
                    w,
                    h,
                    tex
                )
                body_y += self.note_line_spacing

        # --------------------------------------------------
        # ゲーム開始確認ダイアログ
        # --------------------------------------------------
        if self.confirm_mode and self.pending_game_info is not None:

            overlay_w = int(self.W * 0.62)
            overlay_h = int(self.H * 0.50)

            ox = (self.W - overlay_w) // 2
            oy = (self.H - overlay_h) // 2

            img = Image.new("RGBA", (overlay_w, overlay_h), (0, 0, 0, 0))
            draw = ImageDraw.Draw(img)

            draw.rounded_rectangle(
                [0, 0, overlay_w, overlay_h],
                radius=30,
                fill=(0, 0, 0, 230)
            )

            r.ui_draw_texture(
                ox,
                oy,
                overlay_w,
                overlay_h,
                np.array(img, dtype=np.uint8)
            )

            # ----------------------------
            # タイトル
            # ----------------------------
            title_text = "この条件でゲームを開始しますか？"
            tex_t, w_t, h_t = self._get_text_texture(
                title_text,
                (255, 255, 255, 255),
                font_type="note"
            )
            r.ui_draw_texture(
                (self.W - w_t) // 2,
                oy + 28,
                w_t,
                h_t,
                tex_t
            )

            # ----------------------------
            # 条件表示
            # 「：」位置を揃えるためラベル列幅を固定
            # ----------------------------
            info_x = ox + 350
            info_y = oy + 120
            line_gap = self.note_line_spacing + 8

            label_w = 300
            value_offset = 40

            if self.system_config.is_free_play():
                consume_value = "0"
            else:
                consume_value = str(self.pending_game_info["required_credits"])

            info_items = [
                ("ゲーム", self.pending_game_info["game_name"]),
                ("モード", self.pending_game_info["mode_name"]),
                ("人数", f"{self.pending_game_info['players']}"),
                ("消費クレジット", consume_value),
            ]

            for i, (label, value) in enumerate(info_items):

                y = info_y + i * line_gap

                tex_l, w_l, h_l = self._get_text_texture(
                    label,
                    (255, 255, 255, 255),
                    font_type="note"
                )
                r.ui_draw_texture(
                    info_x,
                    y,
                    w_l,
                    h_l,
                    tex_l
                )

                tex_c, w_c, h_c = self._get_text_texture(
                    "：",
                    (255, 255, 255, 255),
                    font_type="note"
                )
                r.ui_draw_texture(
                    info_x + label_w,
                    y,
                    w_c,
                    h_c,
                    tex_c
                )

                tex_v, w_v, h_v = self._get_text_texture(
                    value,
                    (255, 255, 255, 255),
                    font_type="note"
                )
                r.ui_draw_texture(
                    info_x + label_w + value_offset,
                    y,
                    w_v,
                    h_v,
                    tex_v
                )

            # ----------------------------
            # YES / NO
            # ----------------------------
            tex_yes, w_yes, h_yes = self._get_text_texture(
                "ENTER : はい",
                (255, 80, 80, 255),
                font_type="note"
            )
            tex_no, w_no, h_no = self._get_text_texture(
                "CANCEL : いいえ",
                (80, 255, 80, 255),
                font_type="note"
            )

            button_gap = 14
            button_base_y = oy + overlay_h - (h_yes + h_no + button_gap + 28)

            r.ui_draw_texture(
                (self.W - w_yes) // 2,
                button_base_y,
                w_yes,
                h_yes,
                tex_yes
            )
            r.ui_draw_texture(
                (self.W - w_no) // 2,
                button_base_y + h_yes + button_gap,
                w_no,
                h_no,
                tex_no
            )

        self.engine.overlay.draw()

        r.ui_swap()
    # --------------------------------------------------
    def run(self):

        next_scene = self._handle_input()

        if next_scene is not None:
            return next_scene

        if self._dirty:
            self._draw()
            self._dirty = False

        return self