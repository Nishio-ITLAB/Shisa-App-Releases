# framework/scenes/game/root.py

import time

from framework.scene import Scene
from framework.input_types import EventType, ButtonType

from framework.scenes.game.font_manager import FontManager
from framework.scenes.game.cutin_view import CutinView
from framework.scenes.game.pause_view import PauseView
from framework.scenes.game.stuck_dart_view import StuckDartView
from games.countup.view import CountupView


class GameScene(Scene):

    def __init__(self, engine, controller):
        super().__init__(engine)

        self.controller = controller

        self.r = self.engine.renderer
        self.W = self.r.width
        self.H = self.r.height

        self.fonts = FontManager()
        self.cutin_view = CutinView(self.r, self.fonts)
        self.pause_view = PauseView(self.r, self.fonts)
        self.game_view = CountupView(self.r, self.fonts, self.controller)

        # ----------------------------
        # Pause menu
        # ----------------------------
        self.pause_mode = False
        self.pause_index = 0

        self.pause_confirm_mode = False
        self.pause_confirm_target = None

        self.pause_items = [
            {"type": "back", "label": "ゲームに戻る"},
            {"type": "toggle_miss", "label": "盤外MISSを1投に含める"},
            {"type": "undo", "label": "前の投球に戻す"},
            {"type": "empty", "label": ""},
            {"type": "empty", "label": ""},
            {"type": "empty", "label": ""},
            {"type": "quit", "label": "ゲームを終了する"},
        ]

        # ----------------------------
        # Stuck Dart Quation
        # ----------------------------        
        self.stuck_dart_view = StuckDartView(self.r, self.fonts)

        # ----------------------------
        # Dirty draw control
        # ----------------------------
        self._dirty = True
        self._last_view_key = None

    # --------------------------------------------------
    def _move_pause_index(self, direction):

        total = len(self.pause_items)

        for _ in range(total):
            self.pause_index = (self.pause_index + direction) % total

            item = self.pause_items[self.pause_index]
            if item.get("type") != "empty":
                return

    # --------------------------------------------------
    def _handle_input(self):
        events = self.get_events()

        for e in events:

            self._dirty = True

            if e.type != EventType.BUTTON_PRESSED:
                if not self.pause_mode:
                    self.controller.handle_event(e)
                continue

            # ----------------------------
            # Pause confirm mode
            # ----------------------------
            if self.pause_confirm_mode:

                if e.payload == ButtonType.ENTER:

                    if self.pause_confirm_target == "undo":
                        self.controller.undo()
                        self.pause_confirm_mode = False
                        self.pause_confirm_target = None
                        self.pause_mode = False
                        return None

                    elif self.pause_confirm_target == "quit":
                        from framework.scenes.game.result import GameResultScene
                        return GameResultScene(self.engine, self.controller)

                elif e.payload == ButtonType.CANCEL:
                    self.pause_confirm_mode = False
                    self.pause_confirm_target = None
                    return None

                return None

            # ----------------------------
            # Pause menu mode
            # ----------------------------
            if self.pause_mode:

                if e.payload == ButtonType.NAV_UP:
                    self._move_pause_index(-1)
                    self.engine.audio.play("select")

                elif e.payload == ButtonType.NAV_DOWN:
                    self._move_pause_index(1)
                    self.engine.audio.play("select")

                elif e.payload == ButtonType.CANCEL:
                    self.pause_mode = False
                    self.engine.audio.play("cancel")

                elif e.payload == ButtonType.ENTER:

                    item = self.pause_items[self.pause_index]
                    item_type = item.get("type")

                    if item_type == "back":
                        self.pause_mode = False
                        self.engine.audio.play("enter")

                    elif item_type == "toggle_miss":
                        self.controller.toggle_count_miss_as_throw()
                        self.engine.audio.play("enter")

                    elif item_type == "undo":
                        if not self.controller.can_undo():
                            self.engine.audio.play("miss")
                        else:
                            self.pause_confirm_mode = True
                            self.pause_confirm_target = "undo"
                            self.engine.audio.play("enter")

                    elif item_type == "quit":
                        self.pause_confirm_mode = True
                        self.pause_confirm_target = "quit"
                        self.engine.audio.play("enter")

                    elif item_type == "empty":
                        self.engine.audio.play("miss")

                return None

            # ----------------------------
            # Normal game mode
            # ----------------------------
            if e.payload == ButtonType.CANCEL:
                self.pause_mode = True
                self.pause_index = 0
                self.engine.audio.play("maintenance")
                return None

            self.controller.handle_event(e)

        return None

    # --------------------------------------------------
    def _make_view_key(self):
        state = self.controller.state
        now = time.time()

        enter_indicator_visible = (
            not self.pause_mode
            and state.waiting_for_throw_collect
            and not state.throw_collect_confirmed
            and (
                state.throw_collect_blink_immediate
                or now >= state.throw_collect_ready_at
            )
        )

        cutin_active = getattr(state, "cutin_active", False)

        return (
            state.current_player,
            state.round_no,
            state.dart_no,
            tuple(state.scores),
            len(state.throw_history),

            state.waiting_for_throw_collect,
            state.throw_collect_confirmed,
            state.throw_collect_blink_immediate,

            state.stuck_dart_message,
            int(now < state.stuck_dart_until),

            enter_indicator_visible,
            int(now * 30) if enter_indicator_visible else 0,

            cutin_active,
            int(now * 30) if cutin_active else 0,

            getattr(state, "finished", False),
            self.pause_mode,
            self.pause_index,
            self.pause_confirm_mode,
            self.pause_confirm_target,
        )
        
    # --------------------------------------------------
    def _draw(self):
        self.r.ui_clear(0.0, 0.0, 0.0)

        self.game_view.draw(
            show_enter_indicator=not self.pause_mode
        )

        self.cutin_view.draw(
            state=self.controller.state,
            W=self.W,
            H=self.H,
        ) 

        self.stuck_dart_view.draw(
            state=self.controller.state,
            W=self.W,
            H=self.H,
        )

        if self.pause_mode:
            self.pause_view.draw(
                pause_index=self.pause_index,
                pause_items=self.pause_items,
                pause_confirm_mode=self.pause_confirm_mode,
                pause_confirm_target=self.pause_confirm_target,
                controller=self.controller,
                W=self.W,
                H=self.H,
            )

        self.r.ui_swap()

    # --------------------------------------------------
    def run(self):

        self.controller.update()

        self._update_leds()

        next_scene = self._handle_input()

        if next_scene is not None:
            return next_scene

        if self.controller.state.finished:
            from framework.scenes.game.result import GameResultScene
            return GameResultScene(self.engine, self.controller)

        view_key = self._make_view_key()

        if self._dirty or view_key != self._last_view_key:
            self._draw()
            self._last_view_key = view_key
            self._dirty = False

        return self

    # --------------------------------------------------
    def _update_leds(self):

        led = getattr(self.engine, "led", None)
        if led is None:
            return

        state = self.controller.state

        if state.waiting_for_throw_collect:

            if state.throw_collect_confirmed:
                led.restore_button_leds()

            elif (
                state.throw_collect_blink_immediate
                or time.time() >= state.throw_collect_ready_at
            ):
                led.set_enter_blink_only()

            else:
                led.restore_button_leds()

        else:
            led.restore_button_leds()

        led.update()