# framework/input_keyboard.py

import os
import time
import select
import struct
from typing import List

from framework.input_types import InputEvent, EventType


EV_KEY = 0x01
KEY_RELEASED = 0
KEY_PRESSED = 1
KEY_REPEAT = 2

INPUT_EVENT_FORMAT = "llHHI"
INPUT_EVENT_SIZE = struct.calcsize(INPUT_EVENT_FORMAT)


KEY_MAP = {
    2: "1",
    3: "2",
    4: "3",
    5: "4",
    6: "5",
    7: "6",
    8: "7",
    9: "8",
    10: "9",
    11: "0",

    12: "-",
    13: "=",
    26: "[",
    27: "]",
    39: ";",
    40: "'",
    41: "`",
    43: "\\",
    51: ",",
    52: ".",
    53: "/",

    16: "q",
    17: "w",
    18: "e",
    19: "r",
    20: "t",
    21: "y",
    22: "u",
    23: "i",
    24: "o",
    25: "p",
    30: "a",
    31: "s",
    32: "d",
    33: "f",
    34: "g",
    35: "h",
    36: "j",
    37: "k",
    38: "l",
    44: "z",
    45: "x",
    46: "c",
    47: "v",
    48: "b",
    49: "n",
    50: "m",

    57: " ",
}

SHIFT_KEY_MAP = {
    2: "!",
    3: '"',
    4: "#",
    5: "$",
    6: "%",
    7: "&",
    8: "'",
    9: "(",
    10: ")",
    11: "",

    12: "_",
    13: "+",
    26: "{",
    27: "}",
    39: ":",
    40: '"',
    41: "~",
    43: "|",
    51: "<",
    52: ">",
    53: "?",

    16: "Q",
    17: "W",
    18: "E",
    19: "R",
    20: "T",
    21: "Y",
    22: "U",
    23: "I",
    24: "O",
    25: "P",
    30: "A",
    31: "S",
    32: "D",
    33: "F",
    34: "G",
    35: "H",
    36: "J",
    37: "K",
    38: "L",
    44: "Z",
    45: "X",
    46: "C",
    47: "V",
    48: "B",
    49: "N",
    50: "M",
}


class KeyboardInput:

    def __init__(self):
        self.devices = []
        self.shift = False
        self.ctrl = False
        self.alt = False

        self.last_scan_time = 0
        self.scan_interval = 2.0

        self._open_keyboards()

    def _open_keyboards(self):
        self.devices.clear()

        for i in range(32):
            path = f"/dev/input/event{i}"

            if not os.path.exists(path):
                continue

            name = self._read_device_name(path)

            if not self._looks_like_keyboard(name):
                continue

            try:
                fd = os.open(path, os.O_RDONLY | os.O_NONBLOCK)
                self.devices.append((path, fd))
                print("KeyboardInput opened:", path, name)

            except PermissionError:
                #print("KeyboardInput permission denied:", path)
                pass

            except Exception as e:
                print("KeyboardInput open error:", path, e)

    def _read_device_name(self, event_path):
        base = os.path.basename(event_path)
        sys_name_path = f"/sys/class/input/{base}/device/name"

        try:
            with open(sys_name_path, "r") as f:
                return f.read().strip()
        except Exception:
            return ""

    def _looks_like_keyboard(self, name):
        n = name.lower()

        if "consumer control" in n:
            return False

        if "system control" in n:
            return False

        if "keyboard" in n:
            return True

        if "kbd" in n:
            return True

        return False

    def poll(self) -> List[InputEvent]:
        events: List[InputEvent] = []

        if not self.devices:
            now_scan = time.time()

            if now_scan - self.last_scan_time >= self.scan_interval:
                self.last_scan_time = now_scan
                self._open_keyboards()

        if not self.devices:
            return events

        fds = [fd for _, fd in self.devices]

        try:
            readable, _, _ = select.select(fds, [], [], 0)
        except Exception:
            return events

        now = time.time()

        for path, fd in list(self.devices):

            if fd not in readable:
                continue

            while True:
                try:
                    data = os.read(fd, INPUT_EVENT_SIZE)
                except BlockingIOError:
                    break
                except Exception as e:
                    print("KeyboardInput read error:", path, e)
                    self._close_device(path, fd)
                    break

                if not data or len(data) < INPUT_EVENT_SIZE:
                    break

                _, _, ev_type, code, value = struct.unpack(INPUT_EVENT_FORMAT, data)

                if ev_type != EV_KEY:
                    continue

                result = self._handle_key(code, value)

                if result is not None:
                    events.append(
                        InputEvent(
                            type=EventType.KEY_PRESSED,
                            payload=result,
                            timestamp=now
                        )
                    )

        return events

    def _handle_key(self, code, value):

        # Shift
        if code == 42 or code == 54:
            self.shift = value != KEY_RELEASED
            return None

        # Ctrl
        if code == 29 or code == 97:
            self.ctrl = value != KEY_RELEASED
            return None

        # Alt
        if code == 56 or code == 100:
            self.alt = value != KEY_RELEASED
            return None

        if value != KEY_PRESSED and value != KEY_REPEAT:
            return None

        # Ctrl / Alt 系は無視
        if self.ctrl or self.alt:
            return None

        if code == 14:
            return "BACKSPACE"

        if code == 111:
            return "DELETE"

        if code == 28 or code == 96:
            return "ENTER"

        if code == 1:
            return "ESCAPE"

        if self.shift:
            return SHIFT_KEY_MAP.get(code)

        return KEY_MAP.get(code)

    def _close_device(self, path, fd):
        try:
            os.close(fd)
        except Exception:
            pass

        self.devices = [
            (p, f) for p, f in self.devices
            if not (p == path and f == fd)
        ]