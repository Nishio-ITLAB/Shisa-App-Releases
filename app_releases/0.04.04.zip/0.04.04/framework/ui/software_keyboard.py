# framework/ui/software_keyboard.py

import time
import numpy as np
from PIL import Image, ImageDraw, ImageFont

from framework.scene import Scene
from framework.input_types import EventType, ButtonType


FONT_PATH = "/opt/shisa/current/system_assets/fonts/NotoSansMono-Regular.ttf"


KEY_LAYOUT = [
    list("ABCDEFGHIJ"),
    list("KLMNOPQRST"),
    list("UVWXYZabcd"),
    list("efghijklmn"),
    list("opqrstuvwx"),
    list("yz01234567"),
    list('89-_.@!":'),
    list("#$%&+=/?"),
    ["SPACE", "DEL", "OK"]
]


class SoftwareKeyboardScene(Scene):

    def __init__(self, engine, title, initial, on_done):

        super().__init__(engine)

        self.title = title
        self.text = initial
        self.on_done = on_done

        self.r = self.engine.renderer
        self.W = self.r.width
        self.H = self.r.height

        self.cursor_y = 0
        self.cursor_x = 0

        self.font = ImageFont.truetype(FONT_PATH, int(self.H * 0.05))
        self.title_font = ImageFont.truetype(FONT_PATH, int(self.H * 0.07))

        self.spacing_x = 160
        self.spacing_y = 70
        self.spacing_x_last = 320

        self.pad_x = 10
        self.pad_y = 4

        self.start_y = int(self.H * 0.35)

        self.title_tex = None
        self.input_tex = None
        self.input_dirty = True

        self.key_textures_normal = {}
        self.key_textures_selected = {}

        self.keyboard_tex = None
        self.keyboard_w = 0
        self.keyboard_h = 0
        self.keyboard_x = 0
        self.keyboard_y = self.start_y

        self.key_positions = {}

        self._build_static_resources()

    def _render_text(self, text, font, color):

        w = max(1, int(font.getlength(text)))
        ascent, descent = font.getmetrics()
        h = max(1, ascent + descent)

        img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        draw.text((0, 0), text, font=font, fill=color)

        return np.array(img, dtype=np.uint8), w, h

    def _build_static_resources(self):

        self.title_tex = self._render_text(
            self.title,
            self.title_font,
            (255, 255, 255, 255)
        )

        for row in KEY_LAYOUT:

            for key in row:

                if key not in self.key_textures_normal:

                    normal_color = (200, 200, 200, 255)
                    if key == "OK":
                        normal_color = (100, 255, 100, 255)

                    self.key_textures_normal[key] = self._render_text(
                        key,
                        self.font,
                        normal_color
                    )

                    self.key_textures_selected[key] = self._render_text(
                        key,
                        self.font,
                        (255, 255, 255, 255)
                    )

        self._build_keyboard_texture()

    def _build_keyboard_texture(self):

        row_widths = []

        for y, row in enumerate(KEY_LAYOUT):
            spacing = self.spacing_x_last if y == len(KEY_LAYOUT) - 1 else self.spacing_x
            row_widths.append(len(row) * spacing)

        self.keyboard_w = max(row_widths)

        self.keyboard_h = (
            (len(KEY_LAYOUT) - 1) * self.spacing_y
            + max(tex[2] for tex in self.key_textures_normal.values())
        )

        self.keyboard_x = (self.W - self.keyboard_w) // 2

        img = Image.new("RGBA", (self.keyboard_w, self.keyboard_h), (0, 0, 0, 0))

        self.key_positions.clear()

        for y, row in enumerate(KEY_LAYOUT):

            spacing = self.spacing_x_last if y == len(KEY_LAYOUT) - 1 else self.spacing_x
            total_w = len(row) * spacing
            row_start_x = (self.keyboard_w - total_w) // 2

            for x, key in enumerate(row):

                tex, tw, th = self.key_textures_normal[key]

                px = row_start_x + x * spacing
                py = y * self.spacing_y

                key_img = Image.fromarray(tex, "RGBA")

                img.paste(key_img, (px, py), key_img)

                self.key_positions[(y, x)] = {
                    "x": px,
                    "y": py,
                    "w": tw,
                    "h": th,
                    "key": key,
                }

        self.keyboard_tex = np.array(img, dtype=np.uint8)

    def _update_input_texture(self):

        display = self.text + "|"

        self.input_tex = self._render_text(
            display,
            self.font,
            (255, 255, 80, 255)
        )

        self.input_dirty = False

    def _handle_input(self):

        events = self.get_events()

        for e in events:

            if e.type == EventType.KEY_PRESSED:
                result = self._press_physical_key(e.payload)

                if result is not None:
                    return result

                continue

            if e.type != EventType.BUTTON_PRESSED:
                continue

            if e.payload == ButtonType.NAV_UP:
                self.cursor_y = max(0, self.cursor_y - 1)

            elif e.payload == ButtonType.NAV_DOWN:
                self.cursor_y = min(len(KEY_LAYOUT) - 1, self.cursor_y + 1)

            elif e.payload == ButtonType.NAV_LEFT:
                self.cursor_x = max(0, self.cursor_x - 1)

            elif e.payload == ButtonType.NAV_RIGHT:
                row_len = len(KEY_LAYOUT[self.cursor_y])
                self.cursor_x = min(row_len - 1, self.cursor_x + 1)

            elif e.payload == ButtonType.ENTER:

                result = self._press_key()

                if result is not None:
                    return result

            elif e.payload == ButtonType.CANCEL:

                return self.on_done(None)

            row_len = len(KEY_LAYOUT[self.cursor_y])

            if self.cursor_x >= row_len:
                self.cursor_x = row_len - 1

        return None

    def _press_physical_key(self, key):

        if key == "BACKSPACE" or key == "DELETE":

            self.text = self.text[:-1]
            self.input_dirty = True

        elif key == "ENTER":

            return self.on_done(self.text)

        elif key == "ESCAPE":

            return self.on_done(None)

        elif isinstance(key, str) and len(key) == 1:

            self.text += key
            self.input_dirty = True

        return None

    def _press_key(self):

        key = KEY_LAYOUT[self.cursor_y][self.cursor_x]

        if key == "SPACE":

            self.text += " "
            self.input_dirty = True

        elif key == "DEL":

            self.text = self.text[:-1]
            self.input_dirty = True

        elif key == "OK":

            return self.on_done(self.text)

        else:

            self.text += key
            self.input_dirty = True

        return None

    def _draw_selected_key_overlay(self):

        info = self.key_positions[(self.cursor_y, self.cursor_x)]

        rect_x = self.keyboard_x + info["x"] - self.pad_x
        rect_y = self.keyboard_y + info["y"] - self.pad_y
        rect_w = info["w"] + self.pad_x * 2
        rect_h = info["h"] + self.pad_y * 2

        self.r.ui_draw_rect(
            rect_x,
            rect_y,
            rect_w,
            rect_h,
            (0.3, 0.0, 0.0, 1.0)
        )

        tex, tw, th = self.key_textures_selected[info["key"]]

        self.r.ui_draw_texture(
            self.keyboard_x + info["x"],
            self.keyboard_y + info["y"],
            tw,
            th,
            tex
        )

    def _draw(self):

        r = self.r

        r.ui_clear(0, 0, 0)

        tex, w, h = self.title_tex

        r.ui_draw_texture(
            (self.W - w) // 2,
            int(self.H * 0.10),
            w,
            h,
            tex
        )

        if self.input_dirty or self.input_tex is None:
            self._update_input_texture()

        tex, w, h = self.input_tex

        r.ui_draw_texture(
            (self.W - w) // 2,
            int(self.H * 0.22),
            w,
            h,
            tex
        )

        r.ui_draw_texture(
            self.keyboard_x,
            self.keyboard_y,
            self.keyboard_w,
            self.keyboard_h,
            self.keyboard_tex
        )

        self._draw_selected_key_overlay()

        self.engine.overlay.draw()

        r.ui_swap()

    def run(self):

        next_scene = self._handle_input()

        self._draw()

        time.sleep(0.01)

        if next_scene is not None:
            return next_scene

        return self