# framework/scenes/service/online_update.py

import os
import time
import json
import urllib.request
import urllib.error
import subprocess
import shutil
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont

from framework.scene import Scene
from framework.input_types import EventType, ButtonType
from framework.ui.software_keyboard import SoftwareKeyboardScene

from utils.network import connect_wifi, check_internet, disconnect_wifi


FONT_PATH = "/opt/shisa/current/system_assets/fonts/NotoSansMono-Regular.ttf"

# --------------------------------------------------
# GitHub OTA source
# --------------------------------------------------

GITHUB_OWNER = "Nishio-ITLAB"
GITHUB_REPO = "Shisa-App-Releases"
GITHUB_APP_RELEASES_DIR = "app_releases"
GITHUB_ASSET_RELEASES_DIR = "asset_releases"

GITHUB_APP_CONTENTS_API_URL = (
    f"https://api.github.com/repos/{GITHUB_OWNER}/{GITHUB_REPO}/contents/{GITHUB_APP_RELEASES_DIR}"
)

GITHUB_ASSET_CONTENTS_API_URL = (
    f"https://api.github.com/repos/{GITHUB_OWNER}/{GITHUB_REPO}/contents/{GITHUB_ASSET_RELEASES_DIR}"
)

# --------------------------------------------------
# OTA paths
# --------------------------------------------------

UPLOAD_DIR = Path("/opt/shisa/shared/uploads")
TMP_DIR = UPLOAD_DIR / "tmp_extract"
RELEASES_DIR = Path("/opt/shisa/releases")
CURRENT_LINK = Path("/opt/shisa/current")
ASSET_RELEASES_DIR = Path("/opt/shisa/asset_releases")
CURRENT_ASSETS_LINK = Path("/opt/shisa/current_assets")

class OnlineUpdateScene(Scene):

    def __init__(self, engine):
        super().__init__(engine)

        self.config = self.engine.system_config

        self.r = self.engine.renderer
        self.W = self.r.width
        self.H = self.r.height

        # --------------------------------------------------
        # Font
        # --------------------------------------------------

        self.title_font_size = int(self.H * 0.08)
        self.menu_font_size = int(self.H * 0.055)
        self.log_font_size = int(self.H * 0.020)

        self.title_font = ImageFont.truetype(FONT_PATH, self.title_font_size)
        self.menu_font = ImageFont.truetype(FONT_PATH, self.menu_font_size)
        self.log_font = ImageFont.truetype(FONT_PATH, self.log_font_size)

        ascent_t, descent_t = self.title_font.getmetrics()
        self.title_height = ascent_t + descent_t

        ascent_m, descent_m = self.menu_font.getmetrics()
        self.menu_height = ascent_m + descent_m

        ascent_l, descent_l = self.log_font.getmetrics()
        self.log_height = ascent_l + descent_l

        self.text_cache = {}

        # --------------------------------------------------
        # Menu
        # --------------------------------------------------

        self.menu_items = [
            "UPDATE EXECUTE",
            "SSID",
            "PASSWORD",
        ]

        self.index = 0

        # --------------------------------------------------
        # Box
        # --------------------------------------------------

        self.box_width = int(self.W * 0.7)
        self.box_height = int(self.H * 0.45)
        self.box_radius = 40

        self.box_x = (self.W - self.box_width) // 2
        self.box_y = int(self.H * 0.28)

        self._menu_box_texture = self._create_rounded_box()

        self._panel_cache = {}
        self._outline_cache = {}

        # --------------------------------------------------
        # Update state
        # --------------------------------------------------

        self.update_mode = False
        self.update_logs = []
        self.update_step = 0
        self.update_timer = 0

        self.latest = None
        self.zip_path = None

        self.latest_app = None
        self.latest_assets = None
        self.app_zip_path = None
        self.assets_zip_path = None
        self.assets_updated = False
        self.app_updated = False

        self.progress_text = ""

    # --------------------------------------------------

    def _create_rounded_box(self):

        img = Image.new("RGBA", (self.box_width, self.box_height), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        draw.rounded_rectangle(
            [0, 0, self.box_width, self.box_height],
            radius=self.box_radius,
            fill=(20, 20, 20, 220)
        )

        return np.array(img, dtype=np.uint8)

    # --------------------------------------------------

    def _get_text_texture(self, text, font, color):

        key = (text, font.size, color)

        if key in self.text_cache:
            return self.text_cache[key]

        w = max(1, int(font.getlength(text)))

        ascent, descent = font.getmetrics()
        h = ascent + descent

        img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        draw.text((0, 0), text, font=font, fill=color)

        arr = np.array(img, dtype=np.uint8)

        self.text_cache[key] = (arr, w, h)

        return arr, w, h

    # --------------------------------------------------
    def _get_panel_texture(self, w, h, radius, fill):

        key = (w, h, radius, fill)

        if key not in self._panel_cache:
            img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
            draw = ImageDraw.Draw(img)

            draw.rounded_rectangle(
                [0, 0, w - 1, h - 1],
                radius=radius,
                fill=fill
            )

            self._panel_cache[key] = np.array(img, dtype=np.uint8)

        return self._panel_cache[key]


    def _get_rect_texture(self, w, h, fill):

        key = (w, h, fill)

        if key not in self._outline_cache:
            img = Image.new("RGBA", (w, h), fill)
            self._outline_cache[key] = np.array(img, dtype=np.uint8)

        return self._outline_cache[key]


    def _draw_rect_outline(self, x, y, w, h, color, width=3):

        r = self.r

        top = self._get_rect_texture(w, width, color)
        bottom = top
        left = self._get_rect_texture(width, h, color)
        right = left

        r.ui_draw_texture(x, y, w, width, top)
        r.ui_draw_texture(x, y + h - width, w, width, bottom)
        r.ui_draw_texture(x, y, width, h, left)
        r.ui_draw_texture(x + w - width, y, width, h, right)

    # --------------------------------------------------
    # version helpers
    # --------------------------------------------------

    def _get_current_version(self):

        try:
            with open("/opt/shisa/current/version.txt", "r") as f:
                lines = f.read().splitlines()
                version = lines[0].strip() if len(lines) > 0 else "unknown"
                return version
        except Exception as e:
            print("GET CURRENT VERSION ERROR:", e)
            return "unknown"

    def _get_current_assets_version(self):

        try:
            with open("/opt/shisa/current_assets/version.txt", "r") as f:
                lines = f.read().splitlines()
                version = lines[0].strip() if len(lines) > 0 else "unknown"
                return version
        except Exception as e:
            print("GET CURRENT ASSETS VERSION ERROR:", e)
            return "unknown"

    def _parse_version_tuple(self, version_str):

        try:
            parts = version_str.strip().split(".")
            return tuple(int(p) for p in parts)
        except Exception:
            return None

    def _compare_versions(self, current_version, latest_version):

        cur = self._parse_version_tuple(current_version)
        lat = self._parse_version_tuple(latest_version)

        if cur is None or lat is None:
            return None

        if lat > cur:
            return 1

        if lat < cur:
            return -1

        return 0

    # --------------------------------------------------
    # github helpers
    # --------------------------------------------------

    def _fetch_latest_release_info(self, contents_api_url, label):

        print(f"===== FETCH LATEST {label} RELEASE INFO START =====")
        print("URL:", contents_api_url)

        req = urllib.request.Request(
            contents_api_url,
            headers={
                "Accept": "application/vnd.github+json",
                "User-Agent": "Shisa-OTA-Updater"
            }
        )

        with urllib.request.urlopen(req, timeout=10) as resp:

            status = getattr(resp, "status", None)
            print("HTTP STATUS:", status)

            body = resp.read().decode("utf-8")
            items = json.loads(body)

        if not isinstance(items, list):
            raise RuntimeError(f"INVALID GITHUB RESPONSE : {label}")

        zip_items = []

        for item in items:

            name = item.get("name", "")
            download_url = item.get("download_url", "")

            if not name.endswith(".zip"):
                continue

            version = name[:-4].strip()

            if self._parse_version_tuple(version) is None:
                print("SKIP INVALID VERSION ZIP:", name)
                continue

            zip_items.append({
                "name": name,
                "version": version,
                "download_url": download_url,
                "size": int(item.get("size", 0)),
            })

        if not zip_items:
            raise RuntimeError(f"NO {label} RELEASE ZIP FOUND")

        zip_items.sort(
            key=lambda x: self._parse_version_tuple(x["version"])
        )

        latest = zip_items[-1]

        print("LATEST ZIP NAME:", latest["name"])
        print("LATEST VERSION:", latest["version"])
        print("LATEST DOWNLOAD URL:", latest["download_url"])
        print("LATEST SIZE:", latest["size"])

        return latest

    # --------------------------------------------------
    # OTA helpers
    # --------------------------------------------------

    def _download_zip(self, url, filename, expected_size=0, label=""):

        print("===== DOWNLOAD ZIP START =====")
        print("URL:", url)
        print("FILENAME:", filename)
        print("EXPECTED SIZE:", expected_size)

        try:
            UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

            dst = UPLOAD_DIR / filename

            if dst.exists():
                dst.unlink()

            # ----------------------------------------
            # progress hook
            # ----------------------------------------
            last_percent = {"v": -1}

            def hook(block_count, block_size, total_size):

                if total_size <= 0:
                    return

                downloaded = block_count * block_size
                percent = int(downloaded * 100 / total_size)

                if percent >= last_percent["v"] + 2:
                    last_percent["v"] = percent

                    msg = f"{label} DOWNLOAD {percent}%"

                    print(msg)

                    # ★ ここが重要
                    self.progress_text = msg

            # ----------------------------------------
            # download
            # ----------------------------------------
            urllib.request.urlretrieve(
                url,
                str(dst),
                reporthook=hook
            )

            actual_size = dst.stat().st_size

            print("DOWNLOAD SUCCESS:", dst)
            print("DOWNLOAD SIZE:", actual_size)

            if expected_size > 0 and actual_size != expected_size:
                print("DOWNLOAD SIZE MISMATCH")
                self.update_logs.append("DOWNLOAD SIZE MISMATCH")

                if dst.exists():
                    dst.unlink()

                return False, None

            return True, dst

        except Exception as e:
            print("DOWNLOAD ERROR:", e)
            self.update_logs.append(f"DOWNLOAD ERROR : {e}")
            return False, None

    # --------------------------------------------------

    def _extract_zip(self, zip_path):

        print("===== EXTRACT ZIP START =====")
        print("ZIP PATH:", zip_path)

        try:
            if TMP_DIR.exists():
                shutil.rmtree(TMP_DIR)

            TMP_DIR.mkdir(parents=True, exist_ok=True)

            r = subprocess.run(
                ["unzip", "-o", str(zip_path), "-d", str(TMP_DIR)],
                capture_output=True,
                text=True
            )

            print("UNZIP RETURN:", r.returncode)
            print("UNZIP STDOUT:", r.stdout)
            print("UNZIP STDERR:", r.stderr)

            if r.returncode != 0:
                self.update_logs.append("UNZIP FAILED")
                return False

            return True

        except Exception as e:
            print("UNZIP ERROR:", e)
            self.update_logs.append(f"UNZIP ERROR : {e}")
            return False

    # --------------------------------------------------

    def _validate_release(self, version):

        print("===== VALIDATE RELEASE START =====")
        print("VERSION:", version)

        try:
            target_dir = TMP_DIR / version

            print("TARGET DIR:", target_dir)

            if not target_dir.exists():
                self.update_logs.append("INVALID STRUCTURE")
                return False

            main_py = target_dir / "main.py"
            version_txt = target_dir / "version.txt"

            if not main_py.exists():
                self.update_logs.append("main.py NOT FOUND")
                return False

            if not version_txt.exists():
                self.update_logs.append("version.txt NOT FOUND")
                return False

            with open(version_txt, "r") as f:
                lines = f.read().splitlines()

            zip_version = lines[0].strip() if len(lines) > 0 else ""

            print("ZIP VERSION:", zip_version)

            if zip_version != version:
                self.update_logs.append("VERSION MISMATCH")
                return False

            return True

        except Exception as e:
            print("VALIDATE ERROR:", e)
            self.update_logs.append(f"VALIDATE ERROR : {e}")
            return False

    # --------------------------------------------------

    def _validate_assets_release(self, version):

        print("===== VALIDATE ASSETS RELEASE START =====")
        print("VERSION:", version)

        try:
            target_dir = TMP_DIR / version

            print("TARGET DIR:", target_dir)

            if not target_dir.exists():
                self.update_logs.append("INVALID ASSETS STRUCTURE")
                return False

            version_txt = target_dir / "version.txt"

            if not version_txt.exists():
                self.update_logs.append("ASSETS version.txt NOT FOUND")
                return False

            with open(version_txt, "r") as f:
                lines = f.read().splitlines()

            zip_version = lines[0].strip() if len(lines) > 0 else ""

            print("ASSETS ZIP VERSION:", zip_version)

            if zip_version != version:
                self.update_logs.append("ASSETS VERSION MISMATCH")
                return False

            # 最低限の構造チェック
            required_dirs = [
                "audio",
                "fonts",
                "image",
                "video",
            ]

            for d in required_dirs:
                if not (target_dir / d).exists():
                    self.update_logs.append(f"ASSETS DIR NOT FOUND : {d}")
                    return False

            return True

        except Exception as e:
            print("VALIDATE ASSETS ERROR:", e)
            self.update_logs.append(f"VALIDATE ASSETS ERROR : {e}")
            return False    

    # --------------------------------------------------

    def _install_release(self, version):

        print("===== INSTALL RELEASE START =====")
        print("VERSION:", version)

        try:
            src = TMP_DIR / version
            dst = RELEASES_DIR / version

            print("SRC:", src)
            print("DST:", dst)

            RELEASES_DIR.mkdir(parents=True, exist_ok=True)

            if dst.exists():
                shutil.rmtree(dst)

            shutil.move(str(src), str(dst))

            # ============================
            # ① パーミッション修正
            # ============================
            Path(dst).chmod(0o755)

            for root, dirs, files in os.walk(dst):
                for d in dirs:
                    Path(root, d).chmod(0o755)
                for f in files:
                    Path(root, f).chmod(0o644)

            # ============================
            # ② ★最重要: 所有者修正
            # ============================
            subprocess.run([
                "sudo", "chown", "-R", "pi:pi", str(dst)
            ])

            print("INSTALL SUCCESS")

            return True

        except Exception as e:
            print("INSTALL ERROR:", e)
            self.update_logs.append(f"INSTALL ERROR : {e}")
            return False

    # --------------------------------------------------

    def _install_assets_release(self, version):

        print("===== INSTALL ASSETS RELEASE START =====")
        print("VERSION:", version)

        try:
            src = TMP_DIR / version
            dst = ASSET_RELEASES_DIR / version

            print("SRC:", src)
            print("DST:", dst)

            ASSET_RELEASES_DIR.mkdir(parents=True, exist_ok=True)

            if dst.exists():
                shutil.rmtree(dst)

            shutil.move(str(src), str(dst))

            Path(dst).chmod(0o755)

            for root, dirs, files in os.walk(dst):
                for d in dirs:
                    Path(root, d).chmod(0o755)
                for f in files:
                    Path(root, f).chmod(0o644)

            subprocess.run([
                "sudo", "chown", "-R", "pi:pi", str(dst)
            ])

            print("INSTALL ASSETS SUCCESS")

            return True

        except Exception as e:
            print("INSTALL ASSETS ERROR:", e)
            self.update_logs.append(f"INSTALL ASSETS ERROR : {e}")
            return False

    # --------------------------------------------------

    def _switch_current(self, version):

        print("===== SWITCH CURRENT START =====")
        print("VERSION:", version)

        try:
            target = RELEASES_DIR / version

            if not target.exists():
                self.update_logs.append("TARGET RELEASE NOT FOUND")
                return False

            # ============================
            # currentリンク更新
            # ============================
            r = subprocess.run(
                ["ln", "-sfn", str(target), str(CURRENT_LINK)],
                capture_output=True,
                text=True
            )

            print("LINK RETURN:", r.returncode)
            print("LINK STDOUT:", r.stdout)
            print("LINK STDERR:", r.stderr)

            if r.returncode != 0:
                self.update_logs.append("CURRENT LINK FAILED")
                return False

            # ★ symlinkの所有者修正（重要）
            subprocess.run([
                "sudo", "chown", "-h", "pi:pi", str(CURRENT_LINK)
            ])

            # ============================
            # assetsリンク更新
            # ============================
            assets_link = target / "assets"

            if assets_link.exists() or assets_link.is_symlink():
                assets_link.unlink()

            r = subprocess.run(
                ["ln", "-sfn", "/opt/shisa/current_assets", str(assets_link)],
                capture_output=True,
                text=True
            )

            print("ASSETS LINK RETURN:", r.returncode)
            print("ASSETS LINK STDOUT:", r.stdout)
            print("ASSETS LINK STDERR:", r.stderr)

            if r.returncode != 0:
                self.update_logs.append("ASSETS LINK FAILED")
                return False

            # ★ assets symlinkの所有者修正
            subprocess.run([
                "sudo", "chown", "-h", "pi:pi", str(assets_link)
            ])

            return True

        except Exception as e:
            print("SWITCH CURRENT ERROR:", e)
            self.update_logs.append(f"SWITCH ERROR : {e}")
            return False

    # --------------------------------------------------

    def _switch_current_assets(self, version):

        print("===== SWITCH CURRENT ASSETS START =====")
        print("VERSION:", version)

        try:
            target = ASSET_RELEASES_DIR / version

            if not target.exists():
                self.update_logs.append("TARGET ASSETS NOT FOUND")
                return False

            r = subprocess.run(
                ["ln", "-sfn", str(target), str(CURRENT_ASSETS_LINK)],
                capture_output=True,
                text=True
            )

            print("CURRENT ASSETS LINK RETURN:", r.returncode)
            print("CURRENT ASSETS LINK STDOUT:", r.stdout)
            print("CURRENT ASSETS LINK STDERR:", r.stderr)

            if r.returncode != 0:
                self.update_logs.append("CURRENT ASSETS LINK FAILED")
                return False

            subprocess.run([
                "sudo", "chown", "-h", "pi:pi", str(CURRENT_ASSETS_LINK)
            ])

            return True

        except Exception as e:
            print("SWITCH CURRENT ASSETS ERROR:", e)
            self.update_logs.append(f"SWITCH ASSETS ERROR : {e}")
            return False    

    # --------------------------------------------------

    def _remove_old_release(self, new_version):

        print("===== REMOVE OLD RELEASE START =====")
        print("KEEP VERSION:", new_version)

        try:
            keep_dir = RELEASES_DIR / new_version

            for path in RELEASES_DIR.iterdir():
                if not path.is_dir():
                    continue

                if path.resolve() == keep_dir.resolve():
                    continue

                print("REMOVE OLD RELEASE:", path)
                shutil.rmtree(path)

            return True

        except Exception as e:
            print("REMOVE OLD RELEASE ERROR:", e)
            self.update_logs.append(f"REMOVE OLD RELEASE ERROR : {e}")
            return False

    # --------------------------------------------------

    def _remove_old_assets_release(self, new_version):

        print("===== REMOVE OLD ASSETS RELEASE START =====")
        print("KEEP ASSETS VERSION:", new_version)

        try:
            keep_dir = ASSET_RELEASES_DIR / new_version

            for path in ASSET_RELEASES_DIR.iterdir():
                if not path.is_dir():
                    continue

                if path.resolve() == keep_dir.resolve():
                    continue

                print("REMOVE OLD ASSETS RELEASE:", path)
                shutil.rmtree(path)

            return True

        except Exception as e:
            print("REMOVE OLD ASSETS RELEASE ERROR:", e)
            self.update_logs.append(f"REMOVE OLD ASSETS RELEASE ERROR : {e}")
            return False

    # --------------------------------------------------

    def _cleanup(self, *zip_paths):

        print("===== CLEANUP START =====")

        try:
            for zip_path in zip_paths:
                if zip_path is not None and Path(zip_path).exists():
                    Path(zip_path).unlink()
                    print("ZIP REMOVED:", zip_path)

            if TMP_DIR.exists():
                shutil.rmtree(TMP_DIR)
                print("TMP REMOVED:", TMP_DIR)

            return True

        except Exception as e:
            print("CLEANUP ERROR:", e)
            self.update_logs.append(f"CLEANUP ERROR : {e}")
            return False

    # --------------------------------------------------

    def _reboot_system(self):

        print("===== REBOOT START =====")

        try:
            subprocess.Popen(["sudo", "reboot"])
        except Exception as e:
            print("REBOOT ERROR:", e)
            self.update_logs.append(f"REBOOT ERROR : {e}")

    # --------------------------------------------------
    # keyboard callbacks
    # --------------------------------------------------

    def _set_ssid(self, value):

        if value is not None:
            self.config.set_wifi_ssid(value)

        return self

    def _set_pass(self, value):

        if value is not None:
            self.config.set_wifi_password(value)

        return self

    def _can_execute_update(self):
        return bool(self.config.get_wifi_ssid().strip())

    # --------------------------------------------------
    # update process
    # --------------------------------------------------

    def _update_process(self):

        # --------------------------------------------------
        # 1: Wi-Fi 接続開始
        # --------------------------------------------------
        if self.update_step == 1:

            self.update_logs.append("WIFI CONNECTING...")
            self.update_step = 2
            return

        # --------------------------------------------------
        # 2: Wi-Fi 接続実行
        # --------------------------------------------------
        elif self.update_step == 2:

            ok, msg = connect_wifi(
                self.config.get_wifi_ssid(),
                self.config.get_wifi_password()
            )

            self.update_logs.append(msg)

            if ok:
                self.update_step = 3
            else:
                self.update_timer = time.time()
                self.update_step = 6

            return

        # --------------------------------------------------
        # 3: Internet check 開始
        # --------------------------------------------------
        elif self.update_step == 3:

            self.update_logs.append("CHECK INTERNET...")
            self.update_step = 4
            return

        # --------------------------------------------------
        # 4: Internet check 実行
        # --------------------------------------------------
        elif self.update_step == 4:

            ok, msg = check_internet()

            self.update_logs.append(msg)

            if ok:
                self.update_step = 5
            else:
                self.update_timer = time.time()
                self.update_step = 6

            return

        # --------------------------------------------------
        # 5: assets update check へ
        # --------------------------------------------------
        elif self.update_step == 5:

            self.update_logs.append("CHECK ASSETS VERSION...")
            self.update_step = 7
            return

        # --------------------------------------------------
        # 6: FAILED
        # --------------------------------------------------
        elif self.update_step == 6:

            if not self.update_logs or self.update_logs[-1] != "FAILED":
                self.update_logs.append("FAILED")

            if time.time() - self.update_timer > 3:
                disconnect_wifi()
                self.update_mode = False

            return

        # --------------------------------------------------
        # 7: assets 最新確認
        # --------------------------------------------------
        elif self.update_step == 7:

            try:
                current_assets_version = self._get_current_assets_version()
                self.update_logs.append(f"ASSETS CURRENT : {current_assets_version}")

                latest_assets = self._fetch_latest_release_info(
                    GITHUB_ASSET_CONTENTS_API_URL,
                    "ASSETS"
                )

                latest_assets_version = latest_assets["version"]
                self.update_logs.append(f"ASSETS LATEST  : {latest_assets_version}")

                cmp_result = self._compare_versions(
                    current_assets_version,
                    latest_assets_version
                )

                if cmp_result is None:
                    self.update_logs.append("ASSETS VERSION COMPARE ERROR")
                    self.update_timer = time.time()
                    self.update_step = 6

                elif cmp_result < 0:
                    self.update_logs.append("LOCAL ASSETS VERSION IS NEWER")
                    self.update_step = 20

                elif cmp_result == 0:
                    self.update_logs.append("NO ASSETS UPDATE")
                    self.update_step = 20

                else:
                    self.latest_assets = latest_assets
                    self.update_logs.append("ASSETS UPDATE AVAILABLE")
                    self.update_step = 9

            except urllib.error.HTTPError as e:
                self.update_logs.append(f"ASSETS GITHUB HTTP ERROR : {e.code}")
                self.update_timer = time.time()
                self.update_step = 6

            except urllib.error.URLError as e:
                self.update_logs.append(f"ASSETS GITHUB URL ERROR : {e.reason}")
                self.update_timer = time.time()
                self.update_step = 6

            except Exception as e:
                self.update_logs.append(f"ASSETS GITHUB ERROR : {e}")
                self.update_timer = time.time()
                self.update_step = 6

            return

        # --------------------------------------------------
        # 8: 未使用
        # --------------------------------------------------
        elif self.update_step == 8:

            if time.time() - self.update_timer > 3:
                disconnect_wifi()
                self.update_mode = False

            return

        # --------------------------------------------------
        # 9: assets download
        # --------------------------------------------------
        elif self.update_step == 9:

            self.update_logs.append("ASSETS UPDATE AVAILABLE")
            self.progress_text = "ASSETS DOWNLOAD 0%"

            ok, zip_path = self._download_zip(
                self.latest_assets["download_url"],
                "assets_" + self.latest_assets["name"],
                self.latest_assets.get("size", 0),
                label="ASSETS"
            )

            if ok:
                self.assets_zip_path = zip_path
                self.update_logs.append("DOWNLOAD ASSETS OK")
                self.update_step = 10
            else:
                self.update_timer = time.time()
                self.update_step = 6

            return

        # --------------------------------------------------
        # 10: assets extract
        # --------------------------------------------------
        elif self.update_step == 10:

            self.update_logs.append("EXTRACT ASSETS ZIP...")

            if self._extract_zip(self.assets_zip_path):
                self.update_logs.append("EXTRACT ASSETS OK")
                self.update_step = 11
            else:
                self.update_timer = time.time()
                self.update_step = 6

            return

        # --------------------------------------------------
        # 11: assets validate
        # --------------------------------------------------
        elif self.update_step == 11:

            self.update_logs.append("VALIDATE ASSETS...")

            if self._validate_assets_release(self.latest_assets["version"]):
                self.update_logs.append("VALIDATE ASSETS OK")
                self.update_step = 12
            else:
                self.update_timer = time.time()
                self.update_step = 6

            return

        # --------------------------------------------------
        # 12: assets install
        # --------------------------------------------------
        elif self.update_step == 12:

            self.update_logs.append("INSTALL ASSETS...")

            if self._install_assets_release(self.latest_assets["version"]):
                self.update_logs.append("INSTALL ASSETS OK")
                self.update_step = 13
            else:
                self.update_timer = time.time()
                self.update_step = 6

            return

        # --------------------------------------------------
        # 13: current_assets 切替
        # --------------------------------------------------
        elif self.update_step == 13:

            self.update_logs.append("SWITCH CURRENT ASSETS...")

            if self._switch_current_assets(self.latest_assets["version"]):
                self.update_logs.append("SWITCH CURRENT ASSETS OK")
                self.assets_updated = True
                self.update_step = 14
            else:
                self.update_timer = time.time()
                self.update_step = 6

            return

        # --------------------------------------------------
        # 14: old assets release 削除
        # --------------------------------------------------
        elif self.update_step == 14:

            self.update_logs.append("REMOVE OLD ASSETS RELEASE...")

            if self._remove_old_assets_release(self.latest_assets["version"]):
                self.update_logs.append("REMOVE OLD ASSETS RELEASE OK")
                self.update_step = 20
            else:
                self.update_timer = time.time()
                self.update_step = 6

            return

        # --------------------------------------------------
        # 20: app 最新確認
        # --------------------------------------------------
        elif self.update_step == 20:

            try:
                current_version = self._get_current_version()
                self.update_logs.append(f"APP CURRENT : {current_version}")

                latest_app = self._fetch_latest_release_info(
                    GITHUB_APP_CONTENTS_API_URL,
                    "APP"
                )

                latest_app_version = latest_app["version"]
                self.update_logs.append(f"APP LATEST  : {latest_app_version}")

                cmp_result = self._compare_versions(
                    current_version,
                    latest_app_version
                )

                if cmp_result is None:
                    self.update_logs.append("APP VERSION COMPARE ERROR")
                    self.update_timer = time.time()
                    self.update_step = 6

                elif cmp_result < 0:
                    self.update_logs.append("LOCAL APP VERSION IS NEWER")
                    self.update_step = 30

                elif cmp_result == 0:
                    self.update_logs.append("NO APP UPDATE")
                    self.update_step = 30

                else:
                    self.latest_app = latest_app
                    self.update_logs.append("APP UPDATE AVAILABLE")
                    self.update_step = 22

            except urllib.error.HTTPError as e:
                self.update_logs.append(f"APP GITHUB HTTP ERROR : {e.code}")
                self.update_timer = time.time()
                self.update_step = 6

            except urllib.error.URLError as e:
                self.update_logs.append(f"APP GITHUB URL ERROR : {e.reason}")
                self.update_timer = time.time()
                self.update_step = 6

            except Exception as e:
                self.update_logs.append(f"APP GITHUB ERROR : {e}")
                self.update_timer = time.time()
                self.update_step = 6

            return

        # --------------------------------------------------
        # 22: app download
        # --------------------------------------------------
        elif self.update_step == 22:

            self.update_logs.append("DOWNLOAD APP ZIP...")

            ok, zip_path = self._download_zip(
                self.latest_app["download_url"],
                "app_" + self.latest_app["name"],
                self.latest_app.get("size", 0),
                label="APP"
            )

            if ok:
                self.app_zip_path = zip_path
                self.update_logs.append("DOWNLOAD APP OK")
                self.update_step = 23
            else:
                self.update_timer = time.time()
                self.update_step = 6

            return

        # --------------------------------------------------
        # 23: app extract
        # --------------------------------------------------
        elif self.update_step == 23:

            self.update_logs.append("EXTRACT APP ZIP...")

            if self._extract_zip(self.app_zip_path):
                self.update_logs.append("EXTRACT APP OK")
                self.update_step = 24
            else:
                self.update_timer = time.time()
                self.update_step = 6

            return

        # --------------------------------------------------
        # 24: app validate
        # --------------------------------------------------
        elif self.update_step == 24:

            self.update_logs.append("VALIDATE APP...")

            if self._validate_release(self.latest_app["version"]):
                self.update_logs.append("VALIDATE APP OK")
                self.update_step = 25
            else:
                self.update_timer = time.time()
                self.update_step = 6

            return

        # --------------------------------------------------
        # 25: app install
        # --------------------------------------------------
        elif self.update_step == 25:

            self.update_logs.append("INSTALL APP...")

            if self._install_release(self.latest_app["version"]):
                self.update_logs.append("INSTALL APP OK")
                self.update_step = 26
            else:
                self.update_timer = time.time()
                self.update_step = 6

            return

        # --------------------------------------------------
        # 26: current 切替
        # --------------------------------------------------
        elif self.update_step == 26:

            self.update_logs.append("SWITCH CURRENT APP...")

            if self._switch_current(self.latest_app["version"]):
                self.update_logs.append("SWITCH CURRENT APP OK")
                self.app_updated = True
                self.update_step = 27
            else:
                self.update_timer = time.time()
                self.update_step = 6

            return

        # --------------------------------------------------
        # 27: old app release 削除
        # --------------------------------------------------
        elif self.update_step == 27:

            self.update_logs.append("REMOVE OLD APP RELEASE...")

            if self._remove_old_release(self.latest_app["version"]):
                self.update_logs.append("REMOVE OLD APP RELEASE OK")
                self.update_step = 30
            else:
                self.update_timer = time.time()
                self.update_step = 6

            return

        # --------------------------------------------------
        # 30: cleanup
        # --------------------------------------------------
        elif self.update_step == 30:

            self.update_logs.append("CLEANUP...")

            if self._cleanup(self.assets_zip_path, self.app_zip_path):

                if self.assets_updated or self.app_updated:
                    self.update_logs.append("UPDATE SUCCESS")
                    self.update_logs.append("REBOOT IN 10s...")
                    self.update_timer = time.time()
                    self.update_step = 31
                else:
                    self.update_logs.append("NO UPDATE")
                    self.update_timer = time.time()
                    self.update_step = 32

            else:
                self.update_timer = time.time()
                self.update_step = 6

            return

        # --------------------------------------------------
        # 31: reboot
        # --------------------------------------------------
        elif self.update_step == 31:

            if time.time() - self.update_timer > 10:
                self._reboot_system()

            return

        # --------------------------------------------------
        # 32: no update end
        # --------------------------------------------------
        elif self.update_step == 32:

            if time.time() - self.update_timer > 3:
                disconnect_wifi()
                self.update_mode = False

            return


    # --------------------------------------------------

    def _handle_input(self):

        events = self.get_events()

        for e in events:

            if e.type != EventType.BUTTON_PRESSED:
                continue

            if e.payload == ButtonType.NAV_UP:

                self.index = (self.index - 1) % len(self.menu_items)

            elif e.payload == ButtonType.NAV_DOWN:

                self.index = (self.index + 1) % len(self.menu_items)

            elif e.payload == ButtonType.ENTER:

                if self.index == 0:

                    if not self._can_execute_update():
                        return None

                    self.update_mode = True
                    self.update_logs = []
                    self.update_step = 1
                    self.update_timer = 0

                    self.latest = None
                    self.zip_path = None

                    self.latest_app = None
                    self.latest_assets = None
                    self.app_zip_path = None
                    self.assets_zip_path = None
                    self.assets_updated = False
                    self.app_updated = False

                elif self.index == 1:

                    return SoftwareKeyboardScene(
                        self.engine,
                        title="INPUT SSID",
                        initial=self.config.get_wifi_ssid(),
                        on_done=self._set_ssid
                    )

                elif self.index == 2:

                    return SoftwareKeyboardScene(
                        self.engine,
                        title="INPUT PASSWORD",
                        initial=self.config.get_wifi_password(),
                        on_done=self._set_pass
                    )

            elif e.payload == ButtonType.CANCEL:

                from framework.scenes.service.system import SystemMenuScene
                return SystemMenuScene(self.engine)

        return None

    # --------------------------------------------------

    def _draw(self):

        r = self.r

        r.ui_clear(0.0, 0.0, 0.0)

        title_text = "ONLINE UPDATE"

        tex_t, w_t, h_t = self._get_text_texture(
            title_text,
            self.title_font,
            (255, 255, 255, 255)
        )

        r.ui_draw_texture(
            (self.W - w_t) // 2,
            int(self.H * 0.15),
            w_t,
            h_t,
            tex_t
        )

        r.ui_draw_texture(
            self.box_x,
            self.box_y,
            self.box_width,
            self.box_height,
            self._menu_box_texture
        )

        spacing = 40

        total_menu_height = (
            len(self.menu_items) * self.menu_height +
            (len(self.menu_items) - 1) * spacing
        )

        start_y = self.box_y + (self.box_height - total_menu_height) // 2

        left_x = self.box_x + 80
        right_x = self.box_x + self.box_width - 80

        for i, item in enumerate(self.menu_items):

            y = start_y + i * (self.menu_height + spacing)

            disabled = (i == 0 and not self._can_execute_update())

            row_w = self.box_width - 100
            row_h = self.menu_height + 18
            row_x = self.box_x + 50
            row_y = y - 9

            if i == self.index:
                if disabled:
                    color = (120, 120, 120, 255)
                    fill_color = (25, 25, 25, 220)
                    border_color = (120, 120, 120, 255)
                else:
                    color = (255, 255, 255, 255)
                    fill_color = (70, 0, 0, 185)
                    border_color = (255, 80, 80, 255)

                row_tex = self._get_panel_texture(
                    row_w,
                    row_h,
                    10,
                    fill_color
                )

                r.ui_draw_texture(row_x, row_y, row_w, row_h, row_tex)

                self._draw_rect_outline(
                    row_x,
                    row_y,
                    row_w,
                    row_h,
                    border_color,
                    width=3
                )

            else:
                if disabled:
                    color = (90, 90, 90, 255)
                else:
                    color = (200, 200, 200, 255)

            tex_l, w_l, h_l = self._get_text_texture(
                item,
                self.menu_font,
                color
            )

            r.ui_draw_texture(left_x, y, w_l, h_l, tex_l)

            value = ""

            if i == 1:
                value = self.config.get_wifi_ssid()

            elif i == 2:
                value = "*" * len(self.config.get_wifi_password())

            tex_v, w_v, h_v = self._get_text_texture(
                value,
                self.menu_font,
                (255, 255, 255, 255)
            )

            r.ui_draw_texture(
                right_x - w_v,
                y,
                w_v,
                h_v,
                tex_v
            )

        # --------------------------------------------------
        # update overlay
        # --------------------------------------------------

        if self.update_mode:

            overlay_w = int(self.W * 0.7)
            overlay_h = int(self.H * 0.8)

            ox = (self.W - overlay_w) // 2
            oy = (self.H - overlay_h) // 2

            img = Image.new("RGBA", (overlay_w, overlay_h), (0, 0, 0, 0))
            draw = ImageDraw.Draw(img)

            draw.rounded_rectangle(
                [0, 0, overlay_w, overlay_h],
                radius=30,
                fill=(0, 0, 0, 230)
            )

            r.ui_draw_texture(
                ox,
                oy,
                overlay_w,
                overlay_h,
                np.array(img)
            )

            # -------------------------------
            # タイトル表示（追加）
            # -------------------------------
            title = "ONLINE UPDATE"

            tex, w, h = self._get_text_texture(
                title,
                self.menu_font,
                (255, 255, 0, 255)
            )

            TITLE_MARGIN_TOP = 5

            r.ui_draw_texture(
                ox + 40,
                oy + TITLE_MARGIN_TOP,
                w,
                h,
                tex
            )

            # ログ開始位置（タイトルの下にずらす）
            y = oy + 20 + h + 20

            progress_area_h = self.menu_height + 50
            max_lines = (overlay_h - 80 - progress_area_h) // (self.log_height + 10)

            for line in self.update_logs[-max_lines:]:

                tex, w, h = self._get_text_texture(
                    line,
                    self.log_font,
                    (255, 255, 255, 255)
                )

                r.ui_draw_texture(
                    ox + 40,
                    y,
                    w,
                    h,
                    tex
                )

                y += h + 10

            # -------------------------------
            # download progress 固定表示
            # -------------------------------
            if self.progress_text:

                tex_p, w_p, h_p = self._get_text_texture(
                    self.progress_text,
                    self.menu_font,
                    (0, 255, 180, 255)
                )

                r.ui_draw_texture(
                    ox + 40,
                    oy + overlay_h - h_p - 30,
                    w_p,
                    h_p,
                    tex_p
                )                

        self.engine.overlay.draw()

        r.ui_swap()

    # --------------------------------------------------

    def run(self):

        next_scene = None

        if not self.update_mode:
            next_scene = self._handle_input()
        else:
            self._update_process()

        self._draw()

        if next_scene is not None:
            return next_scene

        return self