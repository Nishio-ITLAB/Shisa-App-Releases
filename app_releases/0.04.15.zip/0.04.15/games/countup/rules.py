# games/countup/rules.py

from framework.input_types import DartHit, DartRing


CRICKET_TARGETS = {15, 16, 17, 18, 19, 20}

CRICKET_ROUND_TARGETS = {
    1: {15},
    2: {16},
    3: {17},
    4: {18},
    5: {19},
    6: {20},
}


def get_cricket_countup_target_numbers(round_no: int) -> set[int]:
    """
    CR.COUNT-UPの現在ラウンドにおける有効ナンバーを返す。
    R7はBull専用なので空set。
    R8以降は15〜20。
    """

    if round_no in CRICKET_ROUND_TARGETS:
        return CRICKET_ROUND_TARGETS[round_no]

    if round_no == 7:
        return set()

    return CRICKET_TARGETS

def get_cricket_countup_target_text(round_no: int) -> str:
    """
    CR.COUNT-UPの現在ラウンドにおける狙い先表示テキストを返す。
    """

    if round_no == 1:
        return "Throw at 15"

    if round_no == 2:
        return "Throw at 16"

    if round_no == 3:
        return "Throw at 17"

    if round_no == 4:
        return "Throw at 18"

    if round_no == 5:
        return "Throw at 19"

    if round_no == 6:
        return "Throw at 20"

    if round_no == 7:
        return "Throw at Bull"

    return "Throw at any cricket numbers"

def score_hit(
    mode_id: str,
    hit: DartHit,
    is_fat_bull: bool = False,
    round_no: int = 1,
) -> int:
    """
    DartHitをCOUNT-UP系ゲームの得点に変換する。
    """

    if mode_id == "count_up":
        return _score_normal_countup(hit, is_fat_bull)

    if mode_id == "cr_count_up":
        return _score_cricket_countup(hit, is_fat_bull, round_no)

    raise ValueError(f"Unknown countup mode_id: {mode_id}")


def score_miss() -> int:
    """
    MISSは0点。
    1投として扱うかどうかはcontroller側で判断する。
    """
    return 0


def _score_normal_countup(hit: DartHit, is_fat_bull: bool) -> int:
    """
    通常COUNT-UP。
    全ナンバー得点対象。
    """

    if hit.ring == DartRing.OUTER_BULL:
        return 50 if is_fat_bull else 25

    if hit.ring == DartRing.INNER_BULL:
        return 50

    if hit.number is None:
        return 0

    multiplier = _ring_multiplier(hit.ring)
    return hit.number * multiplier


def _score_cricket_countup(
    hit: DartHit,
    is_fat_bull: bool,
    round_no: int,
) -> int:
    """
    CR.COUNT-UP。
    R1: 15のみ
    R2: 16のみ
    R3: 17のみ
    R4: 18のみ
    R5: 19のみ
    R6: 20のみ
    R7: Bullのみ
    R8以降: 15〜20 + Bull
    対象外は0点。ただし投数は進む。
    """

    # Bull判定
    if hit.ring == DartRing.OUTER_BULL:
        if round_no == 7 or round_no >= 8:
            return 50 if is_fat_bull else 25
        return 0

    if hit.ring == DartRing.INNER_BULL:
        if round_no == 7 or round_no >= 8:
            return 50
        return 0

    # R7はBull専用なのでナンバーは無効
    if round_no == 7:
        return 0

    target_numbers = get_cricket_countup_target_numbers(round_no)

    if hit.number not in target_numbers:
        return 0

    multiplier = _ring_multiplier(hit.ring)
    return hit.number * multiplier


def _ring_multiplier(ring: DartRing) -> int:
    if ring == DartRing.INNER_SINGLE:
        return 1

    if ring == DartRing.OUTER_SINGLE:
        return 1

    if ring == DartRing.DOUBLE:
        return 2

    if ring == DartRing.TRIPLE:
        return 3

    return 0


def build_throw_record(state, score: int, hit: DartHit | None, is_miss: bool = False) -> dict:
    """
    throw_historyへ保存する1投分の記録を作る。
    """

    if is_miss:
        number = None
        ring = "MISS"
    elif hit is not None:
        number = hit.number
        ring = hit.ring.name
    else:
        number = None
        ring = "UNKNOWN"

    return {
        "round_no": state.round_no,
        "player": state.current_player,
        "dart_no": state.dart_no,
        "mode_id": state.mode_id,
        "score": score,
        "number": number,
        "ring": ring,
    }


def evaluate_turn_awards(turn_throws: list[dict]) -> list[str]:
    """
    1ターン分のアワードを判定する。
    複数条件に該当しても、controller._play_award() と同じ優先順位で
    最上位アワードのみ返す。
    """

    if not turn_throws:
        return []

    turn_score = sum(t["score"] for t in turn_throws)

    if _is_ton80(turn_throws):
        return ["ton_80"]

    if _is_shisa_eye(turn_throws):
        return ["shisa_eye"]

    if _is_hat_trick(turn_throws):
        return ["hat_trick"]

    if _is_3_in_a_bed(turn_throws):
        return ["3_in_a_bed"]

    if turn_score >= 150:
        return ["high_ton"]

    if turn_score >= 100:
        return ["low_ton"]

    return []


def _is_ton80(turn_throws: list[dict]) -> bool:
    if len(turn_throws) < 3:
        return False

    for t in turn_throws:
        if t["score"] <= 0:
            return False

        if t["number"] != 20:
            return False

        if t["ring"] != "TRIPLE":
            return False

    return True


def _is_3_in_a_bed(turn_throws: list[dict]) -> bool:
    """
    3投すべてが同じナンバーのDOUBLEまたはTRIPLEならTrue。
    BullはHat Trick扱いとするため除外。
    CR.COUNT-UPでは15〜20のみ対象。
    """

    if len(turn_throws) < 3:
        return False

    first = turn_throws[0]

    if first["number"] is None:
        return False

    if first["ring"] not in ("DOUBLE", "TRIPLE"):
        return False

    # CR.COUNT-UPでは15〜20のみ対象
    if first["mode_id"] == "cr_count_up" and first["number"] not in CRICKET_TARGETS:
        return False

    target_number = first["number"]
    target_ring = first["ring"]

    for t in turn_throws:
        if t["number"] != target_number:
            return False

        if t["ring"] != target_ring:
            return False

        if t["score"] <= 0:
            return False

    return True


def _is_shisa_eye(turn_throws: list[dict]) -> bool:
    """
    3投すべてがINNER_BULLならTrue。
    Hat Trickの上位版。
    """

    if len(turn_throws) < 3:
        return False

    for t in turn_throws:
        if t["score"] <= 0:
            return False

        if t["ring"] != "INNER_BULL":
            return False

    return True


def _is_hat_trick(turn_throws: list[dict]) -> bool:
    """
    3投すべてがBullならTrue
    """

    if len(turn_throws) < 3:
        return False

    for t in turn_throws:
        if t["score"] <= 0:
            return False

        if t["ring"] not in ("INNER_BULL", "OUTER_BULL"):
            return False

    return True


def is_game_finished(state) -> bool:
    return state.round_no > state.rounds