# framework/scenes/game/result.py

import time
import numpy as np
from PIL import Image, ImageDraw, ImageFont

from framework.scene import Scene
from framework.input_types import EventType, ButtonType
from games.countup.result_presenter import build_result_view as build_countup_result_view
from games.cricket.result_presenter import build_result_view as build_cricket_result_view
from games.zero1.result_presenter import build_result_view as build_zero1_result_view

FONT_JP = "/opt/shisa/current/assets/fonts/NotoSansJP-Regular.ttf"
FONT_MONO = "/opt/shisa/current/assets/fonts/ChivoMono-VariableFont_wght.ttf"
FONT_MONO_ITALIC = "/opt/shisa/current/assets/fonts/ChivoMono-Italic-VariableFont_wght.ttf"

RESULT_AUTO_RETURN_SEC = 60.0

class GameResultScene(Scene):

    def __init__(self, engine, controller):
        super().__init__(engine)

        self.controller = controller

        self.r = self.engine.renderer
        self.W, self.H = self.r.get_logical_size()

        self.fonts = {}
        self.text_cache = {}
        self.panel_cache = {}

        self.view = self._build_result_view()

        self.started_at = time.time()

        self.player_colors = [
            (255, 80, 80, 255),
            (80, 180, 255, 255),
            (80, 255, 140, 255),
            (255, 220, 80, 255),
        ]

        self.engine.audio.play("game_clear")

    # --------------------------------------------------
    def _build_result_view(self):
        state = self.controller.state
        mode_id = getattr(state, "mode_id", "")

        if mode_id in ("count_up", "cr_count_up"):
            return build_countup_result_view(state)

        if mode_id in ("standard", "cut_throat"):
            return build_cricket_result_view(state)

        if mode_id in ("301", "501", "701", "901", "1101", "1501"):
            return build_zero1_result_view(state)

        return build_countup_result_view(state)

    # --------------------------------------------------
    def _is_cricket_result(self):
        mode = self.view.get("mode", "")
        return mode in ("STANDARD CRICKET", "CUT THROAT CRICKET")

    # --------------------------------------------------
    def _is_zero1_result(self):
        mode = self.view.get("mode", "")
        return mode in (
            "301 GAME",
            "501 GAME",
            "701 GAME",
            "901 GAME",
            "1101 GAME",
            "1501 GAME",
        )

    # --------------------------------------------------
    def _get_font(self, kind, size):

        key = (kind, size)

        if key in self.fonts:
            return self.fonts[key]

        if kind == "jp":
            path = FONT_JP
        elif kind == "mono_italic":
            path = FONT_MONO_ITALIC
        else:
            path = FONT_MONO

        self.fonts[key] = ImageFont.truetype(path, size)
        return self.fonts[key]

    def _get_text_texture(self, text, kind="jp", size=42, color=(255, 255, 255, 255)):

        key = (text, kind, size, color)

        if key in self.text_cache:
            return self.text_cache[key]

        font = self._get_font(kind, size)

        x0, y0, x1, y1 = font.getbbox(text)
        w = max(1, x1 - x0)
        h = max(1, y1 - y0)

        img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        draw.text((-x0, -y0), text, font=font, fill=color)

        tex = np.array(img, dtype=np.uint8)
        self.text_cache[key] = (tex, w, h)

        return tex, w, h

    def _get_panel_texture(self, w, h, radius, fill, outline=None, width=2):

        key = (w, h, radius, fill, outline, width)

        if key not in self.panel_cache:
            img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
            draw = ImageDraw.Draw(img)

            draw.rounded_rectangle(
                [0, 0, w - 1, h - 1],
                radius=radius,
                fill=fill,
                outline=outline,
                width=width
            )

            self.panel_cache[key] = np.array(img, dtype=np.uint8)

        return self.panel_cache[key]

    # --------------------------------------------------
    def _handle_input(self):

        for e in self.get_events():

            if e.type != EventType.BUTTON_PRESSED:
                continue

            if e.payload in (ButtonType.ENTER, ButtonType.CANCEL):
                from framework.scenes.menu import MenuScene
                return MenuScene(self.engine)

            return None

    # --------------------------------------------------
    def _check_auto_return(self):

        if RESULT_AUTO_RETURN_SEC <= 0:
            return None

        if time.time() - self.started_at >= RESULT_AUTO_RETURN_SEC:
            from framework.scenes.menu import MenuScene
            return MenuScene(self.engine)

        return None

    # --------------------------------------------------
    def _draw(self):

        r = self.r
        r.ui_clear(0.0, 0.0, 0.0)

        self._draw_title()
        self._draw_ranking()
        self._draw_award_table()
        self._draw_footer()

        r.ui_swap()

    # --------------------------------------------------
    def _draw_title(self):

        title = "RESULT"
        mode = self.view["mode"]

        tex, w, h = self._get_text_texture(
            title,
            "mono_italic",
            82,
            (255, 255, 255, 255)
        )

        self.r.ui_draw_texture(60, 34, w, h, tex)

        tex2, w2, h2 = self._get_text_texture(
            mode,
            "mono",
            38,
            (180, 180, 180, 255)
        )

        self.r.ui_draw_texture(68, 120, w2, h2, tex2)

    # --------------------------------------------------
    def _draw_ranking(self):

        x = 60
        y = 185
        panel_w = 820
        panel_h = 720

        tex = self._get_panel_texture(
            panel_w,
            panel_h,
            16,
            (18, 18, 18, 255),
            (70, 70, 70, 255),
            2
        )

        self.r.ui_draw_texture(x, y, panel_w, panel_h, tex)

        title_tex, title_w, title_h = self._get_text_texture(
            "RANKING",
            "mono",
            42,
            (230, 230, 230, 255)
        )

        self.r.ui_draw_texture(x + 28, y + 24, title_w, title_h, title_tex)

        row_y = y + 95
        row_h = 130
        row_gap = 155

        for result in self.view["ranking"]:

            player = result["player"]
            color = self.player_colors[player % len(self.player_colors)]

            row_tex = self._get_panel_texture(
                panel_w - 56,
                row_h,
                12,
                (28, 28, 28, 255),
                color,
                3 if result["rank"] == 1 else 2
            )

            self.r.ui_draw_texture(
                x + 28,
                row_y,
                panel_w - 56,
                row_h,
                row_tex
            )

            rank_tex, rank_w, rank_h = self._get_text_texture(
                result["rank_label"],
                "mono_italic",
                46,
                color
            )

            self.r.ui_draw_texture(
                x + 50,
                row_y + 28,
                rank_w,
                rank_h,
                rank_tex
            )

            label_tex, label_w, label_h = self._get_text_texture(
                result["label"],
                "mono",
                40,
                (255, 255, 255, 255)
            )

            self.r.ui_draw_texture(
                x + 150,
                row_y + 18,
                label_w,
                label_h,
                label_tex
            )

            score_tex, score_w, score_h = self._get_text_texture(
                str(result["total_score"]),
                "mono",
                62,
                (255, 255, 255, 255)
            )

            self.r.ui_draw_texture(
                x + panel_w - score_w - 60,
                row_y + 22,
                score_w,
                score_h,
                score_tex
            )

            if self._is_cricket_result():
                stat = (
                    f"MPR(80%) {result['mpr']:.2f}   "
                )

            elif self._is_zero1_result():
                stat = (
                    f"PPD(80%) {result['ppd']:.1f}   "
                )

            else:
                stat = (
                    f"PPD {result['ppd']:.1f}   "
                )

            stat_tex, stat_w, stat_h = self._get_text_texture(
                stat,
                "mono",
                26,
                (160, 160, 160, 255)
            )

            self.r.ui_draw_texture(
                x + 150,
                row_y + 92,
                stat_w,
                stat_h,
                stat_tex
            )

            row_y += row_gap

    # --------------------------------------------------
    def _draw_award_table(self):

        x = 920
        y = 185
        panel_w = self.W - x - 60
        panel_h = 720

        tex = self._get_panel_texture(
            panel_w,
            panel_h,
            16,
            (18, 18, 18, 255),
            (70, 70, 70, 255),
            2
        )

        self.r.ui_draw_texture(x, y, panel_w, panel_h, tex)

        title_tex, title_w, title_h = self._get_text_texture(
            "AWARDS",
            "mono",
            42,
            (230, 230, 230, 255)
        )

        self.r.ui_draw_texture(x + 28, y + 24, title_w, title_h, title_tex)

        players = self.view["players"]
        award_table = self.view.get("award_table", [])

        table_x = x + 34
        table_y = y + 95

        award_col_w = 360
        player_col_w = (panel_w - 68 - award_col_w) // max(1, players)

        # --------------------------------------------------
        # HEADER
        # --------------------------------------------------
        header_tex, header_w, header_h = self._get_text_texture(
            "AWARD",
            "mono",
            30,
            (160, 160, 160, 255)
        )

        self.r.ui_draw_texture(
            table_x,
            table_y,
            header_w,
            header_h,
            header_tex
        )

        for p in range(players):

            color = self.player_colors[p % len(self.player_colors)]

            tex, w, h = self._get_text_texture(
                f"P{p + 1}",
                "mono",
                30,
                color
            )

            cx = table_x + award_col_w + p * player_col_w

            self.r.ui_draw_texture(
                cx + (player_col_w - w) // 2,
                table_y,
                w,
                h,
                tex
            )

        # --------------------------------------------------
        # HEADER LINE
        # --------------------------------------------------
        header_line_tex = np.array(
            Image.new("RGBA", (panel_w - 68, 2), (70, 70, 70, 180)),
            dtype=np.uint8
        )

        self.r.ui_draw_texture(
            table_x,
            table_y + 38,
            panel_w - 68,
            2,
            header_line_tex
        )

        # --------------------------------------------------
        # COLUMN LINES
        # --------------------------------------------------
        row_gap = 52
        row_y = table_y + 56

        table_body_top = table_y + 38
        table_body_bottom = (
            row_y
            + len(award_table) * row_gap
        )

        vline_tex = np.array(
            Image.new(
                "RGBA",
                (2, table_body_bottom - table_body_top),
                (55, 55, 55, 160)
            ),
            dtype=np.uint8
        )

        # AWARD列とP1列の間
        self.r.ui_draw_texture(
            table_x + award_col_w,
            table_body_top,
            2,
            table_body_bottom - table_body_top,
            vline_tex
        )

        # P列間
        for p in range(1, players):

            line_x = table_x + award_col_w + p * player_col_w

            self.r.ui_draw_texture(
                line_x,
                table_body_top,
                2,
                table_body_bottom - table_body_top,
                vline_tex
            )

        # --------------------------------------------------
        # ROWS
        # --------------------------------------------------
        for row in award_table:

            label = row.get("label", "")
            counts = row.get("counts", [])

            # AWARD NAME
            tex, w, h = self._get_text_texture(
                label,
                "mono",
                28,
                (210, 210, 210, 255)
            )

            text_y = row_y + (row_gap - h) // 2 - 3

            self.r.ui_draw_texture(
                table_x,
                text_y,
                w,
                h,
                tex
            )

            # PLAYER COUNTS
            for p in range(players):

                value = 0

                if p < len(counts):
                    value = counts[p]

                color = (
                    (90, 90, 90, 255)
                    if value <= 0
                    else self.player_colors[p % len(self.player_colors)]
                )

                tex, w, h = self._get_text_texture(
                    str(value),
                    "mono",
                    34,
                    color
                )

                cx = table_x + award_col_w + p * player_col_w

                self.r.ui_draw_texture(
                    cx + (player_col_w - w) // 2,
                    row_y + (row_gap - h) // 2 - 4,
                    w,
                    h,
                    tex
                )

            # ------------------------------------------
            # 区切り線
            # 5 MARKS と TON 80 の間だけ強調
            # ------------------------------------------
            is_major_separator = (
                row.get("key") == "5_mark"
            )

            if is_major_separator:
                line_h = 2
                line_color = (55, 55, 55, 160)
            else:
                line_h = 1
                line_color = (45, 45, 45, 140)

            row_line_tex = np.array(
                Image.new(
                    "RGBA",
                    (panel_w - 68, line_h),
                    line_color
                ),
                dtype=np.uint8
            )

            self.r.ui_draw_texture(
                table_x,
                row_y + row_gap - 6,
                panel_w - 68,
                line_h,
                row_line_tex
            )

            row_y += row_gap

    # --------------------------------------------------
    def _draw_footer(self):

        text = "PRESS ENTER / CANCEL"

        now = time.time()

        # 0.5秒周期で点滅
        blink = int(now * 2) % 2 == 0

        if not blink:
            return

        tex, w, h = self._get_text_texture(
            text,
            "mono",
            32,
            (180, 180, 180, 255)
        )

        self.r.ui_draw_texture(
            (self.W - w) // 2,
            self.H - 70,
            w,
            h,
            tex
        )

    # --------------------------------------------------
    def run(self):

        next_scene = self._handle_input()

        if next_scene is not None:
            return next_scene

        next_scene = self._check_auto_return()

        if next_scene is not None:
            return next_scene

        self._draw()

        return self