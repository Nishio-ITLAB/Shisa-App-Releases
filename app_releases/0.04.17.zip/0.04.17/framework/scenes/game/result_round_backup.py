# framework/scenes/game/result.py

import time
import numpy as np
from PIL import Image, ImageDraw, ImageFont

from framework.scene import Scene
from framework.input_types import EventType, ButtonType
from games.countup.result_presenter import build_result_view as build_countup_result_view
from games.cricket.result_presenter import build_result_view as build_cricket_result_view
from games.zero1.result_presenter import build_result_view as build_zero1_result_view

FONT_JP = "/opt/shisa/current/assets/fonts/NotoSansJP-Regular.ttf"
FONT_MONO = "/opt/shisa/current/assets/fonts/ChivoMono-VariableFont_wght.ttf"
FONT_MONO_ITALIC = "/opt/shisa/current/assets/fonts/ChivoMono-Italic-VariableFont_wght.ttf"
FONT_UI = "/opt/shisa/current/system_assets/fonts/NotoSansMono-Regular.ttf"

class GameResultScene(Scene):

    def __init__(self, engine, controller):
        super().__init__(engine)

        self.controller = controller

        self.r = self.engine.renderer
        self.W, self.H = self.r.get_logical_size()

        self.fonts = {}
        self.text_cache = {}
        self.panel_cache = {}

        self.view = self._build_result_view()

        self.player_colors = [
            (255, 80, 80, 255),
            (80, 180, 255, 255),
            (80, 255, 140, 255),
            (255, 220, 80, 255),
        ]

        self.engine.audio.play("game_clear")

        self.round_scroll_offset = 0
        self.round_visible_rows = 10

    # --------------------------------------------------
    def _build_result_view(self):
        state = self.controller.state
        mode_id = getattr(state, "mode_id", "")

        if mode_id in ("count_up", "cr_count_up"):
            return build_countup_result_view(state)

        if mode_id in ("standard", "cut_throat"):
            return build_cricket_result_view(state)

        if mode_id in ("301", "501", "701", "901", "1101", "1501"):
            return build_zero1_result_view(state)

        return build_countup_result_view(state)

    # --------------------------------------------------
    def _is_cricket_result(self):
        mode = self.view.get("mode", "")
        return mode in ("STANDARD CRICKET", "CUT THROAT CRICKET")

    # --------------------------------------------------
    def _is_zero1_result(self):
        mode = self.view.get("mode", "")
        return mode in (
            "301 GAME",
            "501 GAME",
            "701 GAME",
            "901 GAME",
            "1101 GAME",
            "1501 GAME",
        )

    def _is_after_zero1_rating_fixed_round(self, round_no, player=None):

        fixed_round = self._get_zero1_rating_fixed_round()

        if fixed_round is None:
            return False

        return round_no > fixed_round

    # --------------------------------------------------
    def _get_font(self, kind, size):

        key = (kind, size)

        if key in self.fonts:
            return self.fonts[key]

        if kind == "jp":
            path = FONT_JP
        elif kind == "mono_italic":
            path = FONT_MONO_ITALIC
        elif kind == "ui":
            path = FONT_UI
        else:
            path = FONT_MONO

        self.fonts[key] = ImageFont.truetype(path, size)
        return self.fonts[key]

    def _get_text_texture(self, text, kind="jp", size=42, color=(255, 255, 255, 255)):

        key = (text, kind, size, color)

        if key in self.text_cache:
            return self.text_cache[key]

        font = self._get_font(kind, size)

        x0, y0, x1, y1 = font.getbbox(text)
        w = max(1, x1 - x0)
        h = max(1, y1 - y0)

        img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        draw.text((-x0, -y0), text, font=font, fill=color)

        tex = np.array(img, dtype=np.uint8)
        self.text_cache[key] = (tex, w, h)

        return tex, w, h

    def _get_panel_texture(self, w, h, radius, fill, outline=None, width=2):

        key = (w, h, radius, fill, outline, width)

        if key not in self.panel_cache:
            img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
            draw = ImageDraw.Draw(img)

            draw.rounded_rectangle(
                [0, 0, w - 1, h - 1],
                radius=radius,
                fill=fill,
                outline=outline,
                width=width
            )

            self.panel_cache[key] = np.array(img, dtype=np.uint8)

        return self.panel_cache[key]

    # --------------------------------------------------
    def _handle_input(self):

        for e in self.get_events():

            if e.type != EventType.BUTTON_PRESSED:
                continue

            if e.payload == ButtonType.NAV_UP:
                self.round_scroll_offset = max(0, self.round_scroll_offset - 1)
                return None

            if e.payload == ButtonType.NAV_DOWN:
                max_offset = self._get_round_scroll_max()
                self.round_scroll_offset = min(max_offset, self.round_scroll_offset + 1)
                return None

            if e.payload in (ButtonType.ENTER, ButtonType.CANCEL):
                from framework.scenes.menu import MenuScene
                return MenuScene(self.engine)

            return None

    # --------------------------------------------------
    def _get_visible_round_table(self):
        table = self.view.get("round_table", [])

        # 実際にプレイ済みのラウンドだけ表示
        played = []

        for row in table:
            if self._is_cricket_result():
                if any(any(mark != "" for mark in marks) for marks in row.get("marks", [])):
                    played.append(row)
            else:
                if any(score != 0 for score in row.get("scores", [])):
                    played.append(row)

        # 全ラウンド0点でも、現在ラウンドまでは表示したい
        state = self.controller.state
        current_round = getattr(state, "round_no", 1)

        if not played:
            played = [
                row for row in table
                if row.get("round_no", 0) <= current_round
            ]
        else:
            max_played_round = max(row["round_no"] for row in played)
            display_until = max(max_played_round, min(current_round, len(table)))
            played = [
                row for row in table
                if row.get("round_no", 0) <= display_until
            ]

        return played

    def _get_round_scroll_max(self):
        rows = self._get_visible_round_table()
        return max(0, len(rows) - self.round_visible_rows)

    # --------------------------------------------------
    def _draw(self):

        r = self.r
        r.ui_clear(0.0, 0.0, 0.0)

        self._draw_title()
        self._draw_ranking()
        self._draw_round_table()
        self._draw_footer()

        r.ui_swap()

    # --------------------------------------------------
    def _draw_title(self):

        title = "RESULT"
        mode = self.view["mode"]

        tex, w, h = self._get_text_texture(
            title,
            "mono_italic",
            82,
            (255, 255, 255, 255)
        )

        self.r.ui_draw_texture(60, 34, w, h, tex)

        tex2, w2, h2 = self._get_text_texture(
            mode,
            "mono",
            38,
            (180, 180, 180, 255)
        )

        self.r.ui_draw_texture(68, 120, w2, h2, tex2)

    # --------------------------------------------------
    def _draw_ranking(self):

        x = 60
        y = 185
        panel_w = 820
        panel_h = 720

        tex = self._get_panel_texture(
            panel_w,
            panel_h,
            16,
            (18, 18, 18, 255),
            (70, 70, 70, 255),
            2
        )

        self.r.ui_draw_texture(x, y, panel_w, panel_h, tex)

        title_tex, title_w, title_h = self._get_text_texture(
            "RANKING",
            "mono",
            42,
            (230, 230, 230, 255)
        )

        self.r.ui_draw_texture(x + 28, y + 24, title_w, title_h, title_tex)

        row_y = y + 95
        row_h = 130
        row_gap = 155

        for result in self.view["ranking"]:

            player = result["player"]
            color = self.player_colors[player % len(self.player_colors)]

            row_tex = self._get_panel_texture(
                panel_w - 56,
                row_h,
                12,
                (28, 28, 28, 255),
                color,
                3 if result["rank"] == 1 else 2
            )

            self.r.ui_draw_texture(
                x + 28,
                row_y,
                panel_w - 56,
                row_h,
                row_tex
            )

            rank_tex, rank_w, rank_h = self._get_text_texture(
                result["rank_label"],
                "mono_italic",
                46,
                color
            )

            self.r.ui_draw_texture(
                x + 50,
                row_y + 28,
                rank_w,
                rank_h,
                rank_tex
            )

            label_tex, label_w, label_h = self._get_text_texture(
                result["label"],
                "mono",
                40,
                (255, 255, 255, 255)
            )

            self.r.ui_draw_texture(
                x + 150,
                row_y + 18,
                label_w,
                label_h,
                label_tex
            )

            score_tex, score_w, score_h = self._get_text_texture(
                str(result["total_score"]),
                "mono",
                62,
                (255, 255, 255, 255)
            )

            self.r.ui_draw_texture(
                x + panel_w - score_w - 60,
                row_y + 22,
                score_w,
                score_h,
                score_tex
            )

            if self._is_cricket_result():
                stat = (
                    f"MPR(80%) {result['mpr']:.2f}   "
                )

            elif self._is_zero1_result():
                stat = (
                    f"PPD(80%) {result['ppd']:.1f}   "
                )

            else:
                stat = (
                    f"PPD {result['ppd']:.1f}   "
                )

            stat_tex, stat_w, stat_h = self._get_text_texture(
                stat,
                "mono",
                26,
                (160, 160, 160, 255)
            )

            self.r.ui_draw_texture(
                x + 150,
                row_y + 92,
                stat_w,
                stat_h,
                stat_tex
            )

            row_y += row_gap

    # --------------------------------------------------
    def _draw_round_table(self):

        x = 920
        y = 185
        panel_w = self.W - x - 60
        panel_h = 720

        tex = self._get_panel_texture(
            panel_w,
            panel_h,
            16,
            (18, 18, 18, 255),
            (70, 70, 70, 255),
            2
        )

        self.r.ui_draw_texture(x, y, panel_w, panel_h, tex)

        round_title = "ROUND MARKS" if self._is_cricket_result() else "ROUND SCORES"

        title_tex, title_w, title_h = self._get_text_texture(
            round_title,
            "mono",
            42,
            (230, 230, 230, 255)
        )

        self.r.ui_draw_texture(x + 28, y + 24, title_w, title_h, title_tex)

        players = self.view["players"]

        table_x = x + 34
        table_y = y + 95

        round_col_w = 120
        player_col_w = (panel_w - 68 - round_col_w) // max(1, players)

        header_tex, header_w, header_h = self._get_text_texture(
            "ROUND",
            "mono",
            30,
            (160, 160, 160, 255)
        )

        self.r.ui_draw_texture(table_x, table_y, header_w, header_h, header_tex)

        for p in range(players):
            color = self.player_colors[p % len(self.player_colors)]
            text = f"P{p + 1}"

            tex, w, h = self._get_text_texture(
                text,
                "mono",
                30,
                color
            )

            cx = table_x + round_col_w + p * player_col_w
            self.r.ui_draw_texture(
                cx + (player_col_w - w) // 2,
                table_y,
                w,
                h,
                tex
            )

        # ヘッダー下の区切り線
        header_line_tex = np.array(
            Image.new("RGBA", (panel_w - 68, 2), (70, 70, 70, 180)),
            dtype=np.uint8
        )
        self.r.ui_draw_texture(
            table_x,
            table_y + 38,
            panel_w - 68,
            2,
            header_line_tex
        )

        row_y = table_y + 48
        row_gap = 45

        round_rows = self._get_visible_round_table()
        max_offset = self._get_round_scroll_max()

        if self.round_scroll_offset > max_offset:
            self.round_scroll_offset = max_offset

        visible_rows = round_rows[
            self.round_scroll_offset:
            self.round_scroll_offset + self.round_visible_rows
        ]

        # プレイヤー列の縦区切り線
        table_body_top = table_y + 38
        table_body_bottom = table_y + 48 + self.round_visible_rows * row_gap

        vline_tex = np.array(
            Image.new("RGBA", (2, table_body_bottom - table_body_top), (55, 55, 55, 160)),
            dtype=np.uint8
        )

        # ROUND列とP1列の間
        self.r.ui_draw_texture(
            table_x + round_col_w,
            table_body_top,
            2,
            table_body_bottom - table_body_top,
            vline_tex
        )

        # P1/P2/P3/P4間
        for p in range(1, players):
            line_x = table_x + round_col_w + p * player_col_w
            self.r.ui_draw_texture(
                line_x,
                table_body_top,
                2,
                table_body_bottom - table_body_top,
                vline_tex
            )

        for row in visible_rows:

            round_text = f"R{row['round_no']:02d}"

            if self._is_cricket_result():
                scores = row["marks"]

            else:
                scores = row["scores"]

            round_color = (210, 210, 210, 255)

            tex, w, h = self._get_text_texture(
                round_text,
                "mono",
                30,
                round_color
            )

            text_y = row_y + (row_gap - h) // 2 - 4

            self.r.ui_draw_texture(table_x, text_y, w, h, tex)

            for p, value in enumerate(scores):

                is_incomplete_player_round = self._is_incomplete_player_round(
                    row["round_no"],
                    p
                )

                is_after_rating_fixed = self._is_after_zero1_rating_fixed_round(
                    row["round_no"],
                    p
                )

                is_gray = (
                    is_incomplete_player_round
                    or is_after_rating_fixed
                )

                cx = table_x + round_col_w + p * player_col_w

                if self._is_cricket_result():
                    mark_color = (
                        (90, 90, 90, 255)
                        if is_gray
                        else self.player_colors[p % len(self.player_colors)]
                    )

                    self._draw_cricket_round_marks(
                        value,
                        cx,
                        row_y,
                        player_col_w,
                        mark_color
                    )
                else:

                    score_color = (
                        (90, 90, 90, 255)
                        if is_gray
                        else self.player_colors[p % len(self.player_colors)]
                    )

                    tex, w, h = self._get_text_texture(
                        str(value),
                        "mono",
                        32,
                        score_color
                    )

                    text_y = row_y + (row_gap - h) // 2 - 4

                    self.r.ui_draw_texture(
                        cx + (player_col_w - w) // 2,
                        text_y,
                        w,
                        h,
                        tex
                    )

            # ラウンド行の横区切り線
            row_line_tex = np.array(
                Image.new("RGBA", (panel_w - 68, 1), (45, 45, 45, 140)),
                dtype=np.uint8
            )

            self.r.ui_draw_texture(
                table_x,
                row_y + row_gap - 6,
                panel_w - 68,
                1,
                row_line_tex
            )
       
            row_y += row_gap

        # TOTAL行
        row_y += 28

        line_tex = np.array(
            Image.new("RGBA", (panel_w - 68, 3), (90, 90, 90, 255)),
            dtype=np.uint8
        )
        self.r.ui_draw_texture(table_x, row_y - 16, panel_w - 68, 3, line_tex)

        tex, w, h = self._get_text_texture(
            "TOTAL",
            "mono",
            34,
            (210, 210, 210, 255)
        )

        self.r.ui_draw_texture(table_x, row_y, w, h, tex)

        total_values = (
            [r.get("total_marks", 0) for r in self.view["players_detail"]]
            if self._is_cricket_result()
            else self.view["totals"]
        )

        for p, total in enumerate(total_values):
            tex, w, h = self._get_text_texture(
                str(total),
                "mono",
                38,
                self.player_colors[p % len(self.player_colors)]
            )

            cx = table_x + round_col_w + p * player_col_w
            self.r.ui_draw_texture(
                cx + (player_col_w - w) // 2,
                row_y,
                w,
                h,
                tex
            )

        if self.round_scroll_offset > 0:
            tex_u, w_u, h_u = self._get_text_texture(
                "▲",
                "ui",
                34,
                (180, 180, 180, 255)
            )

            self.r.ui_draw_texture(
                x + panel_w - w_u - 28,
                y + 26,
                w_u,
                h_u,
                tex_u
            )

        if self.round_scroll_offset < max_offset:
            tex_d, w_d, h_d = self._get_text_texture(
                "▼",
                "ui",
                34,
                (180, 180, 180, 255)
            )

            self.r.ui_draw_texture(
                x + panel_w - w_d - 28,
                y + panel_h - h_d - 24,
                w_d,
                h_d,
                tex_d
            )

    # --------------------------------------------------
    def _count_player_round_throws(self, round_no, player):

        state = self.controller.state

        count = 0

        for t in getattr(state, "throw_history", []):
            if (
                t.get("round_no") == round_no
                and t.get("player") == player
            ):
                count += 1

        return count


    def _is_incomplete_player_round(self, round_no, player):

        # そのラウンド自体がまだ始まっていないなら通常扱い
        if not self._is_round_started(round_no):
            return False

        # BUSTしているラウンドは、その時点でターン終了なので完了扱い
        if self._has_player_bust_in_round(round_no, player):
            return False

        throw_count = self._count_player_round_throws(round_no, player)

        # ラウンドが始まっているなら、
        # そのプレイヤーが3投完了していない場合はグレーダウン
        return throw_count < 3

    def _has_player_bust_in_round(self, round_no, player):

        state = self.controller.state

        for t in getattr(state, "throw_history", []):
            if (
                t.get("round_no") == round_no
                and t.get("player") == player
                and t.get("bust")
            ):
                return True

        return False

    def _is_round_started(self, round_no):

        state = self.controller.state

        for t in getattr(state, "throw_history", []):
            if t.get("round_no") == round_no:
                return True

        return False

    # --------------------------------------------------
    def _draw_cricket_round_marks(self, marks, x, y, w, color):
        """
        marks: ["/", "X", "O", ""] の3要素
        MISS/未投は "" として表示しない
        """

        mark_size = 26
        gap = 10

        total_w = mark_size * 3 + gap * 2
        start_x = x + (w - total_w) // 2

        for i, mark in enumerate(marks[:3]):

            if not mark:
                continue

            mx = start_x + i * (mark_size + gap)
            my = y + 4

            tex = self._get_cricket_mark_texture(
                mark,
                mark_size,
                color
            )

            self.r.ui_draw_texture(mx, my, mark_size, mark_size, tex)

    def _get_zero1_rating_fixed_round(self):

        if not self._is_zero1_result():
            return None

        state = self.controller.state

        threshold_map = {
            301: 60,
            501: 100,
            701: 140,
            901: 180,
            1101: 220,
            1501: 300,
        }

        start_score = int(getattr(state, "start_score", 0))
        threshold = threshold_map.get(start_score)

        if threshold is None:
            return None

        fixed_round = None

        for t in getattr(state, "throw_history", []):

            if t.get("bust"):
                continue

            remaining_after = t.get("remaining_after")

            if remaining_after is None:
                continue

            if int(remaining_after) <= threshold:
                r = t.get("round_no")

                if fixed_round is None or r < fixed_round:
                    fixed_round = r

        return fixed_round

    def _get_cricket_mark_texture(self, mark, size, color):
        key = ("result_cricket_mark", mark, size, color)

        if key in self.panel_cache:
            return self.panel_cache[key]

        img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        line_w = max(3, size // 8)
        pad = size // 6

        if mark == "/":
            draw.line(
                [
                    (size - pad, pad),
                    (pad, size - pad),
                ],
                fill=color,
                width=line_w
            )

        elif mark == "X":
            draw.line(
                [
                    (pad, pad),
                    (size - pad, size - pad),
                ],
                fill=color,
                width=line_w
            )
            draw.line(
                [
                    (size - pad, pad),
                    (pad, size - pad),
                ],
                fill=color,
                width=line_w
            )

        elif mark == "O":
            circle_pad = size // 8
            draw.ellipse(
                [
                    circle_pad,
                    circle_pad,
                    size - circle_pad,
                    size - circle_pad,
                ],
                outline=color,
                width=line_w
            )
            draw.line(
                [
                    (pad, pad),
                    (size - pad, size - pad),
                ],
                fill=color,
                width=line_w
            )
            draw.line(
                [
                    (size - pad, pad),
                    (pad, size - pad),
                ],
                fill=color,
                width=line_w
            )

        tex = np.array(img, dtype=np.uint8)
        self.panel_cache[key] = tex

        return tex

    # --------------------------------------------------
    def _draw_footer(self):

        text = "PRESS ENTER / CANCEL"

        now = time.time()

        # 0.5秒周期で点滅
        blink = int(now * 2) % 2 == 0

        if not blink:
            return

        tex, w, h = self._get_text_texture(
            text,
            "mono",
            32,
            (180, 180, 180, 255)
        )

        self.r.ui_draw_texture(
            (self.W - w) // 2,
            self.H - 70,
            w,
            h,
            tex
        )

    # --------------------------------------------------
    def run(self):

        next_scene = self._handle_input()

        if next_scene is not None:
            return next_scene

        self._draw()

        return self