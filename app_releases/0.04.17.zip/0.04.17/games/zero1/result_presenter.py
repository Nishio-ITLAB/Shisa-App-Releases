# games/zero1/result_presenter.py


ZERO1_AWARD_ROWS = [
    ("ton_80", "TON 80"),
    ("shisa_eye", "SHISA EYE"),
    ("hat_trick", "HAT TRICK"),
    ("3_in_a_bed", "3 IN A BED"),
    ("high_ton", "HIGH TON"),
    ("low_ton", "LOW TON"),
    ("bust", "BUST"),
]


def build_result_view(state):
    """
    01用リザルト表示データを構築する。
    描画はしない。
    """

    players = state.players
    rounds = state.rounds

    player_results = []

    for player_index in range(players):

        remaining = state.scores[player_index]
        total_score = state.total_scores[player_index]

        round_scores = [
            state.round_scores[round_index][player_index]
            for round_index in range(rounds)
        ]

        high_round = max(round_scores) if round_scores else 0

        player_throws = [
            t for t in state.throw_history
            if t.get("player") == player_index
        ]

        prd_throws = _get_prd_80_throws(state, player_throws)

        dart_count = len(player_throws)

        prd_rounds = sorted({
            int(t.get("round_no"))
            for t in prd_throws
            if t.get("round_no") is not None
        })

        prd_dart_count = len(prd_rounds) * 3

        miss_count = sum(
            1 for t in player_throws
            if t.get("is_miss") or t.get("ring") == "MISS"
        )

        bust_count = sum(
            1 for t in player_throws
            if t.get("bust")
        )

        finish_count = sum(
            1 for t in player_throws
            if t.get("finish")
        )

        prd_score = sum(
            round_scores[round_no - 1]
            for round_no in prd_rounds
            if 0 <= round_no - 1 < len(round_scores)
        )

        ppd = 0.0
        if prd_dart_count > 0:
            ppd = prd_score / prd_dart_count

        player_results.append({
            "player": player_index,
            "label": f"PLAYER {player_index + 1}",

            # 共通ResultScene互換。
            # 01では順位・表示用スコアとして「残り点」を入れる。
            "total_score": remaining,

            # 01固有値
            "remaining": remaining,
            "scored": total_score,

            "round_scores": round_scores,
            "high_round": high_round,
            "dart_count": dart_count,
            "ppd": ppd,
            "prd_score": prd_score,
            "prd_dart_count": prd_dart_count,
            "miss_count": miss_count,
            "bust_count": bust_count,
            "finish_count": finish_count,
            "finished": state.winner == player_index,
        })

    ranking = sorted(
        player_results,
        key=lambda x: (
            0 if x["finished"] else 1,
            x["remaining"],
            -x["scored"],
        )
    )

    _apply_competition_ranking(ranking)

    round_table = []

    for round_index in range(rounds):
        row = {
            "round_no": round_index + 1,
            "scores": [
                state.round_scores[round_index][player_index]
                for player_index in range(players)
            ]
        }
        round_table.append(row)

    award_table = _build_award_table(state)

    return {
        "mode": _format_mode_name(state.mode_id),
        "players": players,
        "rounds": rounds,
        "start_score": state.start_score,
        "out_option": state.out_option,
        "winner": state.winner,
        "winner_label": _format_winner(state),
        "result_reason": state.result_reason,
        "ranking": ranking,
        "players_detail": player_results,

        # 旧リザルト表示用。backup復帰や比較用に残す
        "round_table": round_table,

        # 新リザルト表示用
        "award_table": award_table,

        # 既存ResultScene互換。
        # 01では totals は「残り点」として扱う。
        "totals": state.scores.copy(),

        # 01固有表示用。
        "remaining": state.scores.copy(),
        "total_scores": state.total_scores.copy(),
    }


def _build_award_table(state):
    """
    リザルト右側表示用のアワード集計テーブルを作る。
    award_table[row]["counts"][player_index] = count
    """

    players = state.players
    award_counts = getattr(state, "award_counts", None)

    if award_counts is None:
        award_counts = [
            {}
            for _ in range(players)
        ]

    table = []

    for key, label in ZERO1_AWARD_ROWS:
        counts = []

        for player_index in range(players):
            if player_index < len(award_counts):
                counts.append(int(award_counts[player_index].get(key, 0)))
            else:
                counts.append(0)

        table.append({
            "key": key,
            "label": label,
            "counts": counts,
        })

    return table


def _apply_competition_ranking(rows):
    """
    同点は competition ranking 方式。
    例: 100, 100, 80 => 1st, 1st, 3rd

    01では順位キーを
    - finish済み優先
    - 残り点が少ない方
    - 削った点が多い方
    とする。
    """

    previous_key = None
    previous_rank = 0

    for index, row in enumerate(rows):
        rank = index + 1

        key = (
            row["finished"],
            row["remaining"],
        )

        if previous_key is not None and key == previous_key:
            row["rank"] = previous_rank
        else:
            row["rank"] = rank
            previous_rank = rank

        row["rank_label"] = _format_rank(row["rank"])
        previous_key = key


def _format_winner(state):
    if state.winner is None:
        return None

    return f"PLAYER {state.winner + 1}"


def _format_rank(rank):

    if rank == 1:
        return "1st"

    if rank == 2:
        return "2nd"

    if rank == 3:
        return "3rd"

    return f"{rank}th"


def _format_mode_name(mode_id):

    if mode_id == "301":
        return "301 GAME"

    if mode_id == "501":
        return "501 GAME"

    if mode_id == "701":
        return "701 GAME"

    if mode_id == "901":
        return "901 GAME"

    if mode_id == "1101":
        return "1101 GAME"

    if mode_id == "1501":
        return "1501 GAME"

    return str(mode_id).upper()


def _get_prd_80_throws(state, player_throws):
    """
    01用 PPD(80%) 対象投球。
    ゲーム内の誰かが最初にrating_fixedへ到達したラウンドまでを
    全プレイヤー共通の対象にする。
    """

    fixed_round = _get_global_rating_fixed_round(state)

    if fixed_round is None:
        return player_throws

    return [
        t for t in player_throws
        if t.get("round_no") <= fixed_round
    ]


def _get_global_rating_fixed_round(state):

    fixed_round = None

    for t in state.throw_history:

        if t.get("bust"):
            continue

        if not t.get("rating_fixed"):
            continue

        round_no = t.get("round_no")

        if round_no is None:
            continue

        if fixed_round is None or round_no < fixed_round:
            fixed_round = round_no

    return fixed_round