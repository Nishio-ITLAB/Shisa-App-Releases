# games/zero1/state.py

class Zero1State:

    def __init__(
        self,
        mode_id,
        players,
        rounds,
        undo_limit,
        start_score,
        out_option,
    ):
        self.mode_id = mode_id
        self.players = players
        self.rounds = rounds
        self.undo_limit = undo_limit

        # 01固有設定
        self.start_score = int(start_score)
        self.out_option = str(out_option)

        # 各プレイヤーの残り点
        self.scores = [
            self.start_score
            for _ in range(players)
        ]

        # 各プレイヤーの削った合計点
        # result表示互換用
        self.total_scores = [
            0
            for _ in range(players)
        ]

        # 各ラウンドのプレイヤー別削減点
        # round_scores[round_index][player_index]
        self.round_scores = [
            [0 for _ in range(players)]
            for _ in range(rounds)
        ]

        # ターン開始時点の残り点
        # Bust時にここへ戻す
        self.turn_start_scores = [
            self.start_score
            for _ in range(players)
        ]

        # ターン開始時点のラウンド削減点
        # Bust時にround_scoresをここへ戻す
        self.turn_start_round_scores = [
            0
            for _ in range(players)
        ]

        # 各投の履歴
        self.throw_history = []

        # 各プレイヤーのアワード取得数
        # award_counts[player_index][award_key] = count
        self.award_counts = [
            {
                "ton_80": 0,
                "high_ton": 0,
                "low_ton": 0,
                "hat_trick": 0,
                "shisa_eye": 0,
                "3_in_a_bed": 0,

                # 01固有：BUST回数
                # 表示するかどうかはresult側で判断する
                "bust": 0,
            }
            for _ in range(players)
        ]

        self.current_player = 0
        self.round_no = 1
        self.dart_no = 1

        self.finished = False

        # 勝敗情報
        self.winner = None
        self.result_reason = None

        # Bust表示・演出用
        self.bust_pending = False
        self.bust_at = 0.0

        # 次投までのウェイト
        self.waiting_for_throw_collect = False
        self.throw_collect_ready_at = 0.0
        self.pending_next_player = False
        self.throw_collect_message = None
        self.start_sequence_active = True
        self.start_ready_at = 0.0
        self.finish_pending = False
        self.finish_at = 0.0
        self.throw_collect_blink_immediate = False
        self.pending_awards = []
        self.pending_award_ready_at = 0.0
        self.pending_award_active = False

        # Undo用
        self.last_snapshot = None
        self.undo_used = 0

        # 一時オプション
        self.count_miss_as_throw = True

        # カットイン表示
        self.cutin_active = False
        self.cutin_start_time = 0.0

        # ポーズモード
        self.pause_mode = False
        self.pause_index = 0
        self.pause_confirm_mode = False
        self.pause_confirm_target = None

        # 長押し警告表示用
        self.stuck_dart_message = None
        self.stuck_dart_until = 0.0

        # 入力ロック
        self.input_locked_until = 0.0

        # 今再生中の演出（デバッグ/拡張用）
        self.current_award = None
        self.pending_bust_restore = None