# games/countup/controller.py

import time

from framework.input_types import EventType, ButtonType, DartHit

from .presenter import build_debug_view, build_debug_lines
from . import rules


AWARD_PRE_DELAY_SEC = 0.5
AWARD_INPUT_LOCK_SEC = 5.5
PLAYER_CHANGE_LOCK_SEC = 0.5
AWARD_PLAYER_CHANGE_LOCK_SEC = 0.5
THROW_COLLECT_NOTICE_DELAY_SEC = 0.5

class CountupController:

    def __init__(self, engine, state):
        self.engine = engine
        self.state = state

        now = time.time()
        
        self.state.throw_collect_confirmed = False
        self.state.start_sequence_active = True
        self.state.start_ready_at = now + THROW_COLLECT_NOTICE_DELAY_SEC

    # --------------------------------------------------
    # Debug / Presenter
    # --------------------------------------------------
    def get_debug_view(self):
        return build_debug_view(self.state)

    def get_debug_lines(self):
        return build_debug_lines(self.state)

    # --------------------------------------------------
    # Input
    # --------------------------------------------------
    def update(self):

        if self.state.pending_award_active:
            if time.time() >= self.state.pending_award_ready_at:
                self.state.pending_award_active = False

                award_played = self._play_award(self.state.pending_awards)
                self.state.pending_awards = []

                self._start_throw_collect_wait(award_played)

            return

        # アワード中などにENTER済みなら、ready時刻後に自動確定
        if self.state.waiting_for_throw_collect:
            if (
                self.state.throw_collect_confirmed
                and time.time() >= self.state.throw_collect_ready_at
            ):
                self._confirm_throw_collect()
            return

        # ゲーム終了遅延処理
        if self.state.finish_pending:
            if time.time() >= self.state.finish_at:
                self.state.finish_pending = False
                self.state.finished = True
            return

        if not self.state.start_sequence_active:
            return

        if time.time() < self.state.start_ready_at:
            return

        self.state.start_sequence_active = False
        self.state.start_ready_at = 0.0

        self.engine.audio.play("player_change")
        self._start_player_change_cutin()
        self._lock_player_change()

    def handle_event(self, event):

        if self.state.start_sequence_active:
            return

        if self.state.waiting_for_throw_collect:

            if event.type == EventType.BUTTON_PRESSED and event.payload == ButtonType.ENTER:
                self.state.throw_collect_confirmed = True

            if time.time() < self.state.throw_collect_ready_at:
                return

            if self.state.throw_collect_confirmed:
                self._confirm_throw_collect()
                return

            return

        if time.time() < self.state.input_locked_until:
            return

        if event.type == EventType.DART_LONG_PRESS:
            self._handle_dart_long_press(event.payload)
            return

        if event.type == EventType.DART_LONG_PRESS_RELEASED:
            return

        if event.type == EventType.DART_HIT:

            if self.state.waiting_for_throw_collect:
                return

            if self.state.dart_no > 3:
                return

            self._apply_dart_hit(event.payload)
            return

        if event.type == EventType.MISS:

            if self.state.waiting_for_throw_collect:
                return

            if self.state.dart_no > 3:
                return

            self._apply_miss()
            return

        if event.type != EventType.BUTTON_PRESSED:
            return

        if event.payload == ButtonType.ENTER:

            # 3投完了後は、回収待ちに入る前でもSKIP扱いしない
            if self.state.dart_no > 3:
                return

            self._apply_skip()

    # --------------------------------------------------
    # Stuck dart warning
    # --------------------------------------------------
    def _handle_dart_long_press(self, payload):

        if isinstance(payload, DartHit):
            message = self._format_dart_hit_message(payload)
        else:
            message = "ダーツが刺さったままです\n盤面から取り外してください"

        self.state.stuck_dart_message = message
        self.state.stuck_dart_until = time.time() + 1.1

    def _clear_stuck_dart_warning(self):
        self.state.stuck_dart_message = None
        self.state.stuck_dart_until = 0.0

    def _format_dart_hit_message(self, hit):

        ring_name = hit.ring.name.replace("_", " ")

        if hit.number is None:
            line1 = f"{ring_name} にダーツが刺さったままです"
        else:
            line1 = f"{ring_name} {hit.number} にダーツが刺さったままです"

        line2 = "盤面から取り外してください"

        return f"{line1}\n{line2}"

    # --------------------------------------------------
    # Throw handling
    # --------------------------------------------------
    def _apply_dart_hit(self, hit):

        if not isinstance(hit, DartHit):
            return

        score = rules.score_hit(
            self.state.mode_id,
            hit,
            self.state.is_fat_bull,
            self.state.round_no
        )

        self._play_hit_sound(hit, score)

        self._apply_score(
            score=score,
            hit=hit,
            is_miss=False
        )

    def _apply_miss(self):

        if not self.state.count_miss_as_throw:
            self.engine.audio.play("miss")
            return

        score = rules.score_miss()

        self._apply_score(
            score=score,
            hit=None,
            is_miss=True
        )

    def _apply_skip(self):

        score = rules.score_miss()

        self._apply_score(
            score=score,
            hit=None,
            is_miss=False,
            is_skip=True
        )

    def _apply_score(self, score, hit=None, is_miss=False, is_skip=False):

        if self.state.finished:
            return

        if self.state.round_no > self.state.rounds:
            self.state.finished = True
            return

        if score == 0:
            self.engine.audio.play("miss")

        self._save_snapshot()

        player_index = self.state.current_player
        round_index = self.state.round_no - 1

        # 合計点
        self.state.scores[player_index] += score

        # ラウンド別得点
        self.state.round_scores[round_index][player_index] += score

        # 投球履歴
        record = rules.build_throw_record(
            state=self.state,
            score=score,
            hit=hit,
            is_miss=is_miss
        )

        if is_skip:
            record["is_skip"] = True
            record["ring"] = "SKIP"

        self.state.throw_history.append(record)

        self.state.dart_no += 1

        if self.state.dart_no > 3:
            self.state.throw_collect_confirmed = False

            turn_throws = self._get_current_turn_throws()

            awards = rules.evaluate_turn_awards(turn_throws)
            self._record_turn_awards(player_index, awards)

            if awards:
                self.state.pending_awards = awards
                self.state.pending_award_ready_at = time.time() + AWARD_PRE_DELAY_SEC
                self.state.pending_award_active = True
            else:
                self._start_throw_collect_wait(False)

    def _play_hit_sound(self, hit, score):

        if score == 0:
            return

        is_fat_bull = getattr(self.state, "is_fat_bull", False)

        ring = hit.ring.name

        # -------------------------
        # bull
        # -------------------------
        if ring == "INNER_BULL":
            self.engine.audio.play("bull_inner")
            return

        if ring == "OUTER_BULL":
            self.engine.audio.play("bull_outer")
            return

        # -------------------------
        # normal hit
        # -------------------------
        if ring == "SINGLE":
            self.engine.audio.play("normal_single")

        elif ring == "DOUBLE":
            self.engine.audio.play("normal_double")

        elif ring == "TRIPLE":
            self.engine.audio.play("normal_triple")

        else:
            # 保険（未知リング）
            self.engine.audio.play("normal_single")

    def _start_throw_collect_wait(self, award_played: bool):

        self.state.throw_collect_blink_immediate = award_played

        # 最終プレイヤー・最終ラウンドの3投完了後は、
        # ENTER待ちに入らず自動でリザルトへ進める
        if (
            self.state.round_no >= self.state.rounds
            and self.state.current_player >= self.state.players - 1
        ):
            self.state.finish_pending = True
            self.state.finish_at = time.time() + 2.0
            return

        self.state.waiting_for_throw_collect = True
        self.state.pending_next_player = True
        self.state.throw_collect_message = None

        now = time.time()

        if award_played:
            if self.state.throw_collect_confirmed:
                self.state.throw_collect_ready_at = time.time()
            else:
                self.state.throw_collect_ready_at = (
                    self.state.input_locked_until + AWARD_PLAYER_CHANGE_LOCK_SEC
                )
        else:
            # 通常時は規定秒待ってから矢抜き表示
            self.state.input_locked_until = now + PLAYER_CHANGE_LOCK_SEC
            self.state.throw_collect_ready_at = now + PLAYER_CHANGE_LOCK_SEC

    def _confirm_throw_collect(self):
        self.state.waiting_for_throw_collect = False
        self.state.pending_next_player = False
        self.state.throw_collect_message = None
        self.state.throw_collect_ready_at = 0.0
        self.state.throw_collect_blink_immediate = False

        self.state.dart_no = 1
        self._next_player()

        if not self.state.finished:
            self.engine.audio.play("player_change")
            self._start_player_change_cutin()
            self._lock_player_change()

    def _record_turn_awards(self, player_index, awards):

        if not hasattr(self.state, "award_counts"):
            return

        if player_index < 0 or player_index >= len(self.state.award_counts):
            return

        counts = self.state.award_counts[player_index]

        for award in awards:
            if award in counts:
                counts[award] += 1

    def _get_current_turn_throws(self):
        """
        現在プレイヤー・現在ラウンドの投球履歴を取得する。
        基本的に3投分。
        """

        return [
            t for t in self.state.throw_history
            if t["round_no"] == self.state.round_no
            and t["player"] == self.state.current_player
        ][-3:]

    def _play_award(self, awards):

        if not awards:
            self.state.current_award = None
            return False

        # 再生優先順位（難易度順）
        priority = [
            "ton_80",
            "shisa_eye",
            "hat_trick",
            "3_in_a_bed",
            "high_ton",
            "low_ton",
        ]

        for award in priority:
            if award in awards:
                self.state.current_award = award

                now = time.time()

                # ロック開始
                self.state.input_locked_until = time.time() + AWARD_INPUT_LOCK_SEC

                self.engine.video.play_with_intro(
                    award,
                    black_seconds=0.3,
                    poll_callback=self._poll_award_input
                )

                return True

        self.state.current_award = None
        return False

    def _poll_award_input(self):
        led = getattr(self.engine, "led", None)

        events = self.engine.input.poll()

        for e in events:
            if e.type == EventType.BUTTON_PRESSED and e.payload == ButtonType.ENTER:
                self.state.throw_collect_confirmed = True

                if led is not None:
                    led.restore_button_leds()
                    led.update()

                return True

        if led is not None:
            led.set_enter_blink_only()
            led.update()

        return False

    def _next_player(self):

        if self.state.finished:
            return

        self.state.current_player += 1

        if self.state.current_player >= self.state.players:
            self.state.current_player = 0
            self.state.round_no += 1

        self.state.dart_no = 1

        if self.state.round_no > self.state.rounds:
            self.state.finished = True

    def _start_player_change_cutin(self):

        self.state.cutin_active = True
        self.state.cutin_start_time = time.time()

    def _lock_player_change(self):

        self.state.current_award = None
        self.state.input_locked_until = time.time() + PLAYER_CHANGE_LOCK_SEC

    def _save_snapshot(self):

        self.state.last_snapshot = {
            "scores": self.state.scores.copy(),
            "round_scores": [
                row.copy() for row in self.state.round_scores
            ],
            "throw_history": self.state.throw_history.copy(),
            "award_counts": [
                row.copy() for row in self.state.award_counts
            ],
            "current_player": self.state.current_player,
            "round_no": self.state.round_no,
            "dart_no": self.state.dart_no,
            "finished": self.state.finished,
        }

    def toggle_count_miss_as_throw(self):
        self.state.count_miss_as_throw = not self.state.count_miss_as_throw

    def can_undo(self):
        if self.state.last_snapshot is None:
            return False

        if self.state.undo_limit == -1:
            return True

        return self.state.undo_used < self.state.undo_limit

    def get_undo_remaining_text(self):
        if self.state.undo_limit == -1:
            return "制限なし"

        remaining = self.state.undo_limit - self.state.undo_used
        if remaining < 0:
            remaining = 0

        return f"{remaining}回"

    def undo(self):
        if not self.can_undo():
            self.engine.audio.play("miss")
            return False

        self._undo()
        return True

    def _undo(self):

        if self.state.last_snapshot is None:
            self.engine.audio.play("miss")
            return

        if self.state.undo_limit != -1:
            if self.state.undo_used >= self.state.undo_limit:
                self.engine.audio.play("miss")
                return

        snap = self.state.last_snapshot

        self.state.scores = snap["scores"].copy()
        self.state.round_scores = [
            row.copy() for row in snap["round_scores"]
        ]
        self.state.throw_history = snap["throw_history"].copy()

        self.state.award_counts = [
            row.copy() for row in snap.get("award_counts", self.state.award_counts)
        ]

        self.state.current_player = snap["current_player"]
        self.state.round_no = snap["round_no"]
        self.state.dart_no = snap["dart_no"]
        self.state.finished = snap["finished"]

        # 直前1投だけUndo可能にするため破棄
        self.state.last_snapshot = None
        self.state.undo_used += 1

        self.engine.audio.play("cancel")