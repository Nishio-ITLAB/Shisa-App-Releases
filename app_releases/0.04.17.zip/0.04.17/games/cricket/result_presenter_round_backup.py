# games/cricket/result_presenter.py


def build_result_view(state):
    """
    CRICKET用リザルト表示データを構築する。
    描画はしない。
    """

    players = state.players
    rounds = state.rounds

    player_results = []

    for player_index in range(players):

        total_score = state.scores[player_index]

        round_scores = [
            state.round_scores[round_index][player_index]
            for round_index in range(rounds)
        ]

        high_round = max(round_scores) if round_scores else 0

        player_throws = [
            t for t in state.throw_history
            if t.get("player") == player_index
        ]

        # プレイヤーごとに投げた分をそのままスタッツ対象にする
        # 表示側もプレイヤー単位でグレー判定しているため、ここも揃える
        mpr_throws = _get_mpr_80_throws(player_throws)

        dart_count = len(player_throws)
        mpr_dart_count = len(mpr_throws)

        miss_count = sum(
            1 for t in player_throws
            if t.get("is_miss") or t.get("ring") == "MISS"
        )

        valid_hit_count = sum(
            1 for t in player_throws
            if t.get("valid")
        )

        total_marks = sum(
            _effective_marks(t)
            for t in player_throws
        )

        mpr_marks = sum(
            _effective_marks(t)
            for t in mpr_throws
        )

        applied_marks = sum(
            int(t.get("applied_marks", 0))
            for t in player_throws
            if t.get("valid")
        )

        overflow_marks = sum(
            int(t.get("overflow_marks", 0))
            for t in player_throws
            if t.get("valid")
        )

        closed_count = _count_closed_targets(state, player_index)

        ppd = 0.0
        if dart_count > 0:
            ppd = total_score / dart_count

        mpr = 0.0
        if mpr_dart_count > 0:
            mpr = mpr_marks / (mpr_dart_count / 3.0)

        marks = {
            target: state.marks[player_index][target]
            for target in state.targets
        }

        player_results.append({
            "player": player_index,
            "label": f"PLAYER {player_index + 1}",
            "total_score": total_score,
            "round_scores": round_scores,
            "high_round": high_round,
            "dart_count": dart_count,
            "valid_hit_count": valid_hit_count,
            "miss_count": miss_count,
            "total_marks": total_marks,
            "applied_marks": applied_marks,
            "overflow_marks": overflow_marks,
            "closed_count": closed_count,
            "ppd": ppd,
            "mpr": mpr,
            "mpr_marks": mpr_marks,
            "mpr_dart_count": mpr_dart_count,
            "marks": marks,
            "all_closed": closed_count >= len(state.targets),
        })

    reverse = True

    if state.mode_id == "cut_throat":
        reverse = False

    ranking = sorted(
        player_results,
        key=lambda x: x["total_score"],
        reverse=reverse
    )

    _apply_competition_ranking(ranking)

    round_table = []

    for round_index in range(rounds):
        round_no = round_index + 1

        row = {
            "round_no": round_no,
            "marks": [
                _build_round_mark_list(
                    state=state,
                    round_no=round_no,
                    player_index=player_index,
                )
                for player_index in range(players)
            ]
        }

        round_table.append(row)

    mark_table = []

    for target in state.targets:
        row = {
            "target": target,
            "label": _format_target(target),
            "marks": [
                state.marks[player_index][target]
                for player_index in range(players)
            ],
            "mark_labels": [
                _format_mark(state.marks[player_index][target])
                for player_index in range(players)
            ],
        }
        mark_table.append(row)

    return {
        "mode": _format_mode_name(state.mode_id),
        "players": players,
        "rounds": rounds,
        "winner": state.winner,
        "winner_label": _format_winner(state),
        "result_reason": state.result_reason,
        "is_draw": state.result_reason == "draw",
        "ranking": ranking,
        "players_detail": player_results,
        "round_table": round_table,
        "mark_table": mark_table,
        "targets": state.targets.copy(),
        "totals": state.scores.copy(),
    }


def _apply_competition_ranking(rows):
    """
    同点は competition ranking 方式。
    例: 100, 100, 80 => 1st, 1st, 3rd
    """

    previous_score = None
    previous_rank = 0

    for index, row in enumerate(rows):
        rank = index + 1

        if previous_score is not None and row["total_score"] == previous_score:
            row["rank"] = previous_rank
        else:
            row["rank"] = rank
            previous_rank = rank

        row["rank_label"] = _format_rank(row["rank"])
        previous_score = row["total_score"]


def _get_mpr_80_throws(player_throws):
    """
    6エリアclosed到達dartまでをMPR対象にする。
    到達dart自体は含める。
    6エリア未到達の場合は全投を対象にする。
    """

    result = []

    for t in player_throws:
        result.append(t)

        if int(t.get("closed_target_count", 0)) >= 6:
            break

    return result


def _effective_marks(t):
    """
    MPR用の実効マーク数。
    applied_marks + 得点化されたoverflow_marks。
    """

    if t.get("is_skip") or t.get("is_miss"):
        return 0

    applied_marks = int(t.get("applied_marks", 0))
    overflow_marks = int(t.get("overflow_marks", 0))

    score_deltas = t.get("score_deltas", [])
    has_score = any(delta != 0 for delta in score_deltas)

    scoring_marks = overflow_marks if has_score else 0

    return applied_marks + scoring_marks


def _build_round_mark_list(state, round_no, player_index):
    """
    1ラウンド分の3投マーク表示用。
    MISS/SKIP/未投は表示しない。
    """

    throws = [
        t for t in state.throw_history
        if t.get("round_no") == round_no
        and t.get("player") == player_index
    ][:3]

    marks = []

    for t in throws:
        mark = _effective_marks(t)

        if mark <= 0:
            marks.append("")
        elif mark == 1:
            marks.append("/")
        elif mark == 2:
            marks.append("X")
        else:
            marks.append("O")

    while len(marks) < 3:
        marks.append("")

    return marks

def _count_closed_targets(state, player_index):
    count = 0

    for target in state.targets:
        if state.marks[player_index][target] >= 3:
            count += 1

    return count


def _format_mark(mark):

    if mark <= 0:
        return ""

    if mark == 1:
        return "/"

    if mark == 2:
        return "X"

    return "O"


def _format_winner(state):
    if state.winner is None:
        return None

    return f"PLAYER {state.winner + 1}"


def _format_rank(rank):

    if rank == 1:
        return "1st"

    if rank == 2:
        return "2nd"

    if rank == 3:
        return "3rd"

    return f"{rank}th"


def _format_mode_name(mode_id):

    if mode_id == "standard":
        return "STANDARD CRICKET"

    if mode_id == "cut_throat":
        return "CUT THROAT CRICKET"

    return str(mode_id).upper()


def _format_target(target):

    if target == "BULL":
        return "BULL"

    return str(target)