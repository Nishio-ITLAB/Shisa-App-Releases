# framework/input_manager.py

from typing import List

from hw_platform.io.dart_io import DartIO
from framework.input_types import InputEvent
from framework.input_keyboard import KeyboardInput


class InputManager:

    def __init__(self):
        self.dart_io = DartIO()
        self.keyboard = KeyboardInput()

    def poll(self) -> List[InputEvent]:
        events = []

        try:
            events.extend(self.dart_io.poll())
        except Exception as e:
            print("DartIO error:", e)

        try:
            events.extend(self.keyboard.poll())
        except Exception as e:
            print("KeyboardInput error:", e)

        return events