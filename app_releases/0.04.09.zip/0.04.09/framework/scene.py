# framework/scene.py

from framework.input_types import InputEvent, EventType, ButtonType


class Scene:
    """
    全シーンの基底クラス。
    Engine から毎フレーム run() が呼ばれる。
    """

    def __init__(self, engine):
        self.engine = engine
        self._events = []

        # True:
        #   USBキーボードの UP/DOWN/LEFT/RIGHT/ENTER/ESCAPE を
        #   ButtonType互換イベントへ変換する。
        #
        # False:
        #   KEY_PRESSEDをそのままSceneへ渡す。
        #   SSID/PASS入力画面など、物理キーボードEnterを
        #   ボタンEnterと別扱いしたい画面で使う。
        self.keyboard_nav_enabled = True

    def set_events(self, events):
        self._events = events

    def get_events(self):
        if not self.keyboard_nav_enabled:
            return self._events

        converted = []

        for e in self._events:

            mapped = self._map_keyboard_to_button(e)

            if mapped is not None:
                converted.append(mapped)
            else:
                converted.append(e)

        return converted

    def _map_keyboard_to_button(self, event):

        if event.type != EventType.KEY_PRESSED:
            return None

        key = event.payload

        if key == "UP":
            button = ButtonType.NAV_UP

        elif key == "DOWN":
            button = ButtonType.NAV_DOWN

        elif key == "LEFT":
            button = ButtonType.NAV_LEFT

        elif key == "RIGHT":
            button = ButtonType.NAV_RIGHT

        elif key == "ENTER":
            button = ButtonType.ENTER

        elif key == "ESCAPE":
            button = ButtonType.CANCEL

        else:
            return None

        return InputEvent(
            type=EventType.BUTTON_PRESSED,
            payload=button,
            timestamp=event.timestamp
        )

    def run(self):
        """
        毎フレーム実行。
        次に遷移する Scene を返す。
        基本は self を返す。
        """
        return self
