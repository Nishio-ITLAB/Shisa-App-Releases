# framework/renderer.py

import os
os.environ["PYOPENGL_PLATFORM"] = "egl"

import ctypes
import sdl2
from ctypes import c_void_p
import numpy as np
from OpenGL import GL


class Renderer:
    """
    Dual pipeline renderer with logical 16:9 canvas.

    [基本方針]
      - View / Scene 側は logical_width x logical_height の論理座標で描画する
      - Renderer 側で実ウィンドウへ aspect-fit / letterbox 表示する
      - デフォルト論理解像度は 1920x1080
      - 既存互換のため Renderer(1920, 1080) はそのまま使用可能

    [VIDEO PIPELINE]
      - draw_solid(): swap内包
      - blit_rgba_frame(): swap内包
      - 動画も viewport 内へ aspect-fit 表示
      - video_player.py は swap内包挙動を前提にしているため維持

    [UI PIPELINE]
      - ui_clear(): swapしない
      - ui_draw_*(): swapしない
      - ui_swap(): swapする
      - UI座標は logical_width x logical_height の左上原点ピクセル座標
    """

    DEFAULT_LOGICAL_WIDTH = 1920
    DEFAULT_LOGICAL_HEIGHT = 1080

    def __init__(
        self,
        width=1280,
        height=720,
        logical_width=DEFAULT_LOGICAL_WIDTH,
        logical_height=DEFAULT_LOGICAL_HEIGHT,
    ):
        # --------------------------------------------------
        # 出力ウィンドウ解像度
        # --------------------------------------------------
        self.width = int(width)
        self.height = int(height)

        # 明示的に output_* も持っておく
        self.output_width = int(width)
        self.output_height = int(height)

        # --------------------------------------------------
        # 論理キャンバス解像度
        # --------------------------------------------------
        self.logical_width = int(logical_width)
        self.logical_height = int(logical_height)

        # --------------------------------------------------
        # letterbox viewport
        # --------------------------------------------------
        self.viewport_x = 0
        self.viewport_y = 0
        self.viewport_w = self.output_width
        self.viewport_h = self.output_height
        self.viewport_scale = 1.0

        self._update_logical_viewport()

        self.window = None
        self.ctx = None

        # ---- VIDEO pipeline resources ----
        self.prog_video = None
        self.vbo_video = None
        self.tex_video = None
        self.u_tex_loc_video = None

        # ---- UI pipeline resources ----
        self.prog_ui = None
        self.vbo_ui = None
        self.tex_ui = None
        self.u_tex_loc_ui = None
        self.u_screen_loc_ui = None

        self._init_sdl_gl()
        self._init_video_pipeline()
        self._init_ui_pipeline()

    # --------------------------------------------------
    # VIEWPORT / LETTERBOX
    # --------------------------------------------------
    def _update_logical_viewport(self):
        if self.logical_width <= 0 or self.logical_height <= 0:
            self.logical_width = self.DEFAULT_LOGICAL_WIDTH
            self.logical_height = self.DEFAULT_LOGICAL_HEIGHT

        if self.output_width <= 0 or self.output_height <= 0:
            self.output_width = self.logical_width
            self.output_height = self.logical_height

        sx = self.output_width / self.logical_width
        sy = self.output_height / self.logical_height

        self.viewport_scale = min(sx, sy)

        self.viewport_w = int(round(self.logical_width * self.viewport_scale))
        self.viewport_h = int(round(self.logical_height * self.viewport_scale))

        self.viewport_x = int((self.output_width - self.viewport_w) // 2)
        self.viewport_y = int((self.output_height - self.viewport_h) // 2)

    def _set_full_viewport(self):
        GL.glViewport(0, 0, self.output_width, self.output_height)

    def _set_logical_viewport(self):
        """
        OpenGL viewport は左下原点。
        SDL/画面設計上の viewport_y は上基準で考えたいが、
        letterbox は上下対称なのでこのままでも実害はない。
        念のため OpenGL 座標として下基準に変換する。
        """
        gl_x = self.viewport_x
        gl_y = self.output_height - self.viewport_y - self.viewport_h

        GL.glViewport(gl_x, gl_y, self.viewport_w, self.viewport_h)

    def _clear_fullscreen(self, r, g, b, a=1.0):
        """
        黒帯を含む実ウィンドウ全体をクリアする。
        """
        self._set_full_viewport()
        GL.glClearColor(r, g, b, a)
        GL.glClear(GL.GL_COLOR_BUFFER_BIT)

    # --------------------------------------------------
    # SDL + GL INIT
    # --------------------------------------------------
    def _init_sdl_gl(self):
        sdl2.SDL_Init(sdl2.SDL_INIT_VIDEO)

        sdl2.SDL_GL_SetAttribute(sdl2.SDL_GL_CONTEXT_MAJOR_VERSION, 2)
        sdl2.SDL_GL_SetAttribute(sdl2.SDL_GL_CONTEXT_MINOR_VERSION, 0)
        sdl2.SDL_GL_SetAttribute(
            sdl2.SDL_GL_CONTEXT_PROFILE_MASK,
            sdl2.SDL_GL_CONTEXT_PROFILE_ES
        )

        self.window = sdl2.SDL_CreateWindow(
            b"SHISA",
            sdl2.SDL_WINDOWPOS_CENTERED,
            sdl2.SDL_WINDOWPOS_CENTERED,
            self.output_width,
            self.output_height,
            sdl2.SDL_WINDOW_OPENGL
        )

        self.ctx = sdl2.SDL_GL_CreateContext(self.window)
        sdl2.SDL_GL_MakeCurrent(self.window, self.ctx)

        # vsync要求（環境により無視される場合あり）
        sdl2.SDL_GL_SetSwapInterval(1)

        sdl2.SDL_ShowCursor(sdl2.SDL_DISABLE)

        self._set_full_viewport()

    # --------------------------------------------------
    # Shader compile helper
    # --------------------------------------------------
    def _compile_program(self, vs_src: str, fs_src: str):
        vs = GL.glCreateShader(GL.GL_VERTEX_SHADER)
        GL.glShaderSource(vs, vs_src)
        GL.glCompileShader(vs)

        fs = GL.glCreateShader(GL.GL_FRAGMENT_SHADER)
        GL.glShaderSource(fs, fs_src)
        GL.glCompileShader(fs)

        prog = GL.glCreateProgram()
        GL.glAttachShader(prog, vs)
        GL.glAttachShader(prog, fs)
        GL.glLinkProgram(prog)

        return prog

    # --------------------------------------------------
    # VIDEO PIPELINE
    # --------------------------------------------------
    def _init_video_pipeline(self):
        vs_src = """
        attribute vec2 a_pos;
        attribute vec2 a_uv;
        varying vec2 v_uv;

        void main() {
            gl_Position = vec4(a_pos, 0.0, 1.0);
            v_uv = a_uv;
        }
        """

        fs_src = """
        precision mediump float;
        varying vec2 v_uv;
        uniform sampler2D u_tex;

        void main() {
            gl_FragColor = texture2D(u_tex, v_uv);
        }
        """

        self.prog_video = self._compile_program(vs_src, fs_src)
        GL.glUseProgram(self.prog_video)

        # viewport 内全面に出す NDC クアッド
        quad = np.array([
            -1.0, -1.0, 0.0, 1.0,
             1.0, -1.0, 1.0, 1.0,
            -1.0,  1.0, 0.0, 0.0,
             1.0,  1.0, 1.0, 0.0,
        ], dtype=np.float32)

        self.vbo_video = GL.glGenBuffers(1)
        GL.glBindBuffer(GL.GL_ARRAY_BUFFER, self.vbo_video)
        GL.glBufferData(GL.GL_ARRAY_BUFFER, quad.nbytes, quad, GL.GL_STATIC_DRAW)

        pos_loc = GL.glGetAttribLocation(self.prog_video, "a_pos")
        uv_loc = GL.glGetAttribLocation(self.prog_video, "a_uv")

        GL.glEnableVertexAttribArray(pos_loc)
        GL.glVertexAttribPointer(
            pos_loc,
            2,
            GL.GL_FLOAT,
            GL.GL_FALSE,
            16,
            c_void_p(0)
        )

        GL.glEnableVertexAttribArray(uv_loc)
        GL.glVertexAttribPointer(
            uv_loc,
            2,
            GL.GL_FLOAT,
            GL.GL_FALSE,
            16,
            c_void_p(8)
        )

        self.tex_video = GL.glGenTextures(1)
        GL.glActiveTexture(GL.GL_TEXTURE0)
        GL.glBindTexture(GL.GL_TEXTURE_2D, self.tex_video)

        GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MIN_FILTER, GL.GL_LINEAR)
        GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MAG_FILTER, GL.GL_LINEAR)
        GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_WRAP_S, GL.GL_CLAMP_TO_EDGE)
        GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_WRAP_T, GL.GL_CLAMP_TO_EDGE)

        self.u_tex_loc_video = GL.glGetUniformLocation(self.prog_video, "u_tex")
        if self.u_tex_loc_video != -1:
            GL.glUniform1i(self.u_tex_loc_video, 0)

    def _use_video(self):
        GL.glUseProgram(self.prog_video)

        # 動画も UI と同じ 16:9 論理領域へ出す
        self._set_logical_viewport()

        GL.glDisable(GL.GL_BLEND)

        GL.glBindBuffer(GL.GL_ARRAY_BUFFER, self.vbo_video)

        GL.glActiveTexture(GL.GL_TEXTURE0)
        GL.glBindTexture(GL.GL_TEXTURE_2D, self.tex_video)

        pos_loc = GL.glGetAttribLocation(self.prog_video, "a_pos")
        uv_loc = GL.glGetAttribLocation(self.prog_video, "a_uv")

        GL.glEnableVertexAttribArray(pos_loc)
        GL.glVertexAttribPointer(
            pos_loc,
            2,
            GL.GL_FLOAT,
            GL.GL_FALSE,
            16,
            c_void_p(0)
        )

        GL.glEnableVertexAttribArray(uv_loc)
        GL.glVertexAttribPointer(
            uv_loc,
            2,
            GL.GL_FLOAT,
            GL.GL_FALSE,
            16,
            c_void_p(8)
        )

    # ---- VIDEO API ----
    def draw_solid(self, r, g, b):
        """
        黒画などの全画面単色描画。
        これは letterbox 内だけではなく、実ウィンドウ全体を塗る。
        """
        self._clear_fullscreen(r, g, b, 1.0)
        sdl2.SDL_GL_SwapWindow(self.window)

    def blit_rgba_frame(self, width, height, rgba_np):
        """
        動画フレーム描画。
        実ウィンドウ全体を黒でクリアした後、logical viewport 内に描画する。
        """
        self._clear_fullscreen(0.0, 0.0, 0.0, 1.0)
        self._use_video()

        GL.glTexImage2D(
            GL.GL_TEXTURE_2D,
            0,
            GL.GL_RGBA,
            int(width),
            int(height),
            0,
            GL.GL_RGBA,
            GL.GL_UNSIGNED_BYTE,
            rgba_np
        )

        GL.glDrawArrays(GL.GL_TRIANGLE_STRIP, 0, 4)

        sdl2.SDL_GL_SwapWindow(self.window)

    # --------------------------------------------------
    # UI PIPELINE
    # --------------------------------------------------
    def _init_ui_pipeline(self):
        vs_src = """
        attribute vec2 a_pos;
        attribute vec2 a_uv;
        varying vec2 v_uv;

        uniform vec2 u_screen;

        void main() {
            vec2 ndc = vec2(
                (a_pos.x / u_screen.x) * 2.0 - 1.0,
                1.0 - (a_pos.y / u_screen.y) * 2.0
            );

            gl_Position = vec4(ndc, 0.0, 1.0);
            v_uv = a_uv;
        }
        """

        fs_src = """
        precision mediump float;
        varying vec2 v_uv;
        uniform sampler2D u_tex;

        void main() {
            gl_FragColor = texture2D(u_tex, v_uv);
        }
        """

        self.prog_ui = self._compile_program(vs_src, fs_src)
        GL.glUseProgram(self.prog_ui)

        self.vbo_ui = GL.glGenBuffers(1)
        GL.glBindBuffer(GL.GL_ARRAY_BUFFER, self.vbo_ui)

        pos_loc = GL.glGetAttribLocation(self.prog_ui, "a_pos")
        uv_loc = GL.glGetAttribLocation(self.prog_ui, "a_uv")

        GL.glEnableVertexAttribArray(pos_loc)
        GL.glVertexAttribPointer(
            pos_loc,
            2,
            GL.GL_FLOAT,
            GL.GL_FALSE,
            16,
            c_void_p(0)
        )

        GL.glEnableVertexAttribArray(uv_loc)
        GL.glVertexAttribPointer(
            uv_loc,
            2,
            GL.GL_FLOAT,
            GL.GL_FALSE,
            16,
            c_void_p(8)
        )

        self.tex_ui = GL.glGenTextures(1)
        GL.glActiveTexture(GL.GL_TEXTURE0)
        GL.glBindTexture(GL.GL_TEXTURE_2D, self.tex_ui)

        GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MIN_FILTER, GL.GL_LINEAR)
        GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MAG_FILTER, GL.GL_LINEAR)
        GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_WRAP_S, GL.GL_CLAMP_TO_EDGE)
        GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_WRAP_T, GL.GL_CLAMP_TO_EDGE)

        self.u_tex_loc_ui = GL.glGetUniformLocation(self.prog_ui, "u_tex")
        if self.u_tex_loc_ui != -1:
            GL.glUniform1i(self.u_tex_loc_ui, 0)

        self.u_screen_loc_ui = GL.glGetUniformLocation(self.prog_ui, "u_screen")
        if self.u_screen_loc_ui != -1:
            GL.glUniform2f(
                self.u_screen_loc_ui,
                float(self.logical_width),
                float(self.logical_height)
            )

    def _use_ui(self):
        GL.glUseProgram(self.prog_ui)

        # UI は logical viewport 内にのみ描く
        self._set_logical_viewport()

        GL.glEnable(GL.GL_BLEND)
        GL.glBlendFunc(GL.GL_SRC_ALPHA, GL.GL_ONE_MINUS_SRC_ALPHA)

        GL.glBindBuffer(GL.GL_ARRAY_BUFFER, self.vbo_ui)

        GL.glActiveTexture(GL.GL_TEXTURE0)
        GL.glBindTexture(GL.GL_TEXTURE_2D, self.tex_ui)

        pos_loc = GL.glGetAttribLocation(self.prog_ui, "a_pos")
        uv_loc = GL.glGetAttribLocation(self.prog_ui, "a_uv")

        GL.glEnableVertexAttribArray(pos_loc)
        GL.glVertexAttribPointer(
            pos_loc,
            2,
            GL.GL_FLOAT,
            GL.GL_FALSE,
            16,
            c_void_p(0)
        )

        GL.glEnableVertexAttribArray(uv_loc)
        GL.glVertexAttribPointer(
            uv_loc,
            2,
            GL.GL_FLOAT,
            GL.GL_FALSE,
            16,
            c_void_p(8)
        )

        # UI座標変換は実解像度ではなく論理解像度
        if self.u_screen_loc_ui != -1:
            GL.glUniform2f(
                self.u_screen_loc_ui,
                float(self.logical_width),
                float(self.logical_height)
            )

    # ---- UI API ----
    def ui_clear(self, r, g, b, a=1.0):
        """
        UIフレーム開始時のクリア。
        黒帯を残さないため、まず実ウィンドウ全体を黒でクリア。
        その後、logical viewport 内を指定色でクリアする。
        """
        self._clear_fullscreen(0.0, 0.0, 0.0, 1.0)

        self._use_ui()
        GL.glClearColor(r, g, b, a)
        GL.glClear(GL.GL_COLOR_BUFFER_BIT)

    def ui_swap(self):
        sdl2.SDL_GL_SwapWindow(self.window)

    def ui_draw_texture(self, x, y, w, h, rgba_np):
        """
        x, y, w, h は logical_width x logical_height 上の論理ピクセル座標。
        """
        self._use_ui()

        ww = int(w)
        hh = int(h)
        if ww <= 0 or hh <= 0:
            return

        GL.glTexImage2D(
            GL.GL_TEXTURE_2D,
            0,
            GL.GL_RGBA,
            ww,
            hh,
            0,
            GL.GL_RGBA,
            GL.GL_UNSIGNED_BYTE,
            rgba_np
        )

        vertices = np.array([
            x,     y,     0.0, 0.0,
            x + w, y,     1.0, 0.0,
            x,     y + h, 0.0, 1.0,

            x + w, y,     1.0, 0.0,
            x + w, y + h, 1.0, 1.0,
            x,     y + h, 0.0, 1.0,
        ], dtype=np.float32)

        GL.glBufferData(
            GL.GL_ARRAY_BUFFER,
            vertices.nbytes,
            vertices,
            GL.GL_DYNAMIC_DRAW
        )
        GL.glDrawArrays(GL.GL_TRIANGLES, 0, 6)

    def ui_draw_rect(self, x, y, w, h, color):
        r, g, b, a = color

        ww = int(w)
        hh = int(h)
        if ww <= 0 or hh <= 0:
            return

        img = np.empty((hh, ww, 4), dtype=np.uint8)
        img[..., 0] = int(max(0.0, min(1.0, r)) * 255)
        img[..., 1] = int(max(0.0, min(1.0, g)) * 255)
        img[..., 2] = int(max(0.0, min(1.0, b)) * 255)
        img[..., 3] = int(max(0.0, min(1.0, a)) * 255)

        self.ui_draw_texture(x, y, w, h, img)

    # --------------------------------------------------
    # UTILITY
    # --------------------------------------------------
    def get_logical_size(self):
        return self.logical_width, self.logical_height

    def get_output_size(self):
        return self.output_width, self.output_height

    def get_viewport(self):
        return {
            "x": self.viewport_x,
            "y": self.viewport_y,
            "w": self.viewport_w,
            "h": self.viewport_h,
            "scale": self.viewport_scale,
        }

    def pump_events(self):
        ev = sdl2.SDL_Event()

        while sdl2.SDL_PollEvent(ctypes.byref(ev)) != 0:
            if ev.type == sdl2.SDL_QUIT:
                return False

        return True