# framework/scenes/boot.py

from framework.scenes.base import BaseScene
from framework.scenes.menu import MenuScene


class BootScene(BaseScene):

    def run(self):
        # 起動動画（黒→初期動画、音は映像開始に同期）
        self.engine.video.play_with_intro("initial", black_seconds=2.0)

        # 次はメニュー
        return MenuScene(self.engine)
