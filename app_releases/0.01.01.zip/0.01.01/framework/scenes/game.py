# framework/scenes/game.py

from framework.scenes.base import BaseScene


class GameScene(BaseScene):
    def run(self):
        # TODO: 実装
        return None
