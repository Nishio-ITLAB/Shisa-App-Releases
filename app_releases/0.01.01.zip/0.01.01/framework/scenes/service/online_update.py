# framework/scenes/service/online_update.py

import json
from pathlib import Path
import time
import urllib.request
import urllib.error
import subprocess
import shutil

import numpy as np
from PIL import Image, ImageDraw, ImageFont

from framework.scenes.base import BaseScene
from framework.input_types import EventType, ButtonType
from framework.ui.software_keyboard import SoftwareKeyboardScene

from utils.network import connect_wifi, check_internet, disconnect_wifi


FONT_PATH = "/opt/shisa/shared/assets/fonts/NotoSansMono-Regular.ttf"

WIFI_PATH = Path("/opt/shisa/persist/system/wifi.json")

DEFAULT_WIFI = {
    "schema_version": 1,
    "ssid": "",
    "password": ""
}

# --------------------------------------------------
# GitHub OTA source
# --------------------------------------------------

GITHUB_OWNER = "Nishio-ITLAB"
GITHUB_REPO = "Shisa-App-Releases"
GITHUB_RELEASES_DIR = "releases"

GITHUB_CONTENTS_API_URL = (
    f"https://api.github.com/repos/{GITHUB_OWNER}/{GITHUB_REPO}/contents/{GITHUB_RELEASES_DIR}"
)

# --------------------------------------------------
# OTA paths
# --------------------------------------------------

UPLOAD_DIR = Path("/opt/shisa/shared/uploads")
TMP_DIR = UPLOAD_DIR / "tmp_extract"
RELEASES_DIR = Path("/opt/shisa/releases")
CURRENT_LINK = Path("/opt/shisa/current")


class OnlineUpdateScene(BaseScene):

    def __init__(self, engine):
        super().__init__(engine)

        self.r = self.engine.renderer
        self.W = self.r.width
        self.H = self.r.height

        # --------------------------------------------------
        # wifi.json load / create
        # --------------------------------------------------

        if not WIFI_PATH.exists():

            WIFI_PATH.parent.mkdir(parents=True, exist_ok=True)

            with open(WIFI_PATH, "w") as f:
                json.dump(DEFAULT_WIFI, f, indent=2)

            self.wifi = DEFAULT_WIFI.copy()

        else:

            with open(WIFI_PATH) as f:
                self.wifi = json.load(f)

        if "ssid" not in self.wifi:
            self.wifi["ssid"] = ""

        if "password" not in self.wifi:
            self.wifi["password"] = ""

        # --------------------------------------------------
        # Font
        # --------------------------------------------------

        self.title_font_size = int(self.H * 0.08)
        self.menu_font_size = int(self.H * 0.055)
        self.log_font_size = int(self.H * 0.03)

        self.title_font = ImageFont.truetype(FONT_PATH, self.title_font_size)
        self.menu_font = ImageFont.truetype(FONT_PATH, self.menu_font_size)
        self.log_font = ImageFont.truetype(FONT_PATH, self.log_font_size)

        ascent_t, descent_t = self.title_font.getmetrics()
        self.title_height = ascent_t + descent_t

        ascent_m, descent_m = self.menu_font.getmetrics()
        self.menu_height = ascent_m + descent_m

        ascent_l, descent_l = self.log_font.getmetrics()
        self.log_height = ascent_l + descent_l

        self.text_cache = {}

        # --------------------------------------------------
        # Menu
        # --------------------------------------------------

        self.menu_items = [
            "UPDATE EXECUTE",
            "SSID",
            "PASSWORD",
        ]

        self.index = 0

        # --------------------------------------------------
        # Box
        # --------------------------------------------------

        self.box_width = int(self.W * 0.7)
        self.box_height = int(self.H * 0.45)
        self.box_radius = 40

        self.box_x = (self.W - self.box_width) // 2
        self.box_y = int(self.H * 0.28)

        self._menu_box_texture = self._create_rounded_box()

        # --------------------------------------------------
        # Update state
        # --------------------------------------------------

        self.update_mode = False
        self.update_logs = []
        self.update_step = 0
        self.update_timer = 0

        self.latest = None
        self.zip_path = None

    # --------------------------------------------------

    def _create_rounded_box(self):

        img = Image.new("RGBA", (self.box_width, self.box_height), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        draw.rounded_rectangle(
            [0, 0, self.box_width, self.box_height],
            radius=self.box_radius,
            fill=(20, 20, 20, 220)
        )

        return np.array(img, dtype=np.uint8)

    # --------------------------------------------------

    def _get_text_texture(self, text, font, color):

        key = (text, font.size, color)

        if key in self.text_cache:
            return self.text_cache[key]

        w = max(1, int(font.getlength(text)))

        ascent, descent = font.getmetrics()
        h = ascent + descent

        img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        draw.text((0, 0), text, font=font, fill=color)

        arr = np.array(img, dtype=np.uint8)

        self.text_cache[key] = (arr, w, h)

        return arr, w, h

    # --------------------------------------------------

    def _save_wifi(self):

        with open(WIFI_PATH, "w") as f:
            json.dump(self.wifi, f, indent=2)

    # --------------------------------------------------
    # version helpers
    # --------------------------------------------------

    def _get_current_version(self):

        try:
            with open("/opt/shisa/current/version.txt", "r") as f:
                lines = f.read().splitlines()
                version = lines[0].strip() if len(lines) > 0 else "unknown"
                return version
        except Exception as e:
            print("GET CURRENT VERSION ERROR:", e)
            return "unknown"

    def _parse_version_tuple(self, version_str):

        try:
            parts = version_str.strip().split(".")
            return tuple(int(p) for p in parts)
        except Exception:
            return None

    def _compare_versions(self, current_version, latest_version):

        cur = self._parse_version_tuple(current_version)
        lat = self._parse_version_tuple(latest_version)

        if cur is None or lat is None:
            return None

        if lat > cur:
            return 1

        if lat < cur:
            return -1

        return 0

    # --------------------------------------------------
    # github helpers
    # --------------------------------------------------

    def _fetch_latest_release_info(self):

        print("===== FETCH LATEST RELEASE INFO START =====")
        print("URL:", GITHUB_CONTENTS_API_URL)

        req = urllib.request.Request(
            GITHUB_CONTENTS_API_URL,
            headers={
                "Accept": "application/vnd.github+json",
                "User-Agent": "Shisa-OTA-Updater"
            }
        )

        with urllib.request.urlopen(req, timeout=10) as resp:

            status = getattr(resp, "status", None)
            print("HTTP STATUS:", status)

            body = resp.read().decode("utf-8")
            items = json.loads(body)

        if not isinstance(items, list):
            raise RuntimeError("INVALID GITHUB RESPONSE")

        zip_items = []

        for item in items:

            name = item.get("name", "")
            download_url = item.get("download_url", "")

            if not name.endswith(".zip"):
                continue

            version = name[:-4].strip()

            if self._parse_version_tuple(version) is None:
                print("SKIP INVALID VERSION ZIP:", name)
                continue

            zip_items.append({
                "name": name,
                "version": version,
                "download_url": download_url,
            })

        if not zip_items:
            raise RuntimeError("NO RELEASE ZIP FOUND")

        zip_items.sort(
            key=lambda x: self._parse_version_tuple(x["version"])
        )

        latest = zip_items[-1]

        print("LATEST ZIP NAME:", latest["name"])
        print("LATEST VERSION:", latest["version"])
        print("LATEST DOWNLOAD URL:", latest["download_url"])

        return latest

    # --------------------------------------------------
    # OTA helpers
    # --------------------------------------------------

    def _download_zip(self, url, filename):

        print("===== DOWNLOAD ZIP START =====")
        print("URL:", url)
        print("FILENAME:", filename)

        try:
            UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

            dst = UPLOAD_DIR / filename

            if dst.exists():
                dst.unlink()

            urllib.request.urlretrieve(url, str(dst))

            print("DOWNLOAD SUCCESS:", dst)

            return True, dst

        except Exception as e:
            print("DOWNLOAD ERROR:", e)
            self.update_logs.append(f"DOWNLOAD ERROR : {e}")
            return False, None

    # --------------------------------------------------

    def _extract_zip(self, zip_path):

        print("===== EXTRACT ZIP START =====")
        print("ZIP PATH:", zip_path)

        try:
            if TMP_DIR.exists():
                shutil.rmtree(TMP_DIR)

            TMP_DIR.mkdir(parents=True, exist_ok=True)

            r = subprocess.run(
                ["unzip", "-o", str(zip_path), "-d", str(TMP_DIR)],
                capture_output=True,
                text=True
            )

            print("UNZIP RETURN:", r.returncode)
            print("UNZIP STDOUT:", r.stdout)
            print("UNZIP STDERR:", r.stderr)

            if r.returncode != 0:
                self.update_logs.append("UNZIP FAILED")
                return False

            return True

        except Exception as e:
            print("UNZIP ERROR:", e)
            self.update_logs.append(f"UNZIP ERROR : {e}")
            return False

    # --------------------------------------------------

    def _validate_release(self, version):

        print("===== VALIDATE RELEASE START =====")
        print("VERSION:", version)

        try:
            target_dir = TMP_DIR / version

            print("TARGET DIR:", target_dir)

            if not target_dir.exists():
                self.update_logs.append("INVALID STRUCTURE")
                return False

            main_py = target_dir / "main.py"
            version_txt = target_dir / "version.txt"

            if not main_py.exists():
                self.update_logs.append("main.py NOT FOUND")
                return False

            if not version_txt.exists():
                self.update_logs.append("version.txt NOT FOUND")
                return False

            with open(version_txt, "r") as f:
                lines = f.read().splitlines()

            zip_version = lines[0].strip() if len(lines) > 0 else ""

            print("ZIP VERSION:", zip_version)

            if zip_version != version:
                self.update_logs.append("VERSION MISMATCH")
                return False

            return True

        except Exception as e:
            print("VALIDATE ERROR:", e)
            self.update_logs.append(f"VALIDATE ERROR : {e}")
            return False

    # --------------------------------------------------

    def _install_release(self, version):

        print("===== INSTALL RELEASE START =====")
        print("VERSION:", version)

        try:
            src = TMP_DIR / version
            dst = RELEASES_DIR / version

            print("SRC:", src)
            print("DST:", dst)

            RELEASES_DIR.mkdir(parents=True, exist_ok=True)

            if dst.exists():
                shutil.rmtree(dst)

            shutil.move(str(src), str(dst))

            print("INSTALL SUCCESS")

            return True

        except Exception as e:
            print("INSTALL ERROR:", e)
            self.update_logs.append(f"INSTALL ERROR : {e}")
            return False

    # --------------------------------------------------

    def _switch_current(self, version):

        print("===== SWITCH CURRENT START =====")
        print("VERSION:", version)

        try:
            target = RELEASES_DIR / version

            if not target.exists():
                self.update_logs.append("TARGET RELEASE NOT FOUND")
                return False

            r = subprocess.run(
                ["ln", "-sfn", str(target), str(CURRENT_LINK)],
                capture_output=True,
                text=True
            )

            print("LINK RETURN:", r.returncode)
            print("LINK STDOUT:", r.stdout)
            print("LINK STDERR:", r.stderr)

            if r.returncode != 0:
                self.update_logs.append("CURRENT LINK FAILED")
                return False

            assets_link = target / "assets"

            if assets_link.exists() or assets_link.is_symlink():
                assets_link.unlink()

            r = subprocess.run(
                ["ln", "-sfn", "../../shared/assets", str(assets_link)],
                capture_output=True,
                text=True
            )

            print("ASSETS LINK RETURN:", r.returncode)
            print("ASSETS LINK STDOUT:", r.stdout)
            print("ASSETS LINK STDERR:", r.stderr)

            if r.returncode != 0:
                self.update_logs.append("ASSETS LINK FAILED")
                return False

            return True

        except Exception as e:
            print("SWITCH CURRENT ERROR:", e)
            self.update_logs.append(f"SWITCH ERROR : {e}")
            return False

    # --------------------------------------------------

    def _cleanup(self, zip_path):

        print("===== CLEANUP START =====")

        try:
            if zip_path is not None and Path(zip_path).exists():
                Path(zip_path).unlink()
                print("ZIP REMOVED:", zip_path)

            if TMP_DIR.exists():
                shutil.rmtree(TMP_DIR)
                print("TMP REMOVED:", TMP_DIR)

            return True

        except Exception as e:
            print("CLEANUP ERROR:", e)
            self.update_logs.append(f"CLEANUP ERROR : {e}")
            return False

    # --------------------------------------------------

    def _reboot_system(self):

        print("===== REBOOT START =====")

        try:
            subprocess.Popen(["sudo", "reboot"])
        except Exception as e:
            print("REBOOT ERROR:", e)
            self.update_logs.append(f"REBOOT ERROR : {e}")

    # --------------------------------------------------
    # keyboard callbacks
    # --------------------------------------------------

    def _set_ssid(self, value):

        if value is not None:

            self.wifi["ssid"] = value
            self._save_wifi()

        return self

    def _set_pass(self, value):

        if value is not None:

            self.wifi["password"] = value
            self._save_wifi()

        return self

    # --------------------------------------------------
    # update process
    # --------------------------------------------------

    def _update_process(self):

        if self.update_step == 1:

            self.update_logs.append("WIFI CONNECTING...")
            self.update_step = 2
            return

        elif self.update_step == 2:

            ok, msg = connect_wifi(
                self.wifi["ssid"],
                self.wifi["password"]
            )

            self.update_logs.append(msg)

            if ok:
                self.update_step = 3
            else:
                self.update_timer = time.time()
                self.update_step = 6

            return

        elif self.update_step == 3:

            self.update_logs.append("CHECK INTERNET...")
            self.update_step = 4
            return

        elif self.update_step == 4:

            ok, msg = check_internet()

            self.update_logs.append(msg)

            if ok:
                self.update_step = 5
            else:
                self.update_timer = time.time()
                self.update_step = 6

            return

        elif self.update_step == 5:

            self.update_logs.append("CHECK LATEST VERSION...")
            self.update_step = 7
            return

        elif self.update_step == 7:

            try:
                current_version = self._get_current_version()
                self.update_logs.append(f"CURRENT : {current_version}")

                latest = self._fetch_latest_release_info()
                latest_version = latest["version"]
                self.update_logs.append(f"LATEST  : {latest_version}")

                cmp_result = self._compare_versions(
                    current_version,
                    latest_version
                )

                if cmp_result is None:
                    self.update_logs.append("VERSION COMPARE ERROR")
                    self.update_step = 6

                elif cmp_result < 0:
                    self.update_logs.append("LOCAL VERSION IS NEWER")
                    self.update_timer = time.time()
                    self.update_step = 8

                elif cmp_result == 0:
                    self.update_logs.append("NO UPDATE")
                    self.update_timer = time.time()
                    self.update_step = 8

                else:
                    self.latest = latest
                    self.update_logs.append("UPDATE AVAILABLE")
                    self.update_step = 9

            except urllib.error.HTTPError as e:
                self.update_logs.append(f"GITHUB HTTP ERROR : {e.code}")
                self.update_timer = time.time()
                self.update_step = 6

            except urllib.error.URLError as e:
                self.update_logs.append(f"GITHUB URL ERROR : {e.reason}")
                self.update_timer = time.time()
                self.update_step = 6

            except Exception as e:
                self.update_logs.append(f"GITHUB ERROR : {e}")
                self.update_timer = time.time()
                self.update_step = 6

            return

        elif self.update_step == 9:

            self.update_logs.append("DOWNLOAD ZIP...")
            ok, zip_path = self._download_zip(
                self.latest["download_url"],
                self.latest["name"]
            )

            if ok:
                self.zip_path = zip_path
                self.update_logs.append("DOWNLOAD OK")
                self.update_step = 10
            else:
                self.update_timer = time.time()
                self.update_step = 6

            return

        elif self.update_step == 10:

            self.update_logs.append("EXTRACT ZIP...")

            if self._extract_zip(self.zip_path):
                self.update_logs.append("EXTRACT OK")
                self.update_step = 11
            else:
                self.update_timer = time.time()
                self.update_step = 6

            return

        elif self.update_step == 11:

            self.update_logs.append("VALIDATE RELEASE...")

            if self._validate_release(self.latest["version"]):
                self.update_logs.append("VALIDATE OK")
                self.update_step = 12
            else:
                self.update_timer = time.time()
                self.update_step = 6

            return

        elif self.update_step == 12:

            self.update_logs.append("INSTALL RELEASE...")

            if self._install_release(self.latest["version"]):
                self.update_logs.append("INSTALL OK")
                self.update_step = 13
            else:
                self.update_timer = time.time()
                self.update_step = 6

            return

        elif self.update_step == 13:

            self.update_logs.append("SWITCH CURRENT...")

            if self._switch_current(self.latest["version"]):
                self.update_logs.append("SWITCH OK")
                self.update_step = 14
            else:
                self.update_timer = time.time()
                self.update_step = 6

            return

        elif self.update_step == 14:

            self.update_logs.append("CLEANUP...")

            if self._cleanup(self.zip_path):
                self.update_logs.append("UPDATE SUCCESS")
                self.update_logs.append("REBOOT IN 10s...")
                self.update_timer = time.time()
                self.update_step = 15
            else:
                self.update_timer = time.time()
                self.update_step = 6

            return

        elif self.update_step == 15:

            remain = 10 - int(time.time() - self.update_timer)

            if remain >= 0:
                msg = f"REBOOT IN {remain}s..."
                if not self.update_logs or self.update_logs[-1] != msg:
                    self.update_logs.append(msg)

            if time.time() - self.update_timer > 10:
                self._reboot_system()

            return

        elif self.update_step == 8:

            if time.time() - self.update_timer > 3:
                disconnect_wifi()
                self.update_mode = False

        elif self.update_step == 6:

            if not self.update_logs or self.update_logs[-1] != "FAILED":
                self.update_logs.append("FAILED")

            if time.time() - self.update_timer > 3:
                disconnect_wifi()
                self.update_mode = False

    # --------------------------------------------------

    def _handle_input(self):

        events = self.get_events()

        for e in events:

            if e.type != EventType.BUTTON_PRESSED:
                continue

            if e.payload == ButtonType.NAV_UP:

                self.index = (self.index - 1) % len(self.menu_items)

            elif e.payload == ButtonType.NAV_DOWN:

                self.index = (self.index + 1) % len(self.menu_items)

            elif e.payload == ButtonType.ENTER:

                if self.index == 0:

                    self.update_mode = True
                    self.update_logs = []
                    self.update_step = 1
                    self.update_timer = 0
                    self.latest = None
                    self.zip_path = None

                elif self.index == 1:

                    return SoftwareKeyboardScene(
                        self.engine,
                        title="INPUT SSID",
                        initial=self.wifi["ssid"],
                        on_done=self._set_ssid
                    )

                elif self.index == 2:

                    return SoftwareKeyboardScene(
                        self.engine,
                        title="INPUT PASSWORD",
                        initial=self.wifi["password"],
                        on_done=self._set_pass
                    )

            elif e.payload == ButtonType.CANCEL:

                from framework.scenes.service.system import SystemMenuScene
                return SystemMenuScene(self.engine)

        return None

    # --------------------------------------------------

    def _draw(self):

        r = self.r

        r.ui_clear(0.0, 0.0, 0.0)

        title_text = "ONLINE UPDATE"

        tex_t, w_t, h_t = self._get_text_texture(
            title_text,
            self.title_font,
            (255, 255, 255, 255)
        )

        r.ui_draw_texture(
            (self.W - w_t) // 2,
            int(self.H * 0.15),
            w_t,
            h_t,
            tex_t
        )

        r.ui_draw_texture(
            self.box_x,
            self.box_y,
            self.box_width,
            self.box_height,
            self._menu_box_texture
        )

        spacing = 40

        total_menu_height = (
            len(self.menu_items) * self.menu_height +
            (len(self.menu_items) - 1) * spacing
        )

        start_y = self.box_y + (self.box_height - total_menu_height) // 2

        left_x = self.box_x + 80
        right_x = self.box_x + self.box_width - 80

        for i, item in enumerate(self.menu_items):

            if i == self.index:
                color = (255, 80, 80, 255)
            else:
                color = (200, 200, 200, 255)

            tex_l, w_l, h_l = self._get_text_texture(
                item,
                self.menu_font,
                color
            )

            y = start_y + i * (self.menu_height + spacing)

            r.ui_draw_texture(left_x, y, w_l, h_l, tex_l)

            value = ""

            if i == 1:
                value = self.wifi["ssid"]

            elif i == 2:
                value = "*" * len(self.wifi["password"])

            tex_v, w_v, h_v = self._get_text_texture(
                value,
                self.menu_font,
                (255, 255, 255, 255)
            )

            r.ui_draw_texture(
                right_x - w_v,
                y,
                w_v,
                h_v,
                tex_v
            )

        # --------------------------------------------------
        # update overlay
        # --------------------------------------------------

        if self.update_mode:

            overlay_w = int(self.W * 0.7)
            overlay_h = int(self.H * 0.8)

            ox = (self.W - overlay_w) // 2
            oy = (self.H - overlay_h) // 2

            img = Image.new("RGBA", (overlay_w, overlay_h), (0, 0, 0, 0))
            draw = ImageDraw.Draw(img)

            draw.rounded_rectangle(
                [0, 0, overlay_w, overlay_h],
                radius=30,
                fill=(0, 0, 0, 230)
            )

            r.ui_draw_texture(
                ox,
                oy,
                overlay_w,
                overlay_h,
                np.array(img)
            )

            y = oy + 40

            for line in self.update_logs[-20:]:

                tex, w, h = self._get_text_texture(
                    line,
                    self.log_font,
                    (255, 255, 255, 255)
                )

                r.ui_draw_texture(
                    ox + 40,
                    y,
                    w,
                    h,
                    tex
                )

                y += h + 10

        self.engine.overlay.draw()

        r.ui_swap()

    # --------------------------------------------------

    def run(self):

        next_scene = None

        if not self.update_mode:
            next_scene = self._handle_input()
        else:
            self._update_process()

        self._draw()

        if next_scene is not None:
            return next_scene

        return self