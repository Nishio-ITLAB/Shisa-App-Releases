# framework/scenes/service/coin_settings.py

import numpy as np
from PIL import Image, ImageDraw, ImageFont

from framework.scenes.base import BaseScene
from framework.input_types import EventType, ButtonType


FONT_PATH = "/opt/shisa/shared/assets/fonts/NotoSansMono-Regular.ttf"


class CoinSettingsScene(BaseScene):

    def __init__(self, engine):
        super().__init__(engine)

        # ★ 修正：Engineの共有インスタンスを使用
        self.config = self.engine.system_config

        self.r = self.engine.renderer
        self.W = self.r.width
        self.H = self.r.height

        # ----------------------------
        # Font
        # ----------------------------
        self.title_font_size = int(self.H * 0.07)
        self.menu_font_size = int(self.H * 0.055)

        self.title_font = ImageFont.truetype(FONT_PATH, self.title_font_size)
        self.menu_font = ImageFont.truetype(FONT_PATH, self.menu_font_size)

        ascent_m, descent_m = self.menu_font.getmetrics()
        self.menu_height = ascent_m + descent_m

        self.text_cache = {}

        # ----------------------------
        # Menu
        # ----------------------------
        self.menu_items = [
            "FREE PLAY",
            "COIN PER CREDIT",
            "RESET CURRENT CREDIT",
            "RESET TOTAL COINS",
        ]

        self.index = 0
        self.spacing = 25

        # confirm state
        self.confirm_mode = False
        self.confirm_target = None

        # ----------------------------
        # Box
        # ----------------------------
        self.box_width = int(self.W * 0.7)
        self.box_height = int(self.H * 0.6)
        self.box_radius = 40

        self.box_x = (self.W - self.box_width) // 2
        self.box_y = int(self.H * 0.25)

        self._menu_box_texture = self._create_rounded_box()

    # --------------------------------------------------
    def _create_rounded_box(self):

        img = Image.new("RGBA", (self.box_width, self.box_height), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        draw.rounded_rectangle(
            [0, 0, self.box_width, self.box_height],
            radius=self.box_radius,
            fill=(20, 20, 20, 220)
        )

        return np.array(img, dtype=np.uint8)

    # --------------------------------------------------
    def _get_text_texture(self, text, font, color):

        key = (text, font.size, color)
        if key in self.text_cache:
            return self.text_cache[key]

        w = int(font.getlength(text))
        ascent, descent = font.getmetrics()
        h = ascent + descent

        img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        draw.text((0, 0), text, font=font, fill=color)

        arr = np.array(img, dtype=np.uint8)
        self.text_cache[key] = (arr, w, h)
        return arr, w, h

    # --------------------------------------------------
    def _handle_input(self):

        events = self.get_events()

        for e in events:

            if e.type != EventType.BUTTON_PRESSED:
                continue

            # ----------------------------
            # Confirm Mode
            # ----------------------------
            if self.confirm_mode:

                if e.payload == ButtonType.ENTER:
                    if self.confirm_target == 2:
                        self.config.reset_current_credit()
                    elif self.confirm_target == 3:
                        self.config.reset_coin_total()

                    self.confirm_mode = False

                elif e.payload == ButtonType.CANCEL:
                    self.confirm_mode = False

                return None

            # ----------------------------
            # Normal Mode
            # ----------------------------
            if e.payload == ButtonType.NAV_UP:
                self.index = (self.index - 1) % len(self.menu_items)

            elif e.payload == ButtonType.NAV_DOWN:
                self.index = (self.index + 1) % len(self.menu_items)

            elif e.payload == ButtonType.NAV_LEFT:

                if self.index == 0:
                    self.config.set_free_play(not self.config.is_free_play())

                elif self.index == 1:
                    v = self.config.get_coin_per_credit()
                    self.config.set_coin_per_credit(max(1, v - 1))

            elif e.payload == ButtonType.NAV_RIGHT:

                if self.index == 0:
                    self.config.set_free_play(not self.config.is_free_play())

                elif self.index == 1:
                    v = self.config.get_coin_per_credit()
                    self.config.set_coin_per_credit(v + 1)

            elif e.payload == ButtonType.ENTER:

                if self.index in (2, 3):
                    self.confirm_mode = True
                    self.confirm_target = self.index

            elif e.payload == ButtonType.CANCEL:
                from framework.scenes.service.system import SystemMenuScene
                return SystemMenuScene(self.engine)

        return None

    # --------------------------------------------------
    def _draw(self):

        r = self.r
        r.ui_clear(0.0, 0.0, 0.0)

        # Title
        title_text = "COIN SETTINGS"
        tex_t, w_t, h_t = self._get_text_texture(
            title_text,
            self.title_font,
            (255, 255, 255, 255)
        )

        r.ui_draw_texture(
            (self.W - w_t) // 2,
            int(self.H * 0.15),
            w_t,
            h_t,
            tex_t
        )

        # Box
        r.ui_draw_texture(
            self.box_x,
            self.box_y,
            self.box_width,
            self.box_height,
            self._menu_box_texture
        )

        total_menu_height = (
            len(self.menu_items) * self.menu_height +
            (len(self.menu_items) - 1) * self.spacing
        )

        start_y = self.box_y + (self.box_height - total_menu_height) // 2

        left_x = self.box_x + 80
        right_x = self.box_x + self.box_width - 80

        for i, item in enumerate(self.menu_items):

            y = start_y + i * (self.menu_height + self.spacing)

            if i == self.index:
                color = (255, 80, 80, 255)
            else:
                color = (200, 200, 200, 255)

            tex_l, w_l, h_l = self._get_text_texture(
                item,
                self.menu_font,
                color
            )

            r.ui_draw_texture(left_x, y, w_l, h_l, tex_l)

            value = ""
            if i == 0:
                value = "ON" if self.config.is_free_play() else "OFF"
            elif i == 1:
                value = str(self.config.get_coin_per_credit())
            elif i == 2:
                value = str(self.config.get_current_credit())
            elif i == 3:
                value = str(self.config.get_coin_total())

            tex_v, w_v, h_v = self._get_text_texture(
                value,
                self.menu_font,
                (255, 255, 255, 255)
            )

            r.ui_draw_texture(
                right_x - w_v,
                y,
                w_v,
                h_v,
                tex_v
            )

        # Confirm Dialog
        if self.confirm_mode:

            overlay_w = int(self.W * 0.55)
            overlay_h = int(self.H * 0.32)

            ox = (self.W - overlay_w) // 2
            oy = (self.H - overlay_h) // 2

            img = Image.new("RGBA", (overlay_w, overlay_h), (0, 0, 0, 0))
            draw = ImageDraw.Draw(img)

            draw.rounded_rectangle(
                [0, 0, overlay_w, overlay_h],
                radius=30,
                fill=(0, 0, 0, 230)
            )

            r.ui_draw_texture(ox, oy, overlay_w, overlay_h, np.array(img))

            if self.confirm_target == 2:
                message = "RESET CURRENT CREDIT ?"
            else:
                message = "RESET TOTAL COINS ?"

            tex_msg, w_msg, h_msg = self._get_text_texture(
                message,
                self.menu_font,
                (255, 255, 255, 255)
            )

            r.ui_draw_texture(
                (self.W - w_msg) // 2,
                oy + 50,
                w_msg,
                h_msg,
                tex_msg
            )

            tex_yes, w_yes, h_yes = self._get_text_texture(
                "ENTER : YES",
                self.menu_font,
                (255, 80, 80, 255)
            )

            tex_no, w_no, h_no = self._get_text_texture(
                "CANCEL : NO",
                self.menu_font,
                (80, 255, 80, 255)
            )

            margin_bottom = 40

            r.ui_draw_texture(
                (self.W - w_yes) // 2,
                oy + overlay_h - (h_yes + h_no + margin_bottom),
                w_yes,
                h_yes,
                tex_yes
            )

            r.ui_draw_texture(
                (self.W - w_no) // 2,
                oy + overlay_h - (h_no + margin_bottom),
                w_no,
                h_no,
                tex_no
            )

        self.engine.overlay.draw()
        r.ui_swap()

    # --------------------------------------------------
    def run(self):

        next_scene = self._handle_input()
        self._draw()

        if next_scene is not None:
            return next_scene

        return self
