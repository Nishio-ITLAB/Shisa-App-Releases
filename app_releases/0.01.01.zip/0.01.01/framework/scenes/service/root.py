# framework/scenes/service/root.py

import numpy as np
from PIL import Image, ImageDraw, ImageFont
import os

from framework.scenes.base import BaseScene
from framework.input_types import EventType, ButtonType


FONT_PATH = "/opt/shisa/shared/assets/fonts/NotoSansMono-Regular.ttf"


class ServiceRootScene(BaseScene):

    def __init__(self, engine):
        super().__init__(engine)

        self.r = self.engine.renderer
        self.W = self.r.width
        self.H = self.r.height

        # フォント
        self.title_font_size = int(self.H * 0.08)
        self.menu_font_size = int(self.H * 0.06)

        self.title_font = ImageFont.truetype(FONT_PATH, self.title_font_size)
        self.menu_font = ImageFont.truetype(FONT_PATH, self.menu_font_size)

        # バージョン表示用フォント（追加）
        self.version_font_size = int(self.H * 0.035)
        self.version_font = ImageFont.truetype(FONT_PATH, self.version_font_size)

        ascent_t, descent_t = self.title_font.getmetrics()
        self.title_height = ascent_t + descent_t

        ascent_m, descent_m = self.menu_font.getmetrics()
        self.menu_height = ascent_m + descent_m

        ascent_v, descent_v = self.version_font.getmetrics()
        self.version_height = ascent_v + descent_v

        self.text_cache = {}

        # メニュー順変更済み
        self.menu_items = [
            "SYSTEM",
            "GAME SETTINGS",
        ]

        self.index = 0

        # 枠設定
        self.box_width = int(self.W * 0.5)
        self.box_height = int(self.H * 0.35)
        self.box_radius = 40

        self.box_x = (self.W - self.box_width) // 2
        self.box_y = int(self.H * 0.32)

        self._menu_box_texture = self._create_rounded_box()

        # バージョン取得（変更）
        self.version, self.build = self._get_version_info()

    # --------------------------------------------------
    def _get_version_info(self):
        try:
            with open("/opt/shisa/current/version.txt", "r") as f:
                lines = f.read().splitlines()
                version = lines[0] if len(lines) > 0 else "unknown"
                build = lines[1] if len(lines) > 1 else ""
                return version, build
        except:
            return "unknown", ""

    # --------------------------------------------------
    def _create_rounded_box(self):

        img = Image.new("RGBA", (self.box_width, self.box_height), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        draw.rounded_rectangle(
            [0, 0, self.box_width, self.box_height],
            radius=self.box_radius,
            fill=(20, 20, 20, 220)
        )

        return np.array(img, dtype=np.uint8)

    # --------------------------------------------------
    def _get_text_texture(self, text, font, color):

        key = (text, font.size, color)
        if key in self.text_cache:
            return self.text_cache[key]

        w = int(font.getlength(text))
        ascent, descent = font.getmetrics()
        h = ascent + descent

        img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        draw.text((0, 0), text, font=font, fill=color)

        arr = np.array(img, dtype=np.uint8)
        self.text_cache[key] = (arr, w, h)
        return arr, w, h

    # --------------------------------------------------
    def _handle_input(self):

        events = self.get_events()

        for e in events:

            if e.type != EventType.BUTTON_PRESSED:
                continue

            if e.payload == ButtonType.NAV_UP:
                self.index = (self.index - 1) % len(self.menu_items)

            elif e.payload == ButtonType.NAV_DOWN:
                self.index = (self.index + 1) % len(self.menu_items)

            elif e.payload == ButtonType.ENTER:

                # 0 = SYSTEM
                if self.index == 0:
                    from framework.scenes.service.system import SystemMenuScene
                    return SystemMenuScene(self.engine)

                # 1 = GAME SETTINGS
                elif self.index == 1:
                    # まだ未実装 → とりあえず何もしない
                    return self

            elif e.payload == ButtonType.CANCEL:
                from framework.scenes.menu import MenuScene
                return MenuScene(self.engine)

        return None

    # --------------------------------------------------
    def _draw(self):

        r = self.r

        r.ui_clear(0.0, 0.0, 0.0)

        # タイトル
        title_text = "SERVICE MENU"

        tex_t, w_t, h_t = self._get_text_texture(
            title_text,
            self.title_font,
            (255, 255, 255, 255)
        )

        r.ui_draw_texture(
            (self.W - w_t) // 2,
            int(self.H * 0.15),
            w_t,
            h_t,
            tex_t
        )

        # 枠
        r.ui_draw_texture(
            self.box_x,
            self.box_y,
            self.box_width,
            self.box_height,
            self._menu_box_texture
        )

        # メニュー中央揃え
        spacing = 40

        total_menu_height = (
            len(self.menu_items) * self.menu_height +
            (len(self.menu_items) - 1) * spacing
        )

        start_y = self.box_y + (self.box_height - total_menu_height) // 2

        for i, item in enumerate(self.menu_items):

            if i == self.index:
                color = (255, 80, 80, 255)
            else:
                color = (200, 200, 200, 255)

            tex, w, h = self._get_text_texture(
                item,
                self.menu_font,
                color
            )

            x = (self.W - w) // 2
            y = start_y + i * (self.menu_height + spacing)

            r.ui_draw_texture(x, y, w, h, tex)

        # --------------------------------------------------
        # バージョン表示
        # --------------------------------------------------
        if self.build:
            version_text = f"VERSION {self.version} ({self.build})"
        else:
            version_text = f"VERSION {self.version}"

        tex_v, w_v, h_v = self._get_text_texture(
            version_text,
            self.version_font,
            (140, 140, 140, 255)
        )

        x_v = (self.W - w_v) // 2
        y_v = self.box_y + self.box_height + int(self.H * 0.03)

        r.ui_draw_texture(x_v, y_v, w_v, h_v, tex_v)

        self.engine.overlay.draw()
        r.ui_swap()

    # --------------------------------------------------
    def run(self):

        next_scene = self._handle_input()
        self._draw()

        if next_scene is not None:
            return next_scene

        return self