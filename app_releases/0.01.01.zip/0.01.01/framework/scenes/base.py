# framework/scenes/base.py

from framework.scene import Scene


class BaseScene(Scene):

    def __init__(self, engine):
        super().__init__(engine)

    def run(self):
        """
        1シーンを完結実行して、次のシーンを返す。
        継続するなら self を返しても良い。
        """
        raise NotImplementedError
