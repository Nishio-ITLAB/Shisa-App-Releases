# framework/scenes/menu.py

import numpy as np
from PIL import Image, ImageDraw, ImageFont, Image
import RPi.GPIO as GPIO

from framework.scene import Scene
from framework.input_types import EventType, ButtonType


FONT_PATH = "/opt/shisa/shared/assets/fonts/Orbitron-Regular.ttf"
LOGO_PATH = "/opt/shisa/shared/assets/image/logo.png"


class MenuNode:
    def __init__(self, name, children=None):
        self.name = name
        self.children = children or []


class MenuScene(Scene):

    def __init__(self, engine):
        super().__init__(engine)

        # ----------------------------
        # COIN電源ON（メニュー到達時）
        # ----------------------------
        GPIO.setmode(GPIO.BCM)
        GPIO.setup(9, GPIO.OUT)
        GPIO.output(9, GPIO.HIGH)

        self.r = self.engine.renderer
        self.W = self.r.width
        self.H = self.r.height

        # ----------------------------
        # 横レイアウト（割合固定）
        # ----------------------------
        self.left_margin = int(self.W * 0.05)
        self.col_width = int(self.W * 0.30)   # 1〜3階層は各30%
        self.right_margin = int(self.W * 0.05)

        # ----------------------------
        # 縦レイアウト
        # ----------------------------
        self.logo_height = 100
        self.font_size = int(self.H * 0.07)
        self.line_spacing = int(self.H * 0.095)

        self.top_margin = (
            self.logo_height +
            int(self.H * 0.08)   # ロゴとメニューの間隔
        )

        # ----------------------------
        # フォント
        # ----------------------------
        self.font = ImageFont.truetype(FONT_PATH, self.font_size)
        ascent, descent = self.font.getmetrics()
        self.font_height = ascent + descent

        # ----------------------------
        # ロゴ
        # ----------------------------
        logo_img = Image.open(LOGO_PATH).convert("RGBA")
        ratio = self.logo_height / logo_img.height
        new_w = int(logo_img.width * ratio)
        logo_img = logo_img.resize((new_w, self.logo_height))
        self.logo_rgba = np.array(logo_img, dtype=np.uint8)
        self.logo_w = new_w

        self.text_cache = {}

        # ----------------------------
        # メニュー構造
        # ----------------------------
        self.root = MenuNode("ROOT", [
            MenuNode("GAME 1", [
                MenuNode("MODE 1-1", [
                    MenuNode("1P"),
                    MenuNode("2P"),
                    MenuNode("3P"),
                    MenuNode("4P"),
                ]),
                MenuNode("MODE 1-2"),
                MenuNode("MODE 1-3"),
            ]),
            MenuNode("GAME 2"),
            MenuNode("GAME 3"),
        ])

        self.current = self.root
        self.stack = []
        self.index = 0

    # --------------------------------------------------
    # TEXT
    # --------------------------------------------------
    def _get_text_texture(self, text, color):

        key = (text, color)
        if key in self.text_cache:
            return self.text_cache[key]

        w = int(self.font.getlength(text))
        h = int(self.font_height)

        img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        draw.text((0, 0), text, font=self.font, fill=color)

        arr = np.array(img, dtype=np.uint8)
        self.text_cache[key] = (arr, w, h)
        return arr, w, h

    # --------------------------------------------------
    # INPUT
    # --------------------------------------------------
    def _handle_input(self):

        events = self.get_events()

        for e in events:

            if e.type != EventType.BUTTON_PRESSED:
                continue

            children = self.current.children
            total = len(children)

            if e.payload == ButtonType.NAV_UP:
                if total == 0:
                    return
                self.index = (self.index - 1) % total
                self.engine.audio.play("select")

            elif e.payload == ButtonType.NAV_DOWN:
                if total == 0:
                    return
                self.index = (self.index + 1) % total
                self.engine.audio.play("select")

            elif e.payload in (ButtonType.ENTER, ButtonType.NAV_RIGHT):

                if total == 0:
                    return

                selected = children[self.index]

                if selected.children:
                    self.stack.append((self.current, self.index))
                    self.current = selected
                    self.index = 0

                self.engine.audio.play("select")

            elif e.payload in (ButtonType.CANCEL, ButtonType.NAV_LEFT):

                if self.stack:
                    self.current, self.index = self.stack.pop()
                    self.engine.audio.play("cancel")

            elif e.payload == ButtonType.SERVICE:
                from framework.scenes.service.root import ServiceRootScene
                return ServiceRootScene(self.engine)

        return None

    # --------------------------------------------------
    # DRAW
    # --------------------------------------------------
    def _draw(self):

        r = self.r
        r.ui_clear(0.0, 0.0, 0.0)

        # ロゴ
        r.ui_draw_texture(
            self.left_margin,
            30,
            self.logo_w,
            self.logo_height,
            self.logo_rgba
        )

        # ★「存在する階層だけ」描画（従来通り）
        stack_list = [n for (n, _) in self.stack] + [self.current]
        stack_list = stack_list[:3]  # 最大3階層

        for depth, node in enumerate(stack_list):

            col_x = self.left_margin + depth * self.col_width

            # 背景（この階層が存在する時だけ出る）
            r.ui_draw_rect(
                col_x,
                self.top_margin - 30,
                self.col_width,
                self.H - self.top_margin - 40,
                (0.08, 0.08, 0.08, 1.0)
            )

            y = self.top_margin

            selected_index = None
            if depth < len(self.stack):
                selected_index = self.stack[depth][1]
            elif depth == len(stack_list) - 1:
                selected_index = self.index

            for i, child in enumerate(node.children):

                if depth == len(stack_list) - 1:
                    if i == self.index:
                        color = (255, 80, 80, 255)
                        highlight = True
                    else:
                        color = (220, 220, 220, 255)
                        highlight = False
                else:
                    if i == selected_index:
                        color = (200, 200, 200, 255)
                    else:
                        color = (90, 90, 90, 255)
                    highlight = False

                tex, w, h = self._get_text_texture(child.name, color)

                if highlight:
                    r.ui_draw_rect(
                        col_x + 10,
                        y - 10,
                        min(w + 20, self.col_width - 20),
                        h + 20,
                        (0.3, 0.0, 0.0, 1.0)
                    )

                r.ui_draw_texture(
                    col_x + 20,
                    y,
                    w,
                    h,
                    tex
                )

                y += self.line_spacing

        self.engine.overlay.draw()

        r.ui_swap()

    # --------------------------------------------------
    def run(self):

        next_scene = self._handle_input()

        self._draw()

        if next_scene is not None:
            return next_scene

        return self
