# framework/audio_player.py

import os
os.environ["SDL_AUDIODRIVER"] = "alsa"

import ctypes
import glob
import sdl2
import numpy as np
import av


AUDIO_DIR = "/opt/shisa/shared/assets/audio"

_audio_instance = None


@sdl2.SDL_AudioCallback
def audio_callback(userdata, stream, length):
    global _audio_instance
    player = _audio_instance
    if player is None:
        return

    buf = ctypes.cast(
        stream,
        ctypes.POINTER(ctypes.c_uint8 * length)
    ).contents

    current = player.current_sound
    pos = player.sound_pos
    play_flag = player.play_flag

    if not play_flag or not current:
        for i in range(length):
            buf[i] = 0
        return

    end = pos + length
    chunk = current[pos:end]

    for i in range(len(chunk)):
        buf[i] = chunk[i]

    for i in range(len(chunk), length):
        buf[i] = 0

    pos += length

    if pos >= len(current):
        player.play_flag = False
        pos = 0

    player.sound_pos = pos



class AudioPlayer:

    def __init__(self):
        global _audio_instance
        _audio_instance = self

        self.sounds = {}
        self.current_sound = None
        self.sound_pos = 0
        self.play_flag = False

        self.device = None

        self._init_audio()
        self._load_assets()

    # --------------------------------------------------
    # INIT
    # --------------------------------------------------
    def _init_audio(self):
        sdl2.SDL_InitSubSystem(sdl2.SDL_INIT_AUDIO)

        # 🔥 バッファ調整可能（256〜512で微調整）
        spec = sdl2.SDL_AudioSpec(48000, sdl2.AUDIO_S16SYS, 2, 256)
        spec.callback = audio_callback

        self.device = sdl2.SDL_OpenAudioDevice(None, 0, spec, None, 0)
        sdl2.SDL_PauseAudioDevice(self.device, 0)

    # --------------------------------------------------
    # LOAD ASSETS
    # --------------------------------------------------
    def _load_assets(self):
        audio_files = glob.glob(os.path.join(AUDIO_DIR, "*.mp3"))

        for path in audio_files:
            name = os.path.splitext(os.path.basename(path))[0]
            try:
                self.sounds[name] = self._load_sound(path)
                print("Loaded audio:", name)
            except Exception as e:
                print("Skip audio:", name, e)

    def _load_sound(self, path):
        container = av.open(path)
        stream = container.streams.audio[0]

        resampler = av.audio.resampler.AudioResampler(
            format="s16",
            layout="stereo",
            rate=48000,
        )

        pcm_chunks = []

        for frame in container.decode(stream):
            resampled = resampler.resample(frame)
            if not resampled:
                continue

            frames = resampled if isinstance(resampled, list) else [resampled]

            for f in frames:
                pcm = f.to_ndarray()
                if pcm.ndim == 2:
                    pcm = pcm.T.flatten()
                pcm_chunks.append(pcm.astype(np.int16))

        container.close()
        return np.concatenate(pcm_chunks).tobytes()

    # --------------------------------------------------
    # PUBLIC API
    # --------------------------------------------------
    def play(self, name):
        if name not in self.sounds:
            return

        if self.device is not None:
            sdl2.SDL_LockAudioDevice(self.device)

        try:
            self.current_sound = self.sounds[name]
            self.sound_pos = 0
            self.play_flag = True
        finally:
            if self.device is not None:
                sdl2.SDL_UnlockAudioDevice(self.device)

