# framework/config/system_config.py

import json
import os
from pathlib import Path


class SystemConfig:
    """
    システム永続状態管理クラス
    """

    DEFAULT_DATA = {
        "schema_version": 1,
        "free_play": False,
        "coin_per_credit": 1,
        "coin_total": 0,
        "current_credit": 0,
        "credit_buffer": 0,
    }

    def __init__(self):

        base_dir = Path(__file__).resolve().parents[4]
        self._persist_dir = base_dir / "persist" / "system"
        self._file_path = self._persist_dir / "system.json"

        self._data = {}

        self._ensure_storage()
        self._load()

    # --------------------------------------------------
    # 初期化
    # --------------------------------------------------

    def _ensure_storage(self):
        self._persist_dir.mkdir(parents=True, exist_ok=True)

        if not self._file_path.exists():
            self._data = self.DEFAULT_DATA.copy()
            self._atomic_save()

    def _load(self):
        try:
            with open(self._file_path, "r", encoding="utf-8") as f:
                loaded = json.load(f)
        except Exception:
            loaded = {}

        self._data = self.DEFAULT_DATA.copy()
        self._data.update(loaded)

        if self._data.get("schema_version") != self.DEFAULT_DATA["schema_version"]:
            self._data["schema_version"] = self.DEFAULT_DATA["schema_version"]
            self._atomic_save()

    def reload(self):
        self._load()

    # --------------------------------------------------
    # 保存（atomic）
    # --------------------------------------------------

    def _atomic_save(self):
        tmp_path = self._file_path.with_suffix(".json.tmp")

        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump(self._data, f, indent=2)
            f.flush()
            os.fsync(f.fileno())

        os.replace(tmp_path, self._file_path)

    # --------------------------------------------------
    # 設定関連
    # --------------------------------------------------

    def is_free_play(self):
        return self._data["free_play"]

    def set_free_play(self, value: bool):
        self._data["free_play"] = bool(value)

        # ★ free_play ON時はcredit_bufferを必ずクリア
        if self._data["free_play"]:
            self._data["credit_buffer"] = 0

        self._atomic_save()

    def get_coin_per_credit(self):
        return self._data["coin_per_credit"]

    def set_coin_per_credit(self, value: int):
        if value < 1:
            value = 1

        self._data["coin_per_credit"] = int(value)
        self._data["credit_buffer"] = 0  # 設定変更時はバッファ初期化
        self._atomic_save()

    # --------------------------------------------------
    # コイン関連
    # --------------------------------------------------

    def get_coin_total(self):
        return self._data["coin_total"]

    def get_current_credit(self):
        return self._data["current_credit"]

    def insert_coin(self):

        self._data["coin_total"] += 1

        self._data["credit_buffer"] += 1

        if self._data["credit_buffer"] >= self._data["coin_per_credit"]:
            self._data["current_credit"] += 1
            self._data["credit_buffer"] = 0

        self._atomic_save()

    def consume_credit(self):

        if self._data["free_play"]:
            return True

        if self._data["current_credit"] > 0:
            self._data["current_credit"] -= 1
            self._atomic_save()
            return True

        return False

    # --------------------------------------------------
    # 安全なリセットAPI
    # --------------------------------------------------

    def reset_current_credit(self):
        self._data["current_credit"] = 0
        self._data["credit_buffer"] = 0
        self._atomic_save()

    def reset_coin_total(self):
        self._data["coin_total"] = 0
        self._atomic_save()
