# framework/overlay.py

import numpy as np
from PIL import Image, ImageDraw, ImageFont


FONT_PATH = "/opt/shisa/shared/assets/fonts/Orbitron-Regular.ttf"


class Overlay:

    def __init__(self, engine):
        self.engine = engine
        self.r = engine.renderer

        self.W = self.r.width
        self.H = self.r.height

        self.margin = 30

        self.font_size = int(self.H * 0.035)
        self.font = ImageFont.truetype(FONT_PATH, self.font_size)

        ascent, descent = self.font.getmetrics()
        self.font_height = ascent + descent

        self._cache = {}

        # -------------------------
        # ★ 5桁固定想定
        # -------------------------
        sample_text = "CREDIT: 99999"
        self.max_text_width = int(self.font.getlength(sample_text))

        # -------------------------
        # paddingは上下左右独立
        # -------------------------
        self.pad_x = 25
        self.pad_y = 18

        self.box_width = self.max_text_width + self.pad_x * 2
        self.box_height = self.font_height + self.pad_y * 2

    # --------------------------------------------------
    def _get_text_texture(self, text, color):

        key = (text, color)
        if key in self._cache:
            return self._cache[key]

        w = int(self.font.getlength(text))
        h = int(self.font_height)

        img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        draw.text((0, 0), text, font=self.font, fill=color)

        arr = np.array(img, dtype=np.uint8)
        self._cache[key] = (arr, w, h)
        return arr, w, h

    # --------------------------------------------------
    def draw(self):

        r = self.r
        config = self.engine.system_config

        # -------------------------
        # 毎フレーム最新値取得
        # -------------------------
        if config.is_free_play():
            text = "FREE PLAY"
            color = (255, 200, 0, 255)
        else:
            credit = config.get_current_credit()
            text = f"CREDIT: {credit}"
            color = (255, 255, 255, 255)

        tex, w, h = self._get_text_texture(text, color)

        # -------------------------
        # 右下固定
        # -------------------------
        box_x = self.W - self.box_width - self.margin
        box_y = self.H - self.box_height - self.margin

        # 背景（半透明黒）
        r.ui_draw_rect(
            box_x,
            box_y,
            self.box_width,
            self.box_height,
            (0.0, 0.0, 0.0, 0.65)
        )

        # -------------------------
        # 右固定表示（桁が変わっても動かない）
        # -------------------------
        text_x = box_x + self.pad_x
        text_y = box_y + (self.box_height - h) // 2

        r.ui_draw_texture(
            text_x,
            text_y,
            w,
            h,
            tex
        )
