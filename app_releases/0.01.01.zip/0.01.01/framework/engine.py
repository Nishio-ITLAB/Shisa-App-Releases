# framework/engine.py

import time

from framework.renderer import Renderer
from framework.audio_player import AudioPlayer
from framework.video_player import VideoPlayer
from framework.input_manager import InputManager
from framework.scenes.boot import BootScene

from framework.config.system_config import SystemConfig
from framework.overlay import Overlay
from framework.input_types import EventType


class Engine:
    """
    Engine = オーケストレータ
    """

    def __init__(self):
        self.running = True

        self.renderer = Renderer(1920, 1080)

        self.audio = AudioPlayer()
        self.video = VideoPlayer(self.renderer, self.audio)
        self.input = InputManager()

        # ★ 唯一のSystemConfig
        self.system_config = SystemConfig()

        # ★ Overlayも同一config参照
        self.overlay = Overlay(self)

        self.scene = BootScene(self)

    def stop(self):
        self.running = False

    def run(self):
        while self.running and self.scene is not None:

            # -------------------------
            # 1. 入力取得
            # -------------------------
            events = self.input.poll()

            # -------------------------
            # 2. Engineレベル処理
            # -------------------------
            for e in events:
                if e.type == EventType.COIN:
                    self.system_config.insert_coin()
                    self.audio.play("coin")

            # -------------------------
            # 3. Sceneへ渡す
            # -------------------------
            self.scene.set_events(events)

            # -------------------------
            # 4. Scene実行
            # -------------------------
            self.scene = self.scene.run()

            time.sleep(0.001)
