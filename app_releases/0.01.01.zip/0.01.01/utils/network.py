# utils/network.py

import subprocess
import time


# --------------------------------------------------
# 共通
# --------------------------------------------------

def _run(cmd):

    print("RUN:", " ".join(cmd))

    r = subprocess.run(
        cmd,
        capture_output=True,
        text=True
    )

    print("RETURN:", r.returncode)
    print("STDOUT:", r.stdout.strip())
    print("STDERR:", r.stderr.strip())

    return r


# --------------------------------------------------
# WiFi接続
# --------------------------------------------------

def connect_wifi(ssid: str, password: str, timeout=20):

    print("===== WIFI CONNECT START =====")
    print("SSID:", ssid)

    if not ssid:
        return False, "SSID EMPTY"

    conn_name = f"shisa-{ssid}"

    start = time.time()

    while True:

        elapsed = time.time() - start

        if elapsed > timeout:
            print("WIFI TIMEOUT")
            return False, "WIFI TIMEOUT"

        print(f"TRY CONNECT... ({int(elapsed)}s)")

        try:

            # 削除
            _run([
                "sudo", "nmcli",
                "connection", "delete", conn_name
            ])

            # スキャン
            _run([
                "sudo", "nmcli",
                "dev", "wifi", "rescan"
            ])

            time.sleep(1)

            # 作成
            r = _run([
                "sudo", "nmcli",
                "connection", "add",
                "type", "wifi",
                "ifname", "wlan0",
                "con-name", conn_name,
                "ssid", ssid
            ])

            if r.returncode != 0:
                time.sleep(3)
                continue

            # セキュリティ
            _run([
                "sudo", "nmcli",
                "connection", "modify", conn_name,
                "wifi-sec.key-mgmt", "wpa-psk",
                "wifi-sec.psk", password
            ])

            # metric（優先化）
            _run([
                "sudo", "nmcli",
                "connection", "modify", conn_name,
                "ipv4.route-metric", "50"
            ])

            # 接続
            r = _run([
                "sudo", "nmcli",
                "--wait", "3",
                "connection", "up", conn_name
            ])

            if r.returncode == 0:

                print("WIFI CONNECT SUCCESS")

                # IP確認
                for i in range(8):

                    ip = subprocess.run(
                        ["ip", "addr", "show", "wlan0"],
                        capture_output=True,
                        text=True
                    )

                    if "inet " in ip.stdout:
                        print("IP ACQUIRED")
                        return True, "WIFI CONNECTED"

                    print("WAIT DHCP...")
                    time.sleep(1)

                return False, "NO IP"

        except Exception as e:
            print("WIFI EXCEPTION:", e)

        time.sleep(3)


# --------------------------------------------------
# WiFi切断
# --------------------------------------------------

def disconnect_wifi():

    print("===== WIFI DISCONNECT =====")

    _run([
        "sudo",
        "nmcli",
        "device",
        "disconnect",
        "wlan0"
    ])


# --------------------------------------------------
# Internetチェック（修正版）
# --------------------------------------------------

def check_internet(timeout=10):

    print("===== INTERNET CHECK START =====")

    start = time.time()

    while True:

        elapsed = time.time() - start

        print(f"CHECK INTERNET... ({int(elapsed)}s)")

        if elapsed > timeout:
            print("INTERNET TIMEOUT")
            return False, "NO INTERNET"

        try:

            r = subprocess.run(
                ["ping", "-c", "1", "-W", "1", "8.8.8.8"],
                capture_output=True,
                text=True
            )

            print("PING RETURN:", r.returncode)

            if r.returncode == 0:
                print("INTERNET OK")
                return True, "INTERNET OK"

        except Exception as e:
            print("PING EXCEPTION:", e)

        time.sleep(1)