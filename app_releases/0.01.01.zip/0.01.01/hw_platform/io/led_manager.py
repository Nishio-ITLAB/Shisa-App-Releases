# hw_platform/io/led_manager.py

import time
import RPi.GPIO as GPIO
from enum import Enum, auto


class LedMode(Enum):
    OFF = auto()
    ON = auto()
    BLINK = auto()


class LedManager:
    """
    LED制御クラス

    機能:
    - ON
    - OFF
    - BLINK (0.5秒周期)

    注意:
    update() を周期的に呼ぶ必要がある
    """

    BLINK_INTERVAL = 0.5

    def __init__(self):

        # BCM番号
        self.LED34_PIN = 10
        self.LED20_PIN = 22

        GPIO.setmode(GPIO.BCM)

        GPIO.setup(self.LED34_PIN, GPIO.OUT)
        GPIO.setup(self.LED20_PIN, GPIO.OUT)

        # HIGH = LED ON
        GPIO.output(self.LED34_PIN, GPIO.HIGH)
        GPIO.output(self.LED20_PIN, GPIO.HIGH)

        self._leds = {
            self.LED34_PIN: {
                "mode": LedMode.ON,
                "state": True,
                "last_toggle": time.time(),
            },
            self.LED20_PIN: {
                "mode": LedMode.ON,
                "state": True,
                "last_toggle": time.time(),
            },
        }

    # --------------------------------------------------
    # PUBLIC
    # --------------------------------------------------

    def set_on(self, pin: int):

        led = self._leds.get(pin)
        if led is None:
            return

        led["mode"] = LedMode.ON
        led["state"] = True

        GPIO.output(pin, GPIO.HIGH)

    def set_off(self, pin: int):

        led = self._leds.get(pin)
        if led is None:
            return

        led["mode"] = LedMode.OFF
        led["state"] = False

        GPIO.output(pin, GPIO.LOW)

    def set_blink(self, pin: int):

        led = self._leds.get(pin)
        if led is None:
            return

        led["mode"] = LedMode.BLINK
        led["last_toggle"] = time.time()

    # --------------------------------------------------
    # UPDATE
    # --------------------------------------------------

    def update(self):

        now = time.time()

        for pin, led in self._leds.items():

            if led["mode"] != LedMode.BLINK:
                continue

            if now - led["last_toggle"] >= self.BLINK_INTERVAL:

                led["state"] = not led["state"]
                led["last_toggle"] = now

                if led["state"]:
                    GPIO.output(pin, GPIO.HIGH)
                else:
                    GPIO.output(pin, GPIO.LOW)

    # --------------------------------------------------
    # CLEANUP
    # --------------------------------------------------

    def cleanup(self):

        GPIO.output(self.LED34_PIN, GPIO.LOW)
        GPIO.output(self.LED20_PIN, GPIO.LOW)

        GPIO.cleanup()