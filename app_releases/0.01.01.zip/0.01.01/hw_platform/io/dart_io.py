# hw_platform/io/dart_io.py

import time
import RPi.GPIO as GPIO
from smbus2 import SMBus

from framework.input_types import (
    EventType,
    ButtonType,
    InputEvent,
)

from hw_platform.io.tca9555 import TCA9555
from hw_platform.io.board_logic import BoardLogic


class DartIO:
    """
    実機 I/O 統合クラス

    役割:
    - TCA9555 のポーリング入力
    - MCP23017 の INT / INTCAP / GPIO 読み
    - ボタン debounce
    - ボタン長押し生成
    - ダーツ長押し生成
    - COIN ガード
    - SHOCK ガード
    - D_MODE LED 反映
    - ダーツ盤 SI snapshot / 2点ラッチ / 確定判定
    - 起動時の残留入力フラッシュ
    """

    # =========================================================
    # Debug
    # =========================================================

    DEBUG_BUTTON_EVENTS = False
    DEBUG_MCP_EVENTS = False
    DEBUG_RAW_TCA = False

    # True にすると dart_io 段階で入力内容を表示する
    DEBUG_INPUT_EVENTS = True

    # =========================================================
    # GPIO (BCM)
    # =========================================================

    GPIO_INT = 17
    GPIO_LED34 = 10
    GPIO_LED20 = 22
    GPIO_COINV = 9

    # =========================================================
    # Timing
    # =========================================================

    TCA_POLL_INTERVAL = 0.005          # 5ms
    MCP_INT_DELAY = 0.002              # 2ms
    MCP_FALLBACK_POLL_INTERVAL = 0.02  # 20ms safety poll

    COIN_GUARD_SEC = 0.2               # 200ms
    SHOCK_GUARD_SEC = 0.2              # 200ms

    BUTTON_LONG_PRESS_SEC = 1.0        # 1秒
    BUTTON_DEBOUNCE_COUNT = 2          # 2サンプル連続一致

    DART_LONG_PRESS_SEC = 1.0          # 1秒

    # ダーツ 2点ラッチ関連
    SI_LATCH_TIMEOUT_SEC = 0.04        # 40ms: 2点が揃わなければ破棄
    SI_CONFIRM_DELAY_SEC = 0.004       # 4ms: 2点揃ってから少し待って確定
    SI_LATCH_MAX_POINTS = 3            # ノイズ対策で最大3点まで保持

    # 起動直後は入力無視
    STARTUP_IGNORE_SEC = 0.1           # 100ms

    # =========================================================
    # MCP23017 registers
    # =========================================================

    MCP_IODIRA = 0x00
    MCP_IODIRB = 0x01
    MCP_GPINTENA = 0x04
    MCP_GPINTENB = 0x05
    MCP_DEFVALA = 0x06
    MCP_DEFVALB = 0x07
    MCP_INTCONA = 0x08
    MCP_INTCONB = 0x09
    MCP_IOCON = 0x0A
    MCP_GPPUA = 0x0C
    MCP_GPPUB = 0x0D
    MCP_INTFA = 0x0E
    MCP_INTFB = 0x0F
    MCP_INTCAPA = 0x10
    MCP_INTCAPB = 0x11
    MCP_GPIOA = 0x12
    MCP_GPIOB = 0x13

    # IOCON:
    # MIRROR=1, ODR=1
    MCP_IOCON_VALUE = 0b01000100

    # =========================================================
    # SI bit mapping (仕様通り)
    # =========================================================

    SI_MAP_20_A = [19, 20, 22, 21, 25, 26, 24, 23]
    SI_MAP_20_B = [17, 18, 16, 15, 13, 14, 12, 11]

    SI_MAP_21_A = [3, 4, 6, 5, 7, 8, 10, 9]
    SI_MAP_21_B = [1, 2, None, None, None, None, None, None]

    # =========================================================
    # TCA output defaults
    # =========================================================

    # 0x22
    TCA22_OUT0_DEFAULT = 0x00
    TCA22_OUT1_DEFAULT = 0x00

    # 0x23
    # P01 BTN6check = LOW
    # P02 BTN6LED   = HIGH
    TCA23_OUT0_DEFAULT = 0b00000100
    TCA23_OUT1_DEFAULT = 0x00

    # 0x24
    # P00 BTN5LED = HIGH
    # P03 BTN4LED = HIGH
    # P06 BTN3LED = HIGH
    TCA24_OUT0_DEFAULT = 0b01001001

    # P13 BTN1LED = HIGH
    # P16 BTN2LED = HIGH
    TCA24_OUT1_DEFAULT = 0b01001000

    # =========================================================
    # INIT
    # =========================================================

    def __init__(self):

        # --------------------------------------------------
        # 1. I2C bus / devices
        # --------------------------------------------------

        self.bus = SMBus(1)

        self.tca22 = TCA9555(self.bus, 0x22)
        self.tca23 = TCA9555(self.bus, 0x23)
        self.tca24 = TCA9555(self.bus, 0x24)

        # --------------------------------------------------
        # 2. TCA polarity off
        # --------------------------------------------------

        self.tca22.disable_polarity_inversion()
        self.tca23.disable_polarity_inversion()
        self.tca24.disable_polarity_inversion()

        # --------------------------------------------------
        # 3. output latch を先に安全値へ
        # --------------------------------------------------

        self.tca22.write_port0(self.TCA22_OUT0_DEFAULT)
        self.tca22.write_port1(self.TCA22_OUT1_DEFAULT)

        self.tca23.write_port0(self.TCA23_OUT0_DEFAULT)
        self.tca23.write_port1(self.TCA23_OUT1_DEFAULT)

        self.tca24.write_port0(self.TCA24_OUT0_DEFAULT)
        self.tca24.write_port1(self.TCA24_OUT1_DEFAULT)

        # --------------------------------------------------
        # 4. direction 設定
        # --------------------------------------------------

        # ADDR22
        # Port0: P06 S_MODE in, P07 D_MODE in
        # Port1: all output
        self.tca22.set_direction(
            0b11000000,
            0b00000000,
        )

        # ADDR23
        # Port0: P00 BTN6IN in, P03 COINVcheck in
        # Port1: all output
        self.tca23.set_direction(
            0b00001001,
            0b00000000,
        )

        # ADDR24
        # Port0: P02 BTN5IN in, P05 BTN4IN in
        # Port1: P11 BTN1IN in, P14 BTN2IN in, P17 BTN3IN in
        self.tca24.set_direction(
            0b00100100,
            0b10010010,
        )

        # direction 後にもう一度 desired output を再書き込み
        self.tca22.write_port0(self.TCA22_OUT0_DEFAULT)
        self.tca22.write_port1(self.TCA22_OUT1_DEFAULT)

        self.tca23.write_port0(self.TCA23_OUT0_DEFAULT)
        self.tca23.write_port1(self.TCA23_OUT1_DEFAULT)

        self.tca24.write_port0(self.TCA24_OUT0_DEFAULT)
        self.tca24.write_port1(self.TCA24_OUT1_DEFAULT)

        # --------------------------------------------------
        # 5. MCP23017 初期化
        # --------------------------------------------------

        self._init_mcp20()
        self._init_mcp21()

        # --------------------------------------------------
        # 6. CM4 GPIO 初期化
        # --------------------------------------------------

        GPIO.setmode(GPIO.BCM)

        GPIO.setup(self.GPIO_INT, GPIO.IN, pull_up_down=GPIO.PUD_UP)

        GPIO.setup(self.GPIO_LED34, GPIO.OUT)
        GPIO.setup(self.GPIO_LED20, GPIO.OUT)
        GPIO.setup(self.GPIO_COINV, GPIO.OUT)

        GPIO.output(self.GPIO_LED34, GPIO.LOW)
        GPIO.output(self.GPIO_LED20, GPIO.LOW)
        GPIO.output(self.GPIO_COINV, GPIO.LOW)

        # --------------------------------------------------
        # 7. 内部状態
        # --------------------------------------------------

        self.board_logic = BoardLogic()

        self.last_tca_poll_monotonic = 0.0
        self.last_mcp_poll_monotonic = 0.0
        self.last_coin_time_monotonic = 0.0
        self.last_shock_time_monotonic = 0.0

        self._dmode = False

        self._button_samples = {
            button: []
            for button in ButtonType
        }

        self._button_pressed = {
            button: False
            for button in ButtonType
        }

        self._button_press_time = {
            button: 0.0
            for button in ButtonType
        }

        self._button_long_sent = {
            button: False
            for button in ButtonType
        }

        # ダーツ2点ラッチ
        self._si_latch = []
        self._si_latch_started_monotonic = 0.0
        self._si_pair_ready_monotonic = 0.0

        # SIエッジ検出用の前回状態
        self._last_si_active = set()

        # ダーツ押下状態
        self._dart_pressed = False
        self._dart_press_time = 0.0
        self._dart_long_sent = False
        self._dart_last_hit = None
        self._dart_current_active = False

        # 起動時 D_MODE を読んで LED反映
        self._sync_dmode_from_input()

        # 起動時入力フラッシュ
        self._flush_startup_inputs()

        # 起動直後は少し入力を無視
        self._startup_ignore_until = time.monotonic() + self.STARTUP_IGNORE_SEC

        if self.DEBUG_INPUT_EVENTS:
            print("DartIO initialized")

    # =========================================================
    # MCP init
    # =========================================================

    def _init_mcp20(self):
        """
        ADDR20:
        全ピン SI入力
        """
        addr = 0x20

        self.bus.write_byte_data(addr, self.MCP_IOCON, self.MCP_IOCON_VALUE)

        self.bus.write_byte_data(addr, self.MCP_IODIRA, 0xFF)
        self.bus.write_byte_data(addr, self.MCP_IODIRB, 0xFF)

        self.bus.write_byte_data(addr, self.MCP_GPPUA, 0xFF)
        self.bus.write_byte_data(addr, self.MCP_GPPUB, 0xFF)

        self.bus.write_byte_data(addr, self.MCP_INTCONA, 0x00)
        self.bus.write_byte_data(addr, self.MCP_INTCONB, 0x00)

        self.bus.write_byte_data(addr, self.MCP_GPINTENA, 0xFF)
        self.bus.write_byte_data(addr, self.MCP_GPINTENB, 0xFF)

        self.bus.read_byte_data(addr, self.MCP_GPIOA)
        self.bus.read_byte_data(addr, self.MCP_GPIOB)

    def _init_mcp21(self):
        """
        ADDR21:
        A全入力
        B0,B1,B6,B7 入力
        B2..B5 SHOCKxcheck 出力(LOW初期値)
        """
        addr = 0x21

        self.bus.write_byte_data(addr, self.MCP_IOCON, self.MCP_IOCON_VALUE)

        # A: all input
        self.bus.write_byte_data(addr, self.MCP_IODIRA, 0xFF)
        self.bus.write_byte_data(addr, self.MCP_GPPUA, 0xFF)

        # B: 0,1,6,7 input / 2..5 output
        iodirb = 0b11000011
        gppub = 0b11000011

        self.bus.write_byte_data(addr, self.MCP_IODIRB, iodirb)
        self.bus.write_byte_data(addr, self.MCP_GPPUB, gppub)

        # B2..B5 output LOW
        self.bus.write_byte_data(addr, self.MCP_GPIOB, 0x00)

        self.bus.write_byte_data(addr, self.MCP_INTCONA, 0x00)
        self.bus.write_byte_data(addr, self.MCP_INTCONB, 0x00)

        self.bus.write_byte_data(addr, self.MCP_GPINTENA, 0xFF)
        self.bus.write_byte_data(addr, self.MCP_GPINTENB, 0b11000011)

        self.bus.read_byte_data(addr, self.MCP_GPIOA)
        self.bus.read_byte_data(addr, self.MCP_GPIOB)

    # =========================================================
    # Startup flush
    # =========================================================

    def _flush_startup_inputs(self):
        """
        起動時に残っている INT / ラッチ / 前回状態を全て破棄する
        """
        try:
            a20 = self.bus.read_byte_data(0x20, self.MCP_GPIOA)
            b20 = self.bus.read_byte_data(0x20, self.MCP_GPIOB)
            a21 = self.bus.read_byte_data(0x21, self.MCP_GPIOA)
            b21 = self.bus.read_byte_data(0x21, self.MCP_GPIOB)

            active = set(self._decode_si(a20, b20, a21, b21))
            self._last_si_active = active
            self._dart_current_active = bool(active)

            self._clear_si_latch()
            self._clear_dart_state()

            # 念のため timing 状態も初期化
            self.last_mcp_poll_monotonic = time.monotonic()
            self.last_coin_time_monotonic = 0.0
            self.last_shock_time_monotonic = 0.0

            if self.DEBUG_INPUT_EVENTS:
                print("Startup input flush complete")

        except Exception as e:
            print("Startup flush error:", e)

    # =========================================================
    # Public
    # =========================================================

    def poll(self):
        """
        1回の呼び出しで短時間に終わるようにする
        """
        now_mono = time.monotonic()
        now_ts = time.time()

        # 起動直後は入力無視
        if now_mono < self._startup_ignore_until:
            return []

        events = []

        # --------------------------------------------------
        # 1. MCP INT / fallback poll
        # --------------------------------------------------

        try:
            if GPIO.input(self.GPIO_INT) == GPIO.LOW:
                time.sleep(self.MCP_INT_DELAY)
                events.extend(self._handle_mcp(now_mono, now_ts))

            elif (now_mono - self.last_mcp_poll_monotonic) > self.MCP_FALLBACK_POLL_INTERVAL:
                self.last_mcp_poll_monotonic = now_mono
                events.extend(self._handle_mcp(now_mono, now_ts))

        except Exception as e:
            if self.DEBUG_MCP_EVENTS:
                print("MCP error:", e)

        # --------------------------------------------------
        # 2. TCA poll
        # --------------------------------------------------

        if (now_mono - self.last_tca_poll_monotonic) >= self.TCA_POLL_INTERVAL:
            self.last_tca_poll_monotonic = now_mono
            events.extend(self._handle_tca(now_mono, now_ts))

        # --------------------------------------------------
        # 3. Button long press check
        # --------------------------------------------------

        events.extend(self._check_button_long_press(now_mono, now_ts))

        # --------------------------------------------------
        # 4. Dart long press check
        # --------------------------------------------------

        events.extend(self._check_dart_long_press(now_mono, now_ts))

        # --------------------------------------------------
        # 5. SI latch finalize / timeout
        # --------------------------------------------------

        events.extend(self._finalize_si_latch_if_ready(now_mono, now_ts))
        self._expire_si_latch_if_needed(now_mono)

        return events

    # =========================================================
    # D_MODE / LED
    # =========================================================

    def _sync_dmode_from_input(self):
        p0_22, _ = self.tca22.read_inputs()

        # LEDロジック反転
        self._dmode = not bool(p0_22 & (1 << 7))
        self._apply_dmode_led()

    def _apply_dmode_led(self):
        if self._dmode:
            GPIO.output(self.GPIO_LED20, GPIO.HIGH)
            GPIO.output(self.GPIO_LED34, GPIO.LOW)
        else:
            GPIO.output(self.GPIO_LED20, GPIO.LOW)
            GPIO.output(self.GPIO_LED34, GPIO.HIGH)

    # =========================================================
    # TCA
    # =========================================================

    def _handle_tca(self, now_mono: float, now_ts: float):
        events = []

        p0_22, _ = self.tca22.read_inputs()
        p0_23, _ = self.tca23.read_inputs()
        p0_24, p1_24 = self.tca24.read_inputs()

        if self.DEBUG_RAW_TCA:
            print(
                f"TCA22={p0_22:08b} "
                f"TCA23={p0_23:08b} "
                f"TCA24P0={p0_24:08b} "
                f"TCA24P1={p1_24:08b}"
            )

        # D_MODE
        new_dmode = not bool(p0_22 & (1 << 7))
        if new_dmode != self._dmode:
            self._dmode = new_dmode
            self._apply_dmode_led()

        # Buttons (LOW active)
        raw_button_map = {
            ButtonType.SERVICE: not (p0_22 & (1 << 6)),  # S_MODE
            ButtonType.NAV_UP: not (p0_23 & (1 << 0)),   # BTN6IN
            ButtonType.NAV_DOWN: not (p0_24 & (1 << 2)), # BTN5IN
            ButtonType.NAV_LEFT: not (p0_24 & (1 << 5)), # BTN4IN
            ButtonType.CANCEL: not (p1_24 & (1 << 1)),   # BTN1IN
            ButtonType.ENTER: not (p1_24 & (1 << 4)),    # BTN2IN
            ButtonType.NAV_RIGHT: not (p1_24 & (1 << 7)) # BTN3IN
        }

        for button, raw_pressed in raw_button_map.items():
            events.extend(
                self._update_button_state(
                    button=button,
                    raw_pressed=raw_pressed,
                    now_mono=now_mono,
                    now_ts=now_ts,
                )
            )

        return events

    # =========================================================
    # Button state machine
    # =========================================================

    def _update_button_state(
        self,
        button: ButtonType,
        raw_pressed: bool,
        now_mono: float,
        now_ts: float,
    ):
        events = []

        samples = self._button_samples[button]
        samples.append(raw_pressed)

        if len(samples) > self.BUTTON_DEBOUNCE_COUNT:
            samples.pop(0)

        if len(samples) < self.BUTTON_DEBOUNCE_COUNT:
            return events

        stable_pressed = all(samples)

        if stable_pressed == self._button_pressed[button]:
            return events

        self._button_pressed[button] = stable_pressed

        if stable_pressed:
            self._button_press_time[button] = now_mono
            self._button_long_sent[button] = False

            if self.DEBUG_INPUT_EVENTS:
                print(f"INPUT BUTTON {button.name}")

            events.append(
                InputEvent(
                    type=EventType.BUTTON_PRESSED,
                    payload=button,
                    timestamp=now_ts,
                )
            )

            if self.DEBUG_BUTTON_EVENTS:
                print("BUTTON_PRESSED:", button.name)

        else:
            if self._button_long_sent[button]:
                events.append(
                    InputEvent(
                        type=EventType.BUTTON_LONG_PRESS_RELEASED,
                        payload=button,
                        timestamp=now_ts,
                    )
                )

                if self.DEBUG_BUTTON_EVENTS:
                    print("BUTTON_LONG_PRESS_RELEASED:", button.name)

            events.append(
                InputEvent(
                    type=EventType.BUTTON_RELEASED,
                    payload=button,
                    timestamp=now_ts,
                )
            )

            if self.DEBUG_BUTTON_EVENTS:
                print("BUTTON_RELEASED:", button.name)

            self._button_press_time[button] = 0.0
            self._button_long_sent[button] = False

        return events

    def _check_button_long_press(self, now_mono: float, now_ts: float):
        events = []

        for button in ButtonType:
            if not self._button_pressed[button]:
                continue

            if self._button_long_sent[button]:
                continue

            if (now_mono - self._button_press_time[button]) >= self.BUTTON_LONG_PRESS_SEC:
                self._button_long_sent[button] = True

                events.append(
                    InputEvent(
                        type=EventType.BUTTON_LONG_PRESS,
                        payload=button,
                        timestamp=now_ts,
                    )
                )

                if self.DEBUG_BUTTON_EVENTS:
                    print("BUTTON_LONG_PRESS:", button.name)

        return events

    # =========================================================
    # Dart long press / release
    # =========================================================

    def _check_dart_long_press(self, now_mono: float, now_ts: float):
        events = []

        if not self._dart_pressed:
            return events

        if self._dart_long_sent:
            return events

        if (now_mono - self._dart_press_time) >= self.DART_LONG_PRESS_SEC:
            self._dart_long_sent = True

            if self.DEBUG_INPUT_EVENTS:
                print(f"INPUT DART_LONG_PRESS {self._dart_last_hit}")

            events.append(
                InputEvent(
                    type=EventType.DART_LONG_PRESS,
                    payload=self._dart_last_hit,
                    timestamp=now_ts,
                )
            )

        return events

    def _handle_dart_release_if_needed(self, active_sis, now_ts: float):
        events = []

        current_active = bool(active_sis)

        # 前回押下中で、今回アクティブSIが無い場合にリリース
        if self._dart_pressed and not current_active:

            if self._dart_long_sent:
                if self.DEBUG_INPUT_EVENTS:
                    print(f"INPUT DART_LONG_PRESS_RELEASED {self._dart_last_hit}")

                events.append(
                    InputEvent(
                        type=EventType.DART_LONG_PRESS_RELEASED,
                        payload=self._dart_last_hit,
                        timestamp=now_ts,
                    )
                )
            else:
                if self.DEBUG_INPUT_EVENTS:
                    print(f"INPUT DART_RELEASED {self._dart_last_hit}")

                events.append(
                    InputEvent(
                        type=EventType.DART_RELEASED,
                        payload=self._dart_last_hit,
                        timestamp=now_ts,
                    )
                )

            self._clear_dart_state()

        self._dart_current_active = current_active
        return events

    def _clear_dart_state(self):
        self._dart_pressed = False
        self._dart_press_time = 0.0
        self._dart_long_sent = False
        self._dart_last_hit = None
        self._dart_current_active = False

    # =========================================================
    # MCP
    # =========================================================

    def _handle_mcp(self, now_mono: float, now_ts: float):
        events = []

        a20 = self.bus.read_byte_data(0x20, self.MCP_INTCAPA)
        b20 = self.bus.read_byte_data(0x20, self.MCP_INTCAPB)
        a21 = self.bus.read_byte_data(0x21, self.MCP_INTCAPA)
        b21 = self.bus.read_byte_data(0x21, self.MCP_INTCAPB)

        if self.DEBUG_MCP_EVENTS:
            print(
                f"MCP20 A={a20:08b} B={b20:08b} "
                f"MCP21 A={a21:08b} B={b21:08b}"
            )

        # SHOCK 最優先
        if not (b21 & (1 << 6)):

            if (now_mono - self.last_shock_time_monotonic) >= self.SHOCK_GUARD_SEC:
                self.last_shock_time_monotonic = now_mono

                if self.DEBUG_INPUT_EVENTS:
                    print("INPUT MISS")

                events.append(
                    InputEvent(
                        type=EventType.MISS,
                        payload=None,
                        timestamp=now_ts,
                    )
                )

            self._clear_si_latch()
            self._last_si_active.clear()

            # ダーツが押下中なら、MISS時にも状態は強制解除
            self._clear_dart_state()

            # INT clear safety
            self.bus.read_byte_data(0x21, self.MCP_GPIOA)
            self.bus.read_byte_data(0x21, self.MCP_GPIOB)

            return events

        # COIN
        if not (b21 & (1 << 7)):
            if (now_mono - self.last_coin_time_monotonic) >= self.COIN_GUARD_SEC:
                self.last_coin_time_monotonic = now_mono

                if self.DEBUG_INPUT_EVENTS:
                    print("INPUT COIN")

                events.append(
                    InputEvent(
                        type=EventType.COIN,
                        payload=None,
                        timestamp=now_ts,
                    )
                )

                if self.DEBUG_MCP_EVENTS:
                    print("COIN")

        # SI snapshot
        active_sis = set(self._decode_si(a20, b20, a21, b21))

        # ダーツリリース判定
        events.extend(self._handle_dart_release_if_needed(active_sis, now_ts))

        # 新しくLOWになったSIだけ検出
        new_sis = active_sis - self._last_si_active
        self._last_si_active = active_sis

        # ラッチ更新
        self._update_si_latch(tuple(sorted(new_sis)), now_mono)

        if self.DEBUG_MCP_EVENTS and new_sis:
            print("SI(new):", tuple(sorted(new_sis)))

        # INT clear safety
        self.bus.read_byte_data(0x21, self.MCP_GPIOA)
        self.bus.read_byte_data(0x21, self.MCP_GPIOB)

        return events

    # =========================================================
    # SI latch
    # =========================================================

    def _update_si_latch(self, active_sis, now_mono: float):
        if not active_sis:
            return

        if not self._si_latch:
            self._si_latch_started_monotonic = now_mono

        for si in active_sis:
            if si not in self._si_latch:
                self._si_latch.append(si)

                if len(self._si_latch) > self.SI_LATCH_MAX_POINTS:
                    self._si_latch = self._si_latch[:self.SI_LATCH_MAX_POINTS]

        if len(self._si_latch) >= 2 and self._si_pair_ready_monotonic == 0.0:
            self._si_pair_ready_monotonic = now_mono

    def _finalize_si_latch_if_ready(self, now_mono: float, now_ts: float):
        events = []

        if len(self._si_latch) < 2:
            return events

        if self._si_pair_ready_monotonic == 0.0:
            return events

        if (now_mono - self._si_pair_ready_monotonic) < self.SI_CONFIRM_DELAY_SEC:
            return events

        sis = tuple(sorted(self._si_latch[:2]))

        if self.DEBUG_INPUT_EVENTS:
            print(f"INPUT SI {sis}")

        hit = self.board_logic.decode(sis, self._dmode)

        if hit is not None:
            if self.DEBUG_INPUT_EVENTS:
                print(f"INPUT DART {hit}")

            events.append(
                InputEvent(
                    type=EventType.DART_HIT,
                    payload=hit,
                    timestamp=now_ts,
                )
            )

            if self.DEBUG_MCP_EVENTS:
                print("DART_HIT:", hit)

            # ダーツ押下開始
            self._dart_pressed = True
            self._dart_press_time = now_mono
            self._dart_long_sent = False
            self._dart_last_hit = hit
            self._dart_current_active = True

        self._clear_si_latch()

        return events

    def _expire_si_latch_if_needed(self, now_mono: float):
        if not self._si_latch:
            return

        if (now_mono - self._si_latch_started_monotonic) >= self.SI_LATCH_TIMEOUT_SEC:
            self._clear_si_latch()

    def _clear_si_latch(self):
        self._si_latch.clear()
        self._si_latch_started_monotonic = 0.0
        self._si_pair_ready_monotonic = 0.0

    # =========================================================
    # SI decode
    # =========================================================

    def _decode_si(self, a20, b20, a21, b21):
        active = []

        for bit, si_no in enumerate(self.SI_MAP_20_A):
            if si_no is not None and not (a20 & (1 << bit)):
                active.append(si_no)

        for bit, si_no in enumerate(self.SI_MAP_20_B):
            if si_no is not None and not (b20 & (1 << bit)):
                active.append(si_no)

        for bit, si_no in enumerate(self.SI_MAP_21_A):
            if si_no is not None and not (a21 & (1 << bit)):
                active.append(si_no)

        for bit, si_no in enumerate(self.SI_MAP_21_B):
            if si_no is not None and not (b21 & (1 << bit)):
                active.append(si_no)

        return tuple(sorted(active))

    # =========================================================
    # Public helpers
    # =========================================================

    def set_coin_power(self, enable: bool):
        GPIO.output(self.GPIO_COINV, GPIO.HIGH if enable else GPIO.LOW)

    def cleanup(self):
        try:
            GPIO.output(self.GPIO_COINV, GPIO.LOW)
        except Exception:
            pass

        GPIO.cleanup()