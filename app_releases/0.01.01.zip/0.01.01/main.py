#!/usr/bin/env python3

import signal
import os
from framework.engine import Engine
import RPi.GPIO as GPIO


def get_version_info():
    try:
        with open("/opt/shisa/current/version.txt", "r") as f:
            lines = f.read().splitlines()
            version = lines[0] if len(lines) > 0 else "unknown"
            build = lines[1] if len(lines) > 1 else ""
            return version, build
    except Exception as e:
        return "unknown", ""


def main():

    # --------------------------------------------------
    # VERSION表示（最初に出す）
    # --------------------------------------------------
    version, build = get_version_info()

    print("===== SHISA START =====")

    if build:
        print(f"VERSION: {version} ({build})")
    else:
        print(f"VERSION: {version}")

    # --------------------------------------------------
    # GPIO初期化（起動時はコイン電源OFF）
    # --------------------------------------------------
    GPIO.setmode(GPIO.BCM)
    GPIO.setup(9, GPIO.OUT)
    GPIO.output(9, GPIO.LOW)

    engine = Engine()

    # --------------------------------------------------
    # SIGTERM / SIGINT handler
    # --------------------------------------------------
    def handle_exit(signum, frame):
        print("Signal received. Stopping engine...")

        # コイン電源OFF
        GPIO.output(9, GPIO.LOW)

        engine.stop()

    signal.signal(signal.SIGTERM, handle_exit)
    signal.signal(signal.SIGINT, handle_exit)

    engine.run()


if __name__ == "__main__":
    main()