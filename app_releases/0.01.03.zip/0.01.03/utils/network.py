# utils/network.py

import subprocess
import time


# --------------------------------------------------
# 共通
# --------------------------------------------------

def _run(cmd):

    print("RUN:", " ".join(cmd))

    r = subprocess.run(
        cmd,
        capture_output=True,
        text=True
    )

    print("RETURN:", r.returncode)
    print("STDOUT:", r.stdout.strip())
    print("STDERR:", r.stderr.strip())

    return r


# --------------------------------------------------
# 既存 WiFi connection 削除
# --------------------------------------------------

def _delete_wifi_connection(name: str):

    if not name:
        return

    r = subprocess.run(
        ["nmcli", "-t", "-f", "NAME", "connection", "show"],
        capture_output=True,
        text=True
    )

    names = [line.strip() for line in r.stdout.splitlines() if line.strip()]

    if name in names:
        _run(["sudo", "nmcli", "connection", "delete", name])


# --------------------------------------------------
# wlan0 リフレッシュ
# --------------------------------------------------

def _refresh_wlan():

    print("===== WLAN REFRESH =====")

    _run(["sudo", "nmcli", "device", "disconnect", "wlan0"])
    _run(["sudo", "ip", "link", "set", "wlan0", "down"])
    time.sleep(1)
    _run(["sudo", "ip", "link", "set", "wlan0", "up"])
    time.sleep(2)


# --------------------------------------------------
# route / dns 設定反映
# --------------------------------------------------

def _apply_network_priority(conn_name: str):

    print("===== APPLY NETWORK PRIORITY =====")

    # wlan0 をインターネット優先
    _run([
        "sudo", "nmcli", "connection", "modify", conn_name,
        "ipv4.route-metric", "10"
    ])

    # eth0 はローカル専用にする
    _run([
        "sudo", "nmcli", "connection", "modify", "eth0",
        "ipv4.never-default", "yes"
    ])

    # DNS は自動（テザリング側に任せる）
    _run([
        "sudo", "nmcli", "connection", "modify", conn_name,
        "ipv4.ignore-auto-dns", "no"
    ])

    # eth0のdefault routeを強制排除
    _run([
        "sudo", "ip", "route", "del",
        "default", "dev", "eth0"
    ])
# --------------------------------------------------
# route 反映確認
# --------------------------------------------------

def _has_wlan_default_route():

    r = subprocess.run(
        ["ip", "route"],
        capture_output=True,
        text=True
    )

    print("IP ROUTE:")
    print(r.stdout.strip())

    for line in r.stdout.splitlines():
        s = line.strip()
        if not s.startswith("default via "):
            continue
        if " dev wlan0 " in f" {s} " or s.endswith(" dev wlan0"):
            return True

    return False


# --------------------------------------------------
# WiFi接続
# --------------------------------------------------

def connect_wifi(ssid: str, password: str, timeout=40):

    print("===== WIFI CONNECT START =====")
    print("SSID:", ssid)

    if not ssid:
        return False, "SSID EMPTY"

    start = time.time()

    # --------------------------------------------------
    # ① 古いconnection削除（壊れ対策）
    # --------------------------------------------------
    _delete_wifi_connection(ssid)

    # --------------------------------------------------
    # ② wlan0リフレッシュ
    # --------------------------------------------------
    _refresh_wlan()

    while True:

        elapsed = time.time() - start

        if elapsed > timeout:
            print("WIFI TIMEOUT")
            return False, "WIFI TIMEOUT"

        print(f"TRY CONNECT... ({int(elapsed)}s)")

        try:
            # --------------------------------------------------
            # ③ WiFiスキャン（超重要）
            # --------------------------------------------------
            print("SCAN WIFI...")

            _run([
                "sudo", "nmcli",
                "device", "wifi", "rescan"
            ])

            time.sleep(2)

            # 見えているSSID一覧表示（デバッグ）
            _run([
                "nmcli", "-t", "-f", "SSID,SIGNAL",
                "device", "wifi", "list"
            ])

            # --------------------------------------------------
            # ④ 接続
            # --------------------------------------------------
            r = _run([
                "sudo", "nmcli",
                "device", "wifi", "connect", ssid,
                "password", password,
                "ifname", "wlan0"
            ])

            if r.returncode != 0:
                print("CONNECT FAILED -> RETRY")
                time.sleep(3)
                continue

            print("WIFI CONNECT SUCCESS")

            # --------------------------------------------------
            # ⑤ ネットワーク優先設定
            # --------------------------------------------------
            _apply_network_priority(ssid)

            # --------------------------------------------------
            # ⑥ 再接続（設定反映）
            # --------------------------------------------------
            _run(["sudo", "nmcli", "connection", "down", ssid])
            time.sleep(1)

            r = _run(["sudo", "nmcli", "connection", "up", ssid])
            if r.returncode != 0:
                print("RECONNECT FAILED -> RETRY")
                time.sleep(3)
                continue

            # --------------------------------------------------
            # ⑦ ネットワーク安定待ち
            # --------------------------------------------------
            for i in range(12):

                print(f"WAIT NETWORK READY... ({i+1}/12)")

                ip = subprocess.run(
                    ["ip", "addr", "show", "wlan0"],
                    capture_output=True,
                    text=True
                )

                has_ip = "inet " in ip.stdout
                has_route = _has_wlan_default_route()

                if has_ip and has_route:
                    print("NETWORK READY")
                    return True, "WIFI CONNECTED"

                time.sleep(1)

        except Exception as e:
            print("WIFI EXCEPTION:", e)

        time.sleep(3)

# --------------------------------------------------
# WiFi切断
# --------------------------------------------------

def disconnect_wifi():

    print("===== WIFI DISCONNECT =====")

    _run([
        "sudo", "nmcli",
        "device", "disconnect", "wlan0"
    ])

    # 接続プロファイル削除
    r = subprocess.run(
        ["nmcli", "-t", "-f", "NAME", "connection", "show"],
        capture_output=True,
        text=True
    )

    for line in r.stdout.splitlines():
        name = line.strip()
        if not name:
            continue
        if name == "eth0" or name == "lo" or name == "netplan-eth0":
            continue
        if name.startswith("netplan-"):
            continue

        # wlan0 で使っていた可能性のある WiFi 接続だけ消す
        rr = subprocess.run(
            ["nmcli", "-t", "-f", "NAME,TYPE", "connection", "show"],
            capture_output=True,
            text=True
        )

    rr = subprocess.run(
        ["nmcli", "-t", "-f", "NAME,TYPE", "connection", "show"],
        capture_output=True,
        text=True
    )

    for line in rr.stdout.splitlines():
        parts = line.split(":")
        if len(parts) != 2:
            continue

        name, typ = parts[0].strip(), parts[1].strip()

        if typ != "wifi":
            continue

        if name:
            _run(["sudo", "nmcli", "connection", "delete", name])

    # wlan0 を軽く戻す
    _run(["sudo", "ip", "link", "set", "wlan0", "down"])
    _run(["sudo", "ip", "link", "set", "wlan0", "up"])


# --------------------------------------------------
# Internetチェック
# --------------------------------------------------

def check_internet(timeout=15):

    print("===== INTERNET CHECK START =====")

    start = time.time()

    while True:

        elapsed = time.time() - start
        print(f"CHECK INTERNET... ({int(elapsed)}s)")

        if elapsed > timeout:
            print("INTERNET TIMEOUT")
            return False, "NO INTERNET"

        try:
            # まず gateway 疎通
            r = subprocess.run(
                ["ping", "-I", "wlan0", "-c", "1", "-W", "1", "172.20.10.1"],
                capture_output=True,
                text=True
            )
            print("PING GATEWAY RETURN:", r.returncode)

            if r.returncode != 0:
                time.sleep(1)
                continue

            # 次に HTTPS で実通信確認
            r = subprocess.run(
                [
                    "curl",
                    "--interface", "wlan0",
                    "-I",
                    "--max-time", "5",
                    "https://api.github.com"
                ],
                capture_output=True,
                text=True
            )

            print("CURL RETURN:", r.returncode)
            print("CURL STDOUT:", r.stdout.strip())
            print("CURL STDERR:", r.stderr.strip())

            if r.returncode == 0:
                print("INTERNET OK")
                return True, "INTERNET OK"

        except Exception as e:
            print("INTERNET CHECK EXCEPTION:", e)

        time.sleep(1)