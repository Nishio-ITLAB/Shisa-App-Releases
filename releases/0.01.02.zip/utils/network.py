# utils/network.py

import subprocess
import socket


# --------------------------------------------------
# WiFi 接続
# --------------------------------------------------

def connect_wifi(ssid: str, password: str):

    print("===== WIFI CONNECT START =====")
    print("SSID:", ssid)
    print("PASSWORD LENGTH:", len(password) if password else 0)

    if not ssid:
        print("ERROR: SSID EMPTY")
        return False, "SSID EMPTY"

    try:

        # --------------------------------------------------
        # 既存 connection 削除
        # --------------------------------------------------

        delete_cmd = [
            "sudo",
            "nmcli",
            "connection",
            "delete",
            ssid
        ]

        print("RUN:", " ".join(delete_cmd))

        r = subprocess.run(
            delete_cmd,
            capture_output=True,
            text=True
        )

        print("DELETE RETURN:", r.returncode)
        print("DELETE STDOUT:", r.stdout)
        print("DELETE STDERR:", r.stderr)


        # --------------------------------------------------
        # wlan0 disconnect
        # --------------------------------------------------

        disconnect_cmd = [
            "sudo",
            "nmcli",
            "device",
            "disconnect",
            "wlan0"
        ]

        print("RUN:", " ".join(disconnect_cmd))

        r = subprocess.run(
            disconnect_cmd,
            capture_output=True,
            text=True
        )

        print("DISCONNECT RETURN:", r.returncode)
        print("DISCONNECT STDOUT:", r.stdout)
        print("DISCONNECT STDERR:", r.stderr)


        # --------------------------------------------------
        # WiFi rescan
        # --------------------------------------------------

        rescan_cmd = [
            "sudo",
            "nmcli",
            "dev",
            "wifi",
            "rescan"
        ]

        print("RUN:", " ".join(rescan_cmd))

        r = subprocess.run(
            rescan_cmd,
            capture_output=True,
            text=True
        )

        print("RESCAN RETURN:", r.returncode)
        print("RESCAN STDOUT:", r.stdout)
        print("RESCAN STDERR:", r.stderr)


        # --------------------------------------------------
        # WiFi connect
        # --------------------------------------------------

        connect_cmd = [
            "sudo",
            "nmcli",
            "--wait", "10",
            "dev",
            "wifi",
            "connect",
            ssid,
            "password",
            password,
            "ifname",
            "wlan0"
        ]

        print("RUN:", " ".join(connect_cmd))

        r = subprocess.run(
            connect_cmd,
            capture_output=True,
            text=True
        )

        print("CONNECT RETURN:", r.returncode)
        print("CONNECT STDOUT:", r.stdout)
        print("CONNECT STDERR:", r.stderr)

        if r.returncode == 0:

            print("WIFI CONNECT SUCCESS")

            return True, "WIFI CONNECTED"

        else:

            msg = r.stderr.strip() or r.stdout.strip()

            print("WIFI CONNECT FAIL:", msg)

            return False, f"WIFI FAIL : {msg}"

    except Exception as e:

        print("WIFI EXCEPTION:", e)

        return False, f"WIFI ERROR : {e}"


# --------------------------------------------------
# WiFi 切断
# --------------------------------------------------

def disconnect_wifi():

    print("===== WIFI DISCONNECT =====")

    try:

        cmd = [
            "sudo",
            "nmcli",
            "device",
            "disconnect",
            "wlan0"
        ]

        print("RUN:", " ".join(cmd))

        r = subprocess.run(
            cmd,
            capture_output=True,
            text=True
        )

        print("DISCONNECT RETURN:", r.returncode)
        print("DISCONNECT STDOUT:", r.stdout)
        print("DISCONNECT STDERR:", r.stderr)

    except Exception as e:

        print("DISCONNECT EXCEPTION:", e)


# --------------------------------------------------
# インターネット接続確認
# --------------------------------------------------

def check_internet(timeout=3):

    print("===== INTERNET CHECK START =====")

    try:

        print("CONNECT TEST: 8.8.8.8:53")

        socket.create_connection(("8.8.8.8", 53), timeout=timeout)

        print("INTERNET OK")

        return True, "INTERNET OK"

    except OSError as e:

        print("INTERNET FAIL:", e)

        return False, f"NO INTERNET : {e}"