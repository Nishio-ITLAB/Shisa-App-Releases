# framework/scenes/service/online_update.py

import json
from pathlib import Path
import time

import numpy as np
from PIL import Image, ImageDraw, ImageFont

from framework.scenes.base import BaseScene
from framework.input_types import EventType, ButtonType
from framework.ui.software_keyboard import SoftwareKeyboardScene

from utils.network import connect_wifi, check_internet, disconnect_wifi


FONT_PATH = "/opt/shisa/shared/assets/fonts/NotoSansMono-Regular.ttf"

WIFI_PATH = Path("/opt/shisa/persist/system/wifi.json")

DEFAULT_WIFI = {
    "schema_version": 1,
    "ssid": "",
    "password": ""
}


class OnlineUpdateScene(BaseScene):

    def __init__(self, engine):
        super().__init__(engine)

        self.r = self.engine.renderer
        self.W = self.r.width
        self.H = self.r.height

        # --------------------------------------------------
        # wifi.json load / create
        # --------------------------------------------------

        if not WIFI_PATH.exists():

            WIFI_PATH.parent.mkdir(parents=True, exist_ok=True)

            with open(WIFI_PATH, "w") as f:
                json.dump(DEFAULT_WIFI, f, indent=2)

            self.wifi = DEFAULT_WIFI.copy()

        else:

            with open(WIFI_PATH) as f:
                self.wifi = json.load(f)

        if "ssid" not in self.wifi:
            self.wifi["ssid"] = ""

        if "password" not in self.wifi:
            self.wifi["password"] = ""

        # --------------------------------------------------
        # Font
        # --------------------------------------------------

        self.title_font_size = int(self.H * 0.08)
        self.menu_font_size = int(self.H * 0.055)
        self.log_font_size = int(self.H * 0.03)

        self.title_font = ImageFont.truetype(FONT_PATH, self.title_font_size)
        self.menu_font = ImageFont.truetype(FONT_PATH, self.menu_font_size)
        self.log_font = ImageFont.truetype(FONT_PATH, self.log_font_size)

        ascent_t, descent_t = self.title_font.getmetrics()
        self.title_height = ascent_t + descent_t

        ascent_m, descent_m = self.menu_font.getmetrics()
        self.menu_height = ascent_m + descent_m

        ascent_l, descent_l = self.log_font.getmetrics()
        self.log_height = ascent_l + descent_l

        self.text_cache = {}

        # --------------------------------------------------
        # Menu
        # --------------------------------------------------

        self.menu_items = [
            "UPDATE EXECUTE",
            "SSID",
            "PASSWORD",
        ]

        self.index = 0

        # --------------------------------------------------
        # Box
        # --------------------------------------------------

        self.box_width = int(self.W * 0.7)
        self.box_height = int(self.H * 0.45)
        self.box_radius = 40

        self.box_x = (self.W - self.box_width) // 2
        self.box_y = int(self.H * 0.28)

        self._menu_box_texture = self._create_rounded_box()

        # --------------------------------------------------
        # Update state
        # --------------------------------------------------

        self.update_mode = False
        self.update_logs = []
        self.update_step = 0
        self.update_timer = 0

    # --------------------------------------------------

    def _create_rounded_box(self):

        img = Image.new("RGBA", (self.box_width, self.box_height), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        draw.rounded_rectangle(
            [0, 0, self.box_width, self.box_height],
            radius=self.box_radius,
            fill=(20, 20, 20, 220)
        )

        return np.array(img, dtype=np.uint8)

    # --------------------------------------------------

    def _get_text_texture(self, text, font, color):

        key = (text, font.size, color)

        if key in self.text_cache:
            return self.text_cache[key]

        w = max(1, int(font.getlength(text)))

        ascent, descent = font.getmetrics()
        h = ascent + descent

        img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        draw.text((0, 0), text, font=font, fill=color)

        arr = np.array(img, dtype=np.uint8)

        self.text_cache[key] = (arr, w, h)

        return arr, w, h

    # --------------------------------------------------

    def _save_wifi(self):

        with open(WIFI_PATH, "w") as f:
            json.dump(self.wifi, f, indent=2)

    # --------------------------------------------------
    # keyboard callbacks
    # --------------------------------------------------

    def _set_ssid(self, value):

        if value is not None:

            self.wifi["ssid"] = value
            self._save_wifi()

        return self

    def _set_pass(self, value):

        if value is not None:

            self.wifi["password"] = value
            self._save_wifi()

        return self

    # --------------------------------------------------
    # update process
    # --------------------------------------------------

    def _update_process(self):

        if self.update_step == 1:

            self.update_logs.append("WIFI CONNECTING...")
            self.update_step = 2
            return

        elif self.update_step == 2:

            ok, msg = connect_wifi(
                self.wifi["ssid"],
                self.wifi["password"]
            )

            self.update_logs.append(msg)

            if ok:
                self.update_step = 3
            else:
                self.update_step = 6

            return

        elif self.update_step == 3:

            self.update_logs.append("CHECK INTERNET...")
            self.update_step = 4
            return

        elif self.update_step == 4:

            ok, msg = check_internet()

            self.update_logs.append(msg)

            if ok:
                self.update_logs.append("UPDATE READY")
                self.update_step = 5
            else:
                self.update_step = 6

            self.update_timer = time.time()
            return

        elif self.update_step == 5:

            if time.time() - self.update_timer > 2:
                disconnect_wifi()
                self.update_mode = False

        elif self.update_step == 6:

            if "FAILED" not in self.update_logs[-1]:
                self.update_logs.append("FAILED")

            if time.time() - self.update_timer > 3:
                disconnect_wifi()
                self.update_mode = False

    # --------------------------------------------------

    def _handle_input(self):

        events = self.get_events()

        for e in events:

            if e.type != EventType.BUTTON_PRESSED:
                continue

            if e.payload == ButtonType.NAV_UP:

                self.index = (self.index - 1) % len(self.menu_items)

            elif e.payload == ButtonType.NAV_DOWN:

                self.index = (self.index + 1) % len(self.menu_items)

            elif e.payload == ButtonType.ENTER:

                if self.index == 0:

                    self.update_mode = True
                    self.update_logs = []
                    self.update_step = 1

                elif self.index == 1:

                    return SoftwareKeyboardScene(
                        self.engine,
                        title="INPUT SSID",
                        initial=self.wifi["ssid"],
                        on_done=self._set_ssid
                    )

                elif self.index == 2:

                    return SoftwareKeyboardScene(
                        self.engine,
                        title="INPUT PASSWORD",
                        initial=self.wifi["password"],
                        on_done=self._set_pass
                    )

            elif e.payload == ButtonType.CANCEL:

                from framework.scenes.service.system import SystemMenuScene
                return SystemMenuScene(self.engine)

        return None

    # --------------------------------------------------

    def _draw(self):

        r = self.r

        r.ui_clear(0.0, 0.0, 0.0)

        title_text = "ONLINE UPDATE"

        tex_t, w_t, h_t = self._get_text_texture(
            title_text,
            self.title_font,
            (255, 255, 255, 255)
        )

        r.ui_draw_texture(
            (self.W - w_t) // 2,
            int(self.H * 0.15),
            w_t,
            h_t,
            tex_t
        )

        r.ui_draw_texture(
            self.box_x,
            self.box_y,
            self.box_width,
            self.box_height,
            self._menu_box_texture
        )

        spacing = 40

        total_menu_height = (
            len(self.menu_items) * self.menu_height +
            (len(self.menu_items) - 1) * spacing
        )

        start_y = self.box_y + (self.box_height - total_menu_height) // 2

        left_x = self.box_x + 80
        right_x = self.box_x + self.box_width - 80

        for i, item in enumerate(self.menu_items):

            if i == self.index:
                color = (255, 80, 80, 255)
            else:
                color = (200, 200, 200, 255)

            tex_l, w_l, h_l = self._get_text_texture(
                item,
                self.menu_font,
                color
            )

            y = start_y + i * (self.menu_height + spacing)

            r.ui_draw_texture(left_x, y, w_l, h_l, tex_l)

            value = ""

            if i == 1:
                value = self.wifi["ssid"]

            elif i == 2:
                value = "*" * len(self.wifi["password"])

            tex_v, w_v, h_v = self._get_text_texture(
                value,
                self.menu_font,
                (255, 255, 255, 255)
            )

            r.ui_draw_texture(
                right_x - w_v,
                y,
                w_v,
                h_v,
                tex_v
            )

        # --------------------------------------------------
        # update overlay
        # --------------------------------------------------

        if self.update_mode:

            overlay_w = int(self.W * 0.7)
            overlay_h = int(self.H * 0.8)

            ox = (self.W - overlay_w) // 2
            oy = (self.H - overlay_h) // 2

            img = Image.new("RGBA", (overlay_w, overlay_h), (0, 0, 0, 0))
            draw = ImageDraw.Draw(img)

            draw.rounded_rectangle(
                [0, 0, overlay_w, overlay_h],
                radius=30,
                fill=(0, 0, 0, 230)
            )

            r.ui_draw_texture(
                ox,
                oy,
                overlay_w,
                overlay_h,
                np.array(img)
            )

            y = oy + 40

            for line in self.update_logs[-20:]:

                tex, w, h = self._get_text_texture(
                    line,
                    self.log_font,
                    (255, 255, 255, 255)
                )

                r.ui_draw_texture(
                    ox + 40,
                    y,
                    w,
                    h,
                    tex
                )

                y += h + 10

        self.engine.overlay.draw()

        r.ui_swap()

    # --------------------------------------------------

    def run(self):

        next_scene = None

        if not self.update_mode:
            next_scene = self._handle_input()
        else:
            self._update_process()

        self._draw()

        if next_scene is not None:
            return next_scene

        return self